<?php
// Reset-password page: checks the emailed token and saves a new password.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';

if (is_loggedin()) {
    redirect(site_url('index.php'));
}

$rawToken = trim($_GET['token'] ?? $_POST['token'] ?? '');

if (empty($rawToken)) {
    set_flash('Missing password reset token.', 'danger');
    redirect(site_url('users/forgot_password.php'));
}

$tokenHash = hash('sha256', $rawToken);

// Query block: reads from the database.
$stmt = mysqli_prepare($conn, "SELECT r.reset_id, r.user_id, r.expires_at, r.used_at, u.name, u.email
    FROM password_resets r
    INNER JOIN users u ON r.user_id = u.user_id
    WHERE r.token_hash = ? AND r.used_at IS NULL AND r.expires_at > NOW()
    LIMIT 1");
mysqli_stmt_bind_param($stmt, 's', $tokenHash);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$reset = mysqli_fetch_assoc($result);

if (!$reset) {
    set_flash('This password reset link is invalid or has expired. Please request a new one.', 'danger');
    redirect(site_url('users/forgot_password.php'));
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Security block: rejects forms without a valid CSRF token.
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Your session expired. Please try again.';
    }

    $password = trim($_POST['password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    if (empty($password)) {
        $errors[] = 'Password is required.';
    } elseif (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }

    if ($password !== $confirm_password) {
        $errors[] = 'Passwords do not match.';
    }

    if (empty($errors)) {
        $newHash = password_hash($password, PASSWORD_BCRYPT);
        $uid = (int)$reset['user_id'];
        $rid = (int)$reset['reset_id'];

        mysqli_begin_transaction($conn);
        try {
            // Update block: changes rows in users.
            $updUser = mysqli_prepare($conn, "UPDATE users SET password = ? WHERE user_id = ?");
            mysqli_stmt_bind_param($updUser, 'si', $newHash, $uid);
            mysqli_stmt_execute($updUser);

            // Update block: changes rows in password_resets.
            $updReset = mysqli_prepare($conn, "UPDATE password_resets SET used_at = NOW() WHERE reset_id = ?");
            mysqli_stmt_bind_param($updReset, 'i', $rid);
            mysqli_stmt_execute($updReset);

            mysqli_commit($conn);

            set_flash('Your password has been reset successfully. You can now log in with your new password.', 'success');
            redirect(site_url('users/login.php'));
        } catch (Throwable $ex) {
            mysqli_rollback($conn);
            @error_log('[reset_password] ' . $ex->getMessage());
            $errors[] = 'Failed to reset password. Please try again.';
        }
    }
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/alert.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7">
            <div class="card shadow-sm border-0">
                <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <span class="eyebrow mb-3">Security</span>
                        <h2 class="fw-bold">Set new password</h2>
                        <p class="text-muted">Enter a new secure password for <strong><?= e($reset['email']) ?></strong></p>
                    </div>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger"><?= e(implode(' ', $errors)) ?></div>
                    <?php endif; ?>

                    <form action="<?= e(site_url('users/reset_password.php')) ?>" method="POST" novalidate>
                        <?= csrf_input() ?>
                        <input type="hidden" name="token" value="<?= e($rawToken) ?>">

                        <div class="mb-3">
                            <label for="password" class="form-label fw-semibold">New Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
                                <input type="password" class="form-control form-control-lg" id="password" name="password"
                                    required autocomplete="new-password" minlength="6" autofocus>
                            </div>
                            <div class="form-text">Must be at least 6 characters.</div>
                        </div>

                        <div class="mb-4">
                            <label for="confirm_password" class="form-label fw-semibold">Confirm New Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
                                <input type="password" class="form-control form-control-lg" id="confirm_password" name="confirm_password"
                                    required autocomplete="new-password">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-snapit btn-lg w-100 fw-semibold">
                            <i class="fa-solid fa-key me-2"></i>Reset Password
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
