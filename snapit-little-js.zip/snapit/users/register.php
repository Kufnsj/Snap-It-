<?php
// Registration page and handler: creates a customer account (with optional profile photo).
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';

if (is_loggedin()) {
    redirect(site_url('index.php'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = trim($_POST['password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');
    $avatar_file = $_FILES['avatar'] ?? null;
    $has_avatar = !upload_is_empty($avatar_file);

    $errors = [];

    // When the whole request is bigger than post_max_size, PHP drops $_POST and $_FILES entirely.
    if (empty($_POST) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
        $errors[] = 'The upload was too large. Please choose a photo under 2 MB.';
    } elseif (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Your session expired. Please try again.';
    } else {
        if ($name === '') {
            $errors[] = 'Full name is required.';
        } elseif (mb_strlen($name) > 150) {
            $errors[] = 'Full name is too long (150 characters maximum).';
        }
        if ($email === '') {
            $errors[] = 'Email is required.';
        } elseif (strlen($email) > 150) {
            $errors[] = 'Email is too long (150 characters maximum).';
        } elseif (!valid_email($email)) {
            $errors[] = 'Please enter a valid email address.';
        }
        if ($password === '') {
            $errors[] = 'Password is required.';
        } elseif (strlen($password) < 6) {
            $errors[] = 'Password must be at least 6 characters.';
        }
        if ($password !== $confirm_password) {
            $errors[] = 'Passwords do not match.';
        }
        // The photo is optional, but if one was chosen it must be a valid image.
        // It is checked here, BEFORE the account is created.
        if ($has_avatar) {
            [, $photo_err] = avatar_precheck_upload($avatar_file);
            if ($photo_err) $errors[] = $photo_err;
        }
    }

    if (empty($errors)) {
        // Query block: reads from users.
        $check_stmt = mysqli_prepare($conn, "SELECT user_id FROM users WHERE email = ? LIMIT 1");
        mysqli_stmt_bind_param($check_stmt, 's', $email);
        mysqli_stmt_execute($check_stmt);
        if (mysqli_num_rows(mysqli_stmt_get_result($check_stmt)) > 0) {
            $errors[] = 'Email is already registered. Please use a different email or login.';
        }
    }

    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $role = 'customer';
        $status = 'active';

        // The account row and its photo are saved together: if anything fails the whole
        // registration is rolled back and the half-saved image file is removed.
        // The UNIQUE index on email is the final guard if two people register at the same moment.
        $saved = false;
        $saved_file = null;
        mysqli_begin_transaction($conn);
        try {
            // Save block: inserts into users.
            $insert_stmt = mysqli_prepare($conn, "INSERT INTO users (name, email, password, role, status) VALUES (?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($insert_stmt, 'sssss', $name, $email, $hashed_password, $role, $status);
            mysqli_stmt_execute($insert_stmt);
            $new_id = (int)mysqli_insert_id($conn);

            if ($has_avatar) {
                // The stored file name starts with the new user's id, so it can only be made now.
                [$saved_file, $photo_err] = avatar_save_upload($avatar_file, $new_id);
                if ($photo_err) throw new RuntimeException($photo_err);
                // Update block: changes rows in users.
                $upd = mysqli_prepare($conn, "UPDATE users SET avatar = ? WHERE user_id = ?");
                mysqli_stmt_bind_param($upd, 'si', $saved_file, $new_id);
                mysqli_stmt_execute($upd);
            }
            mysqli_commit($conn);
            $saved = true;
        } catch (Throwable $ex) {
            mysqli_rollback($conn);
            if ($saved_file) avatar_delete_file($saved_file);
            if ($ex instanceof mysqli_sql_exception && (int)$ex->getCode() === 1062) {
                $errors[] = 'Email is already registered. Please use a different email or login.';
            } elseif ($ex instanceof RuntimeException) {
                $errors[] = $ex->getMessage();
            } else {
                @error_log('[users/register] ' . $ex->getMessage());
                $errors[] = 'Registration failed. Please try again.';
            }
        }

        if ($saved) {
            set_flash('Registration successful! Please sign in to continue.', 'success');
            redirect(site_url('users/login.php'));
        }
    }

    // Show the problems on this same page so the typed values are kept
    // (a chosen photo cannot be re-filled by the browser, so it has to be picked again).
    $msg = implode(' ', $errors);
    if ($has_avatar) $msg .= ' Please choose your photo again.';
    set_flash($msg, 'danger');
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/alert.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-7 col-md-9">
            <div class="card shadow-sm border-0">
                <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <span class="eyebrow mb-3">Join Snap It</span>
                        <h2 class="fw-bold">Create your account</h2>
                        <p class="text-muted">Begin reserving unforgettable event experiences</p>
                    </div>

                    <form action="<?= e(site_url('users/register.php')) ?>" method="POST" enctype="multipart/form-data" novalidate>
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

                        <div class="text-center mb-4">
                            <div id="avatarPreviewWrap" class="mx-auto mb-2 d-flex align-items-center justify-content-center"
                                 style="width:104px;height:104px;border-radius:50%;overflow:hidden;border:2px dashed var(--snapit-gold);background:rgba(255,255,255,.04)">
                                <i id="avatarPlaceholder" class="fa-regular fa-user fa-2x text-muted"></i>
                            </div>
                            <label for="avatar" class="form-label fw-semibold mb-1">Profile Photo <span class="text-muted fw-normal">(optional)</span></label>
                            <input type="file" class="form-control" id="avatar" name="avatar" accept="image/jpeg,image/png,image/webp">
                            <div class="form-text">JPG, PNG or WEBP, up to 2 MB. It will be cropped to a square.</div>
                        </div>

                        <div class="mb-3">
                            <label for="name" class="form-label fw-semibold">Full Name</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fa-regular fa-user"></i></span>
                                <input type="text" class="form-control form-control-lg" id="name" name="name"
                                    value="<?= e($_POST['name'] ?? '') ?>" required autocomplete="name">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label fw-semibold">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fa-regular fa-envelope"></i></span>
                                <input type="email" class="form-control form-control-lg" id="email" name="email"
                                    value="<?= e($_POST['email'] ?? '') ?>" required autocomplete="email">
                            </div>
                        </div>

                        <div class="row g-3 mb-4">
                            <div class="col-md-6">
                                <label for="password" class="form-label fw-semibold">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
                                    <input type="password" class="form-control form-control-lg" id="password" name="password"
                                        required autocomplete="new-password">
                                </div>
                                <div class="form-text">At least 6 characters</div>
                            </div>
                            <div class="col-md-6">
                                <label for="confirm_password" class="form-label fw-semibold">Confirm Password</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fa-solid fa-lock-open"></i></span>
                                    <input type="password" class="form-control form-control-lg" id="confirm_password" name="confirm_password"
                                        required autocomplete="new-password">
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-snapit btn-lg w-100 fw-semibold">
                            <i class="fa-solid fa-user-plus me-2"></i>Create Account
                        </button>
                    </form>

                    <div class="text-center mt-4 pt-3 border-top">
                        <p class="mb-0 text-muted">Already have an account?
                            <a href="<?= e(site_url('users/login.php')) ?>" class="fw-semibold text-decoration-none" style="color:var(--snapit-gold)">Sign in here</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php require __DIR__ . '/../includes/footer.php'; ?>
