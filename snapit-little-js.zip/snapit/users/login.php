<?php
// Login page and handler: checks the password, starts the session and redirects by role.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';

if (is_loggedin()) {
    redirect(site_url('index.php'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Security block: rejects forms without a valid CSRF token.
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('Your session expired. Please try again.', 'danger');
        redirect(site_url('users/login.php'));
    }

    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = trim($_POST['password'] ?? '');

    // Server-side (PHP) validation - no HTML5 validation is used on this form.
    $login_errors = [];
    if ($email === '') {
        $login_errors[] = 'Email is required.';
    } elseif (strlen($email) > 150) {
        $login_errors[] = 'Email is too long (150 characters maximum).';
    } elseif (!valid_email($email)) {
        $login_errors[] = 'Please enter a valid email address.';
    }
    if ($password === '') {
        $login_errors[] = 'Password is required.';
    } elseif (strlen($password) > 255) {
        $login_errors[] = 'Password is too long.';
    }
    if ($login_errors) {
        set_flash(implode(' ', $login_errors), 'warning');
        redirect(site_url('users/login.php'));
    }

    // Query block: reads from users.
    $stmt = mysqli_prepare($conn, "SELECT user_id, name, email, password, role, status FROM users WHERE email = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 's', $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if ($row['status'] !== 'active') {
            set_flash('Your account is inactive. Please contact support.', 'danger');
            redirect(site_url('users/login.php'));
        }
        if (password_verify($password, $row['password'])) {
            // Fresh session id and an empty session: nothing left over from a previous
            // visitor on this browser (booth session, old name, CSRF token) can carry
            // into this account.
            session_regenerate_id(true);
            $_SESSION = [];
            $_SESSION['user_id'] = (int)$row['user_id'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['name'] = $row['name'];
            $_SESSION['role'] = $row['role'];
            unset($_SESSION['avatar']);

            if (!empty($_POST['remember'])) {
                $cookieParams = session_get_cookie_params();
                setcookie(session_name(), session_id(), [
                    'expires'  => time() + (86400 * 30),
                    'path'     => $cookieParams['path'] ?: '/',
                    'domain'   => $cookieParams['domain'],
                    'secure'   => $cookieParams['secure'],
                    'httponly' => $cookieParams['httponly'],
                    'samesite' => $cookieParams['samesite'] ?? 'Lax',
                ]);
            }

            set_flash('Welcome back, ' . e($row['name']) . '!', 'success');

            if (is_staff()) {
                redirect(site_url('admin/index.php'));
            }
            redirect(site_url('booking/create.php'));
        }
    }

    set_flash('Invalid email or password.', 'danger');
    redirect(site_url('users/login.php'));
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/alert.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7">
            <div class="card shadow-sm border-0">
                <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <span class="eyebrow mb-3">Member Access</span>
                        <h2 class="fw-bold">Welcome back</h2>
                        <p class="text-muted">Sign in to continue your Snap It experience</p>
                    </div>

                    <form action="<?= e(site_url('users/login.php')) ?>" method="POST" novalidate>
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <div class="mb-3">
                            <label for="email" class="form-label fw-semibold">Email address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fa-regular fa-envelope"></i></span>
                                <input type="text" inputmode="email" class="form-control form-control-lg" id="email" name="email"
                                    value="<?= e($_POST['email'] ?? '') ?>" autocomplete="email">
                            </div>
                        </div>

                        <div class="mb-4">
                            <label for="password" class="form-label fw-semibold">Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
                                <input type="password" class="form-control form-control-lg" id="password" name="password"
                                    autocomplete="current-password">
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center mb-4 small">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="remember" name="remember" value="1">
                                <label class="form-check-label text-muted" for="remember">Remember me</label>
                            </div>
                            <a href="<?= e(site_url('users/forgot_password.php')) ?>" class="text-decoration-none" style="color:var(--snapit-gold)">Forgot password?</a>
                        </div>

                        <button type="submit" class="btn btn-snapit btn-lg w-100 fw-semibold">
                            <i class="fa-solid fa-right-to-bracket me-2"></i>Sign In
                        </button>
                    </form>

                    <div class="text-center mt-4 pt-3 border-top">
                        <p class="mb-0 text-muted">Don't have an account?
                            <a href="<?= e(site_url('users/register.php')) ?>" class="fw-semibold text-decoration-none" style="color:var(--snapit-gold)">Create one</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php require __DIR__ . '/../includes/footer.php'; ?>
