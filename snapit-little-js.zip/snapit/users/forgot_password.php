<?php
// Forgot-password page: creates a reset token and emails the reset link.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/mailer.php';

if (is_loggedin()) {
    redirect(site_url('index.php'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Security block: rejects forms without a valid CSRF token.
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('Your session expired. Please try again.', 'danger');
        redirect(site_url('users/forgot_password.php'));
    }

    $email = strtolower(trim($_POST['email'] ?? ''));

    if (empty($email) || !valid_email($email)) {
        set_flash('Please enter a valid email address.', 'warning');
        redirect(site_url('users/forgot_password.php'));
    }

    // Query block: reads from users.
    $stmt = mysqli_prepare($conn, "SELECT user_id, name, email, status FROM users WHERE email = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 's', $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user && $user['status'] === 'active') {
        $rawToken = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $rawToken);

        // Delete block: removes rows from password_resets.
        $delStmt = mysqli_prepare($conn, "DELETE FROM password_resets WHERE user_id = ?");
        $uid = (int)$user['user_id'];
        mysqli_stmt_bind_param($delStmt, 'i', $uid);
        mysqli_stmt_execute($delStmt);

        // Save block: inserts into password_resets.
        $insStmt = mysqli_prepare($conn, "INSERT INTO password_resets (user_id, token_hash, expires_at, created_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR), NOW())");
        mysqli_stmt_bind_param($insStmt, 'is', $uid, $tokenHash);
        mysqli_stmt_execute($insStmt);

        $resetUrl = snapit_build_full_url('users/reset_password.php?token=' . $rawToken);
        $subject = 'Snap It — Password Reset Request';
        $bodyHtml = '<h2 style="font-size:17px;color:#3a2a1c;margin:0 0 12px">Password Reset Request</h2>'
            . '<p>Hi ' . htmlspecialchars($user['name']) . ',</p>'
            . '<p>We received a request to reset your password for your Snap It account. Click the button below to set a new password:</p>'
            . '<p><a class="cta" href="' . htmlspecialchars($resetUrl) . '" style="display:inline-block;background:#1a120c;color:#d8c09a;text-decoration:none;padding:12px 22px;border-radius:8px;font-weight:600;margin:14px 0">Reset Password</a></p>'
            . '<div class="meta" style="background:#fbf8f3;border-left:4px solid #8c6b45;padding:12px 16px;margin:16px 0;border-radius:0 6px 6px 0;font-size:14px">'
            . 'This password reset link will expire in 1 hour. If you did not request this, you can safely ignore this email.'
            . '</div>';
        $bodyText = "Hi {$user['name']},\n\nWe received a request to reset your password for your Snap It account.\nReset link: {$resetUrl}\n\nThis link expires in 1 hour. If you did not request this, ignore this email.";

        snapit_send_email([
            'to'        => $user['email'],
            'subject'   => $subject,
            'body_html' => snapit_email_wrap_html('Password Reset', $bodyHtml),
            'body_text' => $bodyText,
        ]);
    }

    set_flash('If that email address exists in our system, we have sent password reset instructions to it.', 'info');
    redirect(site_url('users/login.php'));
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/alert.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7">
            <div class="card shadow-sm border-0">
                <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <span class="eyebrow mb-3">Account Recovery</span>
                        <h2 class="fw-bold">Forgot password?</h2>
                        <p class="text-muted">Enter your email and we'll send you a link to reset your password</p>
                    </div>

                    <form action="<?= e(site_url('users/forgot_password.php')) ?>" method="POST" novalidate>
                        <?= csrf_input() ?>
                        <div class="mb-4">
                            <label for="email" class="form-label fw-semibold">Email address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fa-regular fa-envelope"></i></span>
                                <input type="email" class="form-control form-control-lg" id="email" name="email"
                                    value="<?= e($_POST['email'] ?? '') ?>" required autocomplete="email" autofocus>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-snapit btn-lg w-100 fw-semibold">
                            <i class="fa-solid fa-paper-plane me-2"></i>Send Reset Link
                        </button>
                    </form>

                    <div class="text-center mt-4 pt-3 border-top">
                        <p class="mb-0 text-muted">Remembered your password?
                            <a href="<?= e(site_url('users/login.php')) ?>" class="fw-semibold text-decoration-none" style="color:var(--snapit-gold)">Sign in</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
