<?php
// Staff handler: validates and saves a cash payment, marks the booking paid and emails the customer.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
// Guard block: only staff and admins can use this page.
require_staff();

// Request check block: only POST form submissions are accepted here.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(site_url('payment/index.php'));
}

// Security block: rejects forms without a valid CSRF token.
if (!isset($_POST['csrf_token']) || !verify_csrf($_POST['csrf_token'])) {
    set_flash('Invalid security token. Please refresh the page and try again.', 'danger');
    $bookingId = isset($_POST['booking_id']) ? (int)$_POST['booking_id'] : 0;
    if ($bookingId > 0) redirect(site_url('payment/record.php?booking_id=' . $bookingId));
    redirect(site_url('payment/record.php'));
}

$bookingId = $_POST['booking_id'] ?? '';
$amountPaidRaw = $_POST['amount_paid'] ?? '';
$amountPaid = filter_var($amountPaidRaw, FILTER_VALIDATE_FLOAT);
$paymentMethod = $_POST['payment_method'] ?? 'cash';
$allowed_methods = ['cash'];
if (!is_string($paymentMethod) || !in_array(strtolower($paymentMethod), $allowed_methods, true)) {
    set_flash('Invalid payment method.', 'danger');
    $bookingIdInt = is_numeric($bookingId) ? (int)$bookingId : 0;
    if ($bookingIdInt > 0) redirect(site_url('payment/record.php?booking_id=' . $bookingIdInt));
    redirect(site_url('payment/record.php'));
}
$paymentMethod = strtolower($paymentMethod);

$orNumber = trim($_POST['or_number'] ?? '');
$notes = trim($_POST['notes'] ?? '');

if (empty($bookingId)) {
    set_flash('Booking is required.', 'danger');
    redirect(site_url('payment/record.php'));
}

if ($amountPaid === false || $amountPaid <= 0) {
    set_flash('Amount paid must be a valid number greater than zero.', 'danger');
    redirect(site_url('payment/record.php?booking_id=' . (int)$bookingId));
}

if (empty($orNumber)) {
    set_flash('Official Receipt (OR) number is required.', 'danger');
    redirect(site_url('payment/record.php?booking_id=' . (int)$bookingId));
}

// Query block: reads from payments.
$dupStmt = mysqli_prepare($conn, "SELECT payment_id FROM payments WHERE or_number = ? LIMIT 1");
mysqli_stmt_bind_param($dupStmt, 's', $orNumber);
mysqli_stmt_execute($dupStmt);
$dupResult = mysqli_stmt_get_result($dupStmt);
if (mysqli_num_rows($dupResult) > 0) {
    set_flash('OR number is already used. Please enter a unique receipt number.', 'danger');
    redirect(site_url('payment/record.php?booking_id=' . (int)$bookingId));
}

// Query block: reads from bookings.
$bkStmt = mysqli_prepare($conn, "SELECT booking_id, status, user_id, event_name, total_amount FROM bookings WHERE booking_id = ? LIMIT 1");
mysqli_stmt_bind_param($bkStmt, 'i', $bookingId);
mysqli_stmt_execute($bkStmt);
$bkResult = mysqli_stmt_get_result($bkStmt);
$booking = mysqli_fetch_assoc($bkResult);

if (!$booking) {
    set_flash('Booking not found.', 'danger');
    redirect(site_url('payment/record.php'));
}

$collectedBy = $_SESSION['user_id'];

// Save block: inserts into payments.
$insStmt = mysqli_prepare($conn, "INSERT INTO payments (booking_id, amount_paid, payment_method, payment_date, collected_by, or_number, notes)
                                   VALUES (?, ?, 'cash', NOW(), ?, ?, ?)");
mysqli_stmt_bind_param($insStmt, 'idiss', $bookingId, $amountPaid, $collectedBy, $orNumber, $notes);
mysqli_stmt_execute($insStmt);
$paymentId = mysqli_insert_id($conn);

$currentStatus = $booking['status'];
$newStatus = $currentStatus;
if ($currentStatus === 'pending' || $currentStatus === 'confirmed') {
    $newStatus = 'paid';
}

if ($newStatus !== $currentStatus) {
    // Update block: changes rows in bookings.
    $updStmt = mysqli_prepare($conn, "UPDATE bookings SET status = ? WHERE booking_id = ?");
    mysqli_stmt_bind_param($updStmt, 'si', $newStatus, $bookingId);
    mysqli_stmt_execute($updStmt);
}

require_once __DIR__ . '/../includes/mailer.php';

$send = snapit_send_order_status_email($conn, $bookingId, 'payment_received', [
    'or_number'   => $orNumber,
    'amount_paid' => $amountPaid,
]);

// Query block: reads from users.
$adminStmt = mysqli_prepare($conn, "SELECT user_id, email, name FROM users WHERE role = 'admin' LIMIT 1");
mysqli_stmt_execute($adminStmt);
$adminResult = mysqli_stmt_get_result($adminStmt);
$admin = mysqli_fetch_assoc($adminResult);

if ($admin) {
    $eventName = $booking['event_name'];
    $adminSubject = "New Payment Recorded - Booking #$bookingId";
    $adminMessage = "A new payment has been recorded:\n\n"
        . "Booking #$bookingId: $eventName\n"
        . "Customer ID: #" . (int)$booking['user_id'] . "\n"
        . "Amount: " . format_money($amountPaid) . "\n"
        . "OR Number: $orNumber\n"
        . "Collected by: " . ($_SESSION['name'] ?? 'Staff') . "\n"
        . "Date: " . date('M j, Y h:i A');

    // Save block: inserts into notifications.
    $notifAdminStmt = mysqli_prepare($conn, "INSERT INTO notifications (booking_id, user_id, type, recipient_email, subject, message_body, status, created_at)
                                               VALUES (?, ?, 'payment_received', ?, ?, ?, 'pending', NOW())");
    $adminUid = (int)$admin['user_id'];
    mysqli_stmt_bind_param($notifAdminStmt, 'iisss', $bookingId, $adminUid, $admin['email'], $adminSubject, $adminMessage);
    mysqli_stmt_execute($notifAdminStmt);
}

snapit_mail_flash('Payment recorded successfully.', $send);
redirect(site_url('payment/receipt.php?id=' . $paymentId));
