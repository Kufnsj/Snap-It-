<?php
// Booth step 1: the customization page where the guest picks a camera preset, filter, layout and frame, then submits to store_selection.php.
// No JavaScript is used here: the choices are plain radio buttons and the highlight comes from CSS (:checked).
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
// Guard block: only logged-in users may open the booth customization page.
require_login();

// Session block: finds the guest's active booth session, or sends them back to the booking list.
$session_id = current_booth_session_id($conn);
if (!$session_id) {
    set_flash('No active session found. Start a new session.', 'warning');
    redirect(site_url('booth/index.php'));
}

// Idle-timer block: opening/saving the customization page counts as activity, so the guest is not timed out while choosing.
booth_touch_session($conn, $session_id);

// Data block: loads the active presets, filters, layouts and frame designs shown as choices on this page.
$presets = mysqli_query($conn, "SELECT * FROM camera_presets WHERE is_active = 1 ORDER BY preset_id ASC");
$filters = mysqli_query($conn, "SELECT * FROM filters WHERE is_active = 1 ORDER BY filter_id ASC");
$layouts = mysqli_query($conn, "SELECT * FROM layouts WHERE is_active = 1 ORDER BY photo_count ASC");
$frames  = mysqli_query($conn, "SELECT * FROM frame_designs WHERE is_active = 1 ORDER BY design_id ASC");

// Default-choice block: remembers the first option of each category so it is pre-selected when the page opens.
$first_preset = mysqli_fetch_assoc(mysqli_query($conn, "SELECT preset_id FROM camera_presets WHERE is_active = 1 ORDER BY preset_id ASC LIMIT 1"));
$first_filter = mysqli_fetch_assoc(mysqli_query($conn, "SELECT filter_id FROM filters WHERE is_active = 1 ORDER BY filter_id ASC LIMIT 1"));
$first_layout = mysqli_fetch_assoc(mysqli_query($conn, "SELECT layout_id FROM layouts WHERE is_active = 1 ORDER BY photo_count ASC LIMIT 1"));
$first_frame  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT design_id FROM frame_designs WHERE is_active = 1 ORDER BY design_id ASC LIMIT 1"));

// Page layout block: site header (navbar) and flash-message area.
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/alert.php';
?>

<!-- Page title block: heading and short instruction -->
<div class="container py-4">
    <div class="text-center mb-3">
        <h2 class="fw-bold">
            <i class="fa-solid fa-wand-magic-sparkles me-2"></i>Customize Your Booth
        </h2>
        <p class="text-muted mb-0">Choose your preset, filter, layout, and frame design.</p>
    </div>

    <!-- Step shortcuts: plain anchor links that jump to each selection card (no JavaScript) -->
    <div class="step-indicator no-print">
        <a class="step active" href="#step-preset">1</a>
        <a class="step" href="#step-filter">2</a>
        <a class="step" href="#step-layout">3</a>
        <a class="step" href="#step-frame">4</a>
    </div>

    <!-- Selection form: posts the four chosen options and the CSRF token to store_selection.php -->
    <form method="POST" action="<?= e(site_url('booth/store_selection.php')) ?>" id="selectionForm">
        <div class="row g-4">
            <div class="col-lg-7">

                <!-- Card 1: camera preset choices (radio buttons with a sample photo each) -->
                <div class="card p-3 mb-4" id="step-preset">
                    <div class="card-header bg-transparent border-bottom mb-3">
                        <h5 class="fw-bold mb-0"><i class="fa-solid fa-sliders me-2"></i>1. Camera Presets</h5>
                    </div>
                    <div class="row g-3">
                        <?php while ($p = mysqli_fetch_assoc($presets)): ?>
                            <label class="col-md-6 col-lg-4">
                                <input type="radio" name="preset_id" value="<?= (int)$p['preset_id'] ?>"
                                       class="d-none preset-radio"
                                       <?= $first_preset && $p['preset_id'] == $first_preset['preset_id'] ? 'checked' : '' ?>>
                                <div class="preset-card">
                                    <div class="fw-bold mb-1"><?= e($p['name']) ?></div>
                                    <?php $cam_img = camera_photo_url($p['name']); ?>
                                    <div class="preset-photo-wrap">
                                        <?php if ($cam_img): ?>
                                            <img src="<?= e($cam_img) ?>" alt="<?= e($p['name']) ?>" class="preset-photo" loading="lazy">
                                        <?php else: ?>
                                            <i class="fa-solid fa-camera preset-photo-icon"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="small text-muted"><?= e($p['description'] ?? '') ?></div>
                                </div>
                            </label>
                        <?php endwhile; ?>
                    </div>
                </div>

                <!-- Card 2: filter choices (radio buttons; the swatch is previewed with the filter's own CSS) -->
                <div class="card p-3 mb-4" id="step-filter">
                    <div class="card-header bg-transparent border-bottom mb-3">
                        <h5 class="fw-bold mb-0"><i class="fa-solid fa-palette me-2"></i>2. Filters</h5>
                    </div>
                    <div class="row g-3">
                        <?php while ($f = mysqli_fetch_assoc($filters)): ?>
                            <label class="col-md-6 col-lg-4">
                                <input type="radio" name="filter_id" value="<?= (int)$f['filter_id'] ?>"
                                       class="d-none filter-radio"
                                       <?= $first_filter && $f['filter_id'] == $first_filter['filter_id'] ? 'checked' : '' ?>>
                                <div class="filter-card">
                                    <div class="filter-preview" style="background-image:url('<?= e(site_url('includes/img/filter_sample.svg')) ?>');background-size:cover;background-position:center;filter:<?= e($f['css_filter']) ?>"></div>
                                    <div class="fw-bold"><?= e($f['name']) ?></div>
                                </div>
                            </label>
                        <?php endwhile; ?>
                    </div>
                </div>

                <!-- Card 3: layout choices (radio buttons; a small grid drawn by PHP shows the photo arrangement) -->
                <div class="card p-3 mb-4" id="step-layout">
                    <div class="card-header bg-transparent border-bottom mb-3">
                        <h5 class="fw-bold mb-0"><i class="fa-solid fa-table-cells me-2"></i>3. Layouts</h5>
                    </div>
                    <div class="row g-3">
                        <?php while ($L = mysqli_fetch_assoc($layouts)): ?>
                            <label class="col-md-6 col-lg-4">
                                <input type="radio" name="layout_id" value="<?= (int)$L['layout_id'] ?>"
                                       class="d-none layout-radio"
                                       <?= $first_layout && $L['layout_id'] == $first_layout['layout_id'] ? 'checked' : '' ?>>
                                <div class="layout-card">
                                    <div class="mb-2">
                                        <?php
                                        $ps = explode('x', $L['print_size'] ?: '3x2'); $mw = ((int)$ps[0] <= 2) ? 44 : 64;
$items = str_repeat('<div style="background:#d8c09a;border-radius:3px;"></div>', (int)$L['photo_count']);
echo '<div style="display:grid;gap:3px;margin:0 auto;padding:4px;border:1px solid #ddd;max-width:' . $mw . 'px;aspect-ratio:' . (int)$ps[0] . '/' . (int)$ps[1] . ';grid-template-columns:repeat(' . (int)$L['grid_cols'] . ',1fr);grid-template-rows:repeat(' . (int)$L['grid_rows'] . ',1fr);">' . $items . '</div>';
                                        ?>
                                    </div>
                                    <div class="fw-bold mb-0"><?= e($L['name']) ?></div>
                                    <div class="small text-muted"><?= (int)$L['photo_count'] ?> photos</div>
                                </div>
                            </label>
                        <?php endwhile; ?>
                    </div>
                </div>

                <!-- Card 4: frame design choices (radio buttons; each shows its border colour, width and background) -->
                <div class="card p-3 mb-4" id="step-frame">
                    <div class="card-header bg-transparent border-bottom mb-3">
                        <h5 class="fw-bold mb-0"><i class="fa-regular fa-image me-2"></i>4. Frame Designs</h5>
                    </div>
                    <div class="row g-3">
                        <?php while ($fr = mysqli_fetch_assoc($frames)): ?>
                            <label class="col-md-6 col-lg-4">
                                <input type="radio" name="design_id" value="<?= (int)$fr['design_id'] ?>"
                                       class="d-none frame-radio"
                                       <?= $first_frame && $fr['design_id'] == $first_frame['design_id'] ? 'checked' : '' ?>>
                                <div class="frame-card">
                                    <div style="border:<?= (int)$fr['border_width'] ?>px solid <?= e($fr['border_color']) ?>;border-radius:10px;height:90px;background:<?= e($fr['bg_color']) ?>;display:flex;align-items:center;justify-content:center;margin-bottom:6px;">
                                        <i class="fa-regular fa-image text-muted"></i>
                                    </div>
                                    <div class="fw-bold"><?= e($fr['name']) ?></div>
                                    <div class="small text-muted"><?= (int)$fr['border_width'] ?>px border</div>
                                </div>
                            </label>
                        <?php endwhile; ?>
                    </div>
                </div>

            </div>

            <!-- Right column: explanation card with the "Start Capturing" submit button and a back link -->
            <div class="col-lg-5">
                <div class="sticky-top" style="top:1rem;">
                    <div class="card p-4">
                        <!-- Sidebar summary: explains the next step; the camera itself opens on the next page -->
                        <h5 class="fw-bold mb-3 text-center"><i class="fa-regular fa-circle-info me-2"></i>How it works</h5>
                        <p class="text-muted small mb-0 text-center">
                            Pick one option in each of the four cards, then press <strong>Start Capturing</strong>.
                            The camera opens on the next page with your preset and filter already applied.
                        </p>
                        <div class="d-grid gap-2 mt-4">
                            <button type="submit" class="btn btn-snapit btn-lg fw-semibold">
                                <i class="fa-solid fa-camera me-2"></i>Start Capturing
                            </button>
                            <a href="<?= e(site_url('booth/index.php')) ?>" class="btn btn-outline-secondary">
                                <i class="fa-solid fa-arrow-left me-1"></i>Back to bookings
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Security block: CSRF token checked by store_selection.php -->
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    </form>
</div>


<?php include __DIR__ . '/../includes/footer.php'; ?>
