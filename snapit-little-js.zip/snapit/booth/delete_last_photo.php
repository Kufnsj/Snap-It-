<?php
// Booth handler: removes the guest's most recent photo (used by both "Retake Photo" and "Back"). Replaces ajax_delete_photo.php.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';

// Guard block: login required.
require_login();

// Request + security block: POST with a valid CSRF token only.
require_post_csrf(site_url('booth/session.php'));

// Session block: finds the guest's active booth session.
$session_id = current_booth_session_id($conn);
if (!$session_id) {
    set_flash('No active session found.', 'warning');
    redirect(site_url('booth/index.php'));
}

// Lookup block: finds the newest kept photo of this session.
$stmt = mysqli_prepare($conn, "SELECT photo_id, photo_path FROM session_photos WHERE session_id = ? AND is_kept = 1 ORDER BY order_index DESC, photo_id DESC LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $session_id);
mysqli_stmt_execute($stmt);
$last = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Delete block: removes the database row and (only if the path is inside this session's folder) the image file.
if ($last) {
    // Delete block: removes rows from session_photos.
    $del = mysqli_prepare($conn, "DELETE FROM session_photos WHERE photo_id = ? AND session_id = ?");
    $pid = (int)$last['photo_id'];
    mysqli_stmt_bind_param($del, 'ii', $pid, $session_id);
    mysqli_stmt_execute($del);
    $rel = photo_rel_path($last['photo_path']);
    if ($rel && strpos($rel, 'uploads/sessions/sess_' . $session_id . '/') === 0 && strpos($rel, '..') === false) {
        $abs = __DIR__ . '/../' . $rel;
        if (is_file($abs)) @unlink($abs);
    }
}

// Finish block: renews the idle timer. "Back" with no photos left returns to the selections page, otherwise the camera reopens.
booth_touch_session($conn, $session_id);
$remaining = (int)mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM session_photos WHERE session_id = " . (int)$session_id . " AND is_kept = 1"))[0];
if (($_POST['action'] ?? '') === 'back' && $remaining === 0) {
    redirect(site_url('booth/capture.php'));
}
redirect(site_url('booth/session.php'));
