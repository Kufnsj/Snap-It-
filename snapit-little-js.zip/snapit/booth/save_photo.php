<?php
// Booth handler: saves ONE captured photo. booth_camera.js posts the webcam picture here as a normal form (image_data).
// PHP then applies the guest's preset + filter + mirror with GD (includes/photo_fx.php), saves the file and shows Keep / Retake.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/photo_fx.php';

// Guard block: login required.
require_login();

// Request + security block: must be a POST with a valid CSRF token, otherwise go back to the camera page.
require_post_csrf(site_url('booth/session.php'));

// Session block: finds the guest's active booth session.
$session_id = current_booth_session_id($conn);
if (!$session_id) {
    set_flash('No active session found. Start a new session.', 'warning');
    redirect(site_url('booth/index.php'));
}

// Limit block: how many photos does the chosen layout need, and how many are already kept?
$stmt = mysqli_prepare($conn, "SELECT l.photo_count, (SELECT COUNT(*) FROM session_photos sp WHERE sp.session_id = gs.session_id AND sp.is_kept = 1) AS kept
    FROM guest_sessions gs LEFT JOIN layouts l ON gs.layout_id = l.layout_id WHERE gs.session_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $session_id);
mysqli_stmt_execute($stmt);
$info = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
$target_n = (int)($info['photo_count'] ?? 0);
$kept     = (int)($info['kept'] ?? 0);
if ($target_n <= 0 || $kept >= $target_n) {
    redirect(site_url('booth/session.php'));
}

// Image-decoding block: turns the posted "data:image/jpeg;base64,..." text into real image bytes and checks it is a picture.
$image_data = trim($_POST['image_data'] ?? '');
$comma = strpos($image_data, ',');
if (strpos($image_data, 'data:image/') !== 0 || $comma === false) {
    set_flash('The photo could not be read. Please try again.', 'danger');
    redirect(site_url('booth/session.php'));
}
$decoded = base64_decode(str_replace(' ', '+', substr($image_data, $comma + 1)), true);
$info_img = $decoded !== false ? @getimagesizefromstring($decoded) : false;
if (!$info_img || !in_array($info_img['mime'], ['image/jpeg', 'image/png', 'image/webp'], true)) {
    set_flash('The photo was not a valid JPEG, PNG or WebP image.', 'danger');
    redirect(site_url('booth/session.php'));
}

// Folder block: uploads/sessions/sess_<id>/
$sess_dir = __DIR__ . '/../uploads/sessions/sess_' . $session_id;
if (!is_dir($sess_dir) && !@mkdir($sess_dir, 0755, true)) {
    set_flash('Could not create the photo folder on the server.', 'danger');
    redirect(site_url('booth/session.php'));
}

// Look block: the raw picture is saved in a temporary file, PHP applies the look, the temporary file is deleted.
$raw = $sess_dir . '/raw_' . bin2hex(random_bytes(4)) . '.img';
$filename = 'photo_' . $kept . '_' . bin2hex(random_bytes(6)) . '.jpg';
$done = false;
if (@file_put_contents($raw, $decoded) !== false) {
    $look = booth_session_look($conn, $session_id);
    $done = photo_fx_process_file($raw, $sess_dir . '/' . $filename, $look ?: ['css' => '']);
}
@unlink($raw);
if (!$done) {
    set_flash('The photo could not be processed. Please try again.', 'danger');
    redirect(site_url('booth/session.php'));
}

// Database block: records the photo as kept, in the next free slot.
$relative_path = 'uploads/sessions/sess_' . $session_id . '/' . $filename;
$stmt = mysqli_prepare($conn, "INSERT INTO session_photos (session_id, photo_path, order_index, is_kept, created_at) VALUES (?, ?, ?, 1, NOW())");
mysqli_stmt_bind_param($stmt, 'isi', $session_id, $relative_path, $kept);
if (!mysqli_stmt_execute($stmt)) {
    @unlink($sess_dir . '/' . $filename);
    set_flash('Could not record the photo. Please try again.', 'danger');
    redirect(site_url('booth/session.php'));
}

// Finish block: renews the idle timer and shows the new photo so the guest can keep or retake it.
booth_touch_session($conn, $session_id);
redirect(site_url('booth/session.php?review=1'));
