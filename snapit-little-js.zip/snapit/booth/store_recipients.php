<?php
// Booth handler: saves the recipient email addresses and sends them the photos.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
// Guard block: only logged-in users can use this page.
require_login();

// Request check block: only POST form submissions are accepted here.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(site_url('booth/index.php'));
}

// Security block: rejects forms without a valid CSRF token.
if (!isset($_POST['csrf_token']) || !verify_csrf($_POST['csrf_token'])) {
    set_flash('Invalid security token. Please refresh the page and try again.', 'danger');
    $sid = isset($_POST['sid']) ? (int)$_POST['sid'] : 0;
    if ($sid > 0) redirect(site_url('booth/done.php?sid=' . $sid));
    redirect(site_url('booth/index.php'));
}

$sid = (int)($_POST['sid'] ?? 0);
if ($sid <= 0) {
    set_flash('Invalid session reference.', 'warning');
    redirect(site_url('booth/index.php'));
}

// Query block: reads from the database.
$stmt = mysqli_prepare($conn, "SELECT gs.session_id, gs.booking_id, gs.guest_name, b.user_id AS booking_user, b.event_name, b.softcopy_addon, u.name AS customer_name, u.email AS customer_email
                               FROM guest_sessions gs
                               LEFT JOIN bookings b ON gs.booking_id = b.booking_id
                               LEFT JOIN users u ON b.user_id = u.user_id
                               WHERE gs.session_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $sid);
mysqli_stmt_execute($stmt);
$sess = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$sess) {
    set_flash('Session not found.', 'warning');
    redirect(site_url('booth/index.php'));
}

if (is_customer() && (int)$sess['booking_user'] !== (int)$_SESSION['user_id']) {
    set_flash('You do not have permission to modify this booking.', 'danger');
    redirect(site_url('booth/index.php'));
}

require_once __DIR__ . '/../includes/mailer.php';

$booking_id = (int)$sess['booking_id'];
// Query block: reads from session_photos.
$pStmt = mysqli_prepare($conn, "SELECT photo_path FROM session_photos WHERE session_id = ? AND is_kept = 1 ORDER BY order_index ASC");
mysqli_stmt_bind_param($pStmt, 'i', $sid);
mysqli_stmt_execute($pStmt);
$pRes = mysqli_stmt_get_result($pStmt);
$photos = [];
while ($pr = mysqli_fetch_assoc($pRes)) $photos[] = $pr;
mysqli_stmt_close($pStmt);

$galleryUrl = snapit_build_full_url('gallery/view_booking.php?id=' . $booking_id);

$saved = 0;
$sentCount = 0;
$failedCount = 0;

mysqli_begin_transaction($conn);
try {
    for ($i = 1; $i <= 10; $i++) {
        $email = trim($_POST['email' . $i] ?? '');
        if ($email === '') continue;
        if (!valid_email($email)) continue;

        // Query block: reads from delivery_recipients.
        $check = mysqli_prepare($conn, "SELECT recipient_id FROM delivery_recipients WHERE session_id = ? AND email = ? LIMIT 1");
        mysqli_stmt_bind_param($check, 'is', $sid, $email);
        mysqli_stmt_execute($check);
        if (mysqli_num_rows(mysqli_stmt_get_result($check)) > 0) continue;

        $send = snapit_send_booth_softcopy_email($email, $sess, $sess, $photos, $galleryUrl);
        $sentAt = !empty($send['ok']) ? date('Y-m-d H:i:s') : null;
        $err = mb_substr((string)($send['detail'] ?? $send['error'] ?? ''), 0, 1000);
        $mid = mb_substr((string)($send['message_id'] ?? ''), 0, 255);

        if (!empty($send['ok'])) $sentCount++; else $failedCount++;

        // Save block: inserts into delivery_recipients.
        $ins = mysqli_prepare($conn, "INSERT INTO delivery_recipients (booking_id, session_id, email, sent_at, error_detail, message_id, created_at)
                                      VALUES (?, ?, ?, ?, ?, ?, NOW())");
        mysqli_stmt_bind_param($ins, 'iissss', $booking_id, $sid, $email, $sentAt, $err, $mid);
        mysqli_stmt_execute($ins);
        $saved++;
    }

    if ($saved > 0) {
        $notifStatus = ($failedCount === 0) ? 'sent' : (($sentCount > 0) ? 'partial' : 'failed');
        // Save block: inserts into notifications.
        $notif = mysqli_prepare($conn, "INSERT INTO notifications (booking_id, user_id, type, subject, message_body, status, sent_at, created_at)
                                        VALUES (?, ?, 'softcopy_sent', ?, ?, ?, NOW(), NOW())");
        $subject = 'Softcopy photos dispatched for Session #' . $sid;
        $body = $sentCount . ' of ' . $saved . ' recipient(s) dispatched for session #' . $sid . ' (booking #' . $booking_id . ').';
        $bUser = (int)($sess['booking_user'] ?? 0);
        mysqli_stmt_bind_param($notif, 'iisss', $booking_id, $bUser, $subject, $body, $notifStatus);
        mysqli_stmt_execute($notif);
    }

    mysqli_commit($conn);
} catch (Exception $e) {
    mysqli_rollback($conn);
    set_flash('An error occurred while saving recipients: ' . $e->getMessage(), 'danger');
    redirect(site_url('booth/done.php?sid=' . $sid));
}

if ($saved === 0) {
    set_flash('No valid new email addresses provided.', 'warning');
} else {
    $msg = $sentCount . ' recipient(s) sent successfully.';
    if ($failedCount > 0) $msg .= ' (' . $failedCount . ' failed delivery).';
    set_flash($msg, $sentCount > 0 ? 'success' : 'warning');
}

redirect(site_url('booth/done.php?sid=' . $sid));
