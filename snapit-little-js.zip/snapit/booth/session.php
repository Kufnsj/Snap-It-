<?php
// Booth step 2: the photo-taking page. PHP decides which of three screens to show:
//   camera screen  (more photos still needed)  ->  review screen (just captured, keep or retake)  ->  complete screen (all photos kept).
// The only JavaScript is includes/booth_camera.js (about 25 lines): it opens the webcam, shows the live preview, counts down and posts the snapshot to save_photo.php.
// The live filter, mirror and film effects on the preview are plain CSS written by PHP; the saved photo gets its filter from PHP (includes/photo_fx.php).
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/photo_fx.php';

// Guard block: login required.
require_login();

// Session block: finds the guest's active booth session, or sends them back to the booking list.
$session_id = current_booth_session_id($conn);
if (!$session_id) {
    set_flash('No active session found. Start a new session.', 'warning');
    redirect(site_url('booth/index.php'));
}

// Session-data block: loads the session with the chosen preset, filter, layout, frame and event name.
$stmt = mysqli_prepare($conn, "SELECT gs.*, 
    (gs.idle_timeout_at IS NOT NULL AND gs.idle_timeout_at < NOW()) AS idle_expired,
    cp.name AS preset_name, cp.brightness AS p_bri, cp.contrast AS p_con, cp.saturation AS p_sat, cp.warmness AS p_wrm, cp.cam_filter, cp.fx_grain, cp.fx_vignette, cp.fx_fade,
    f.name AS filter_name, f.css_filter,
    l.name AS layout_name, l.photo_count, l.grid_cols, l.grid_rows,
    fd.name AS frame_name, fd.border_color, fd.border_width, fd.bg_color, fd.text_color, fd.photo_gap, fd.photo_radius, fd.pattern, l.print_size,
    b.event_name
    FROM guest_sessions gs
    LEFT JOIN camera_presets cp ON gs.camera_preset_id = cp.preset_id
    LEFT JOIN filters f ON gs.filter_id = f.filter_id
    LEFT JOIN layouts l ON gs.layout_id = l.layout_id
    LEFT JOIN frame_designs fd ON gs.frame_design_id = fd.design_id
    LEFT JOIN bookings b ON gs.booking_id = b.booking_id
    WHERE gs.session_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $session_id);
mysqli_stmt_execute($stmt);
$session = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Selections check block: the guest must finish the customization page first.
if (!$session || !$session['photo_count']) {
    set_flash('Please configure your booth selections first.', 'warning');
    redirect(site_url('booth/capture.php'));
}

// Idle-timeout block: a session left untouched too long is closed by end_session.php (this replaces the old JavaScript idle countdown).
if (!empty($session['idle_expired'])) {
    redirect(site_url('booth/end_session.php?auto=1'));
}
booth_touch_session($conn, $session_id);

// Photos block: loads the photos already kept for this session.
$target_n = (int)$session['photo_count'];
// Query block: reads from session_photos.
$photos_stmt = mysqli_prepare($conn, "SELECT * FROM session_photos WHERE session_id = ? AND is_kept = 1 ORDER BY order_index ASC");
mysqli_stmt_bind_param($photos_stmt, 'i', $session_id);
mysqli_stmt_execute($photos_stmt);
$photo_rows = [];
$photos = mysqli_stmt_get_result($photos_stmt);
while ($ph = mysqli_fetch_assoc($photos)) {
    $photo_rows[] = $ph;
}
$photo_count = count($photo_rows);

// Screen-choice block: decides which screen to show from the photo count and the ?review=1 flag set by save_photo.php.
$is_complete = $photo_count >= $target_n;
$is_review   = isset($_GET['review']) && $photo_count > 0;
$show_camera = !$is_complete && !$is_review;

// Settings block: countdown seconds and mirror choice saved by booth_settings.php.
$countdown_seconds = (int)($session['countdown_seconds'] ?? 3);
if (!in_array($countdown_seconds, [3, 5, 10], true)) $countdown_seconds = 3;
$mirror_preview = (int)($session['mirror_preview'] ?? 1) === 1 ? 1 : 0;

// Look block: the guest's preset + filter as CSS text, used for the live preview (the saved photo gets the same look from PHP).
$look = photo_fx_look_from_row($session);
$grain_svg = "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='2'/></filter><rect width='200' height='200' filter='url(%23n)'/></svg>\")";

// Strip block: the finished photo-strip HTML (frame, layout and filter applied) drawn by PHP for the review and complete screens.
$strip_caption = $session['event_name'] . ' · ' . date('M j, Y');

// Page layout block: site header (navbar) and flash-message area.
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/alert.php';
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-10">

            <!-- Info bar block: shows the guest, preset, filter, layout and frame of this session -->
            <div class="card shadow-sm border-0 p-3 mb-3 no-print">
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <span class="badge bg-primary"><i class="fa-solid fa-user me-1"></i><?= e($session['guest_name'] ?: 'Guest #' . $session_id) ?></span>
                    <span class="badge badge-snapit"><i class="fa-solid fa-sliders me-1"></i><?= e($session['preset_name'] ?? 'Default') ?></span>
                    <span class="badge" style="background:var(--snapit-secondary);color:#fff;"><i class="fa-solid fa-palette me-1"></i><?= e($session['filter_name'] ?? 'None') ?></span>
                    <span class="badge bg-info text-dark"><i class="fa-solid fa-table-cells me-1"></i><?= e($session['layout_name'] ?? 'Solo') ?></span>
                    <span class="badge bg-secondary"><i class="fa-regular fa-image me-1"></i><?= e($session['frame_name'] ?? 'Plain') ?></span>
                </div>
                <div class="small text-muted mt-1">
                    <i class="fa-regular fa-calendar-check me-1"></i><?= e($session['event_name']) ?> &bull; Session #<?= (int)$session_id ?>
                    &bull; <i class="fa-regular fa-clock me-1"></i>Closes after <?= (int)BOOTH_IDLE_MINUTES ?> minutes of inactivity
                </div>
            </div>

            <!-- Progress block: "Photo X of N" bar calculated by PHP -->
            <div class="progress mb-3 no-print" style="height:28px;border-radius:14px;">
                <?php $pct = min(100, ($photo_count / max(1, $target_n)) * 100); ?>
                <div class="progress-bar progress-bar-striped" role="progressbar"
                     style="width: <?= $pct ?>%;background:linear-gradient(90deg,var(--snapit-primary),var(--snapit-secondary));">
                    <span class="fw-bold px-2">Photo <?= (int)min($photo_count + 1, $target_n) ?> of <?= (int)$target_n ?></span>
                </div>
            </div>

            <?php if ($show_camera): ?>
                <!-- Settings block: countdown length and mirror toggle; each button is a plain form submit handled by booth_settings.php -->
                <form method="POST" action="<?= e(site_url('booth/booth_settings.php')) ?>" class="booth-controls no-print">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <div class="d-flex align-items-center gap-2">
                        <span class="booth-ctl-label"><i class="fa-regular fa-clock me-1"></i>Timer</span>
                        <div class="cd-group" role="group" aria-label="Countdown timer">
                            <?php foreach ([3, 5, 10] as $cdOpt): ?>
                                <button type="submit" name="countdown" value="<?= $cdOpt ?>" class="cd-pill<?= $cdOpt === $countdown_seconds ? ' active' : '' ?>"><?= $cdOpt ?>s</button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <button type="submit" name="mirror" value="<?= $mirror_preview ? 0 : 1 ?>" class="mirror-toggle<?= $mirror_preview ? ' active' : '' ?>" title="Flip camera view">
                        <i class="fa-solid fa-camera-rotate me-1"></i>Mirror: <?= $mirror_preview ? 'On' : 'Off' ?>
                    </button>
                </form>
            <?php endif; ?>

            <div class="position-relative mb-4">
                <div class="booth-frame" style="border-color:<?= e($session['border_color']) ?>;border-width:<?= (int)$session['border_width'] ?>px;">

                    <?php if ($show_camera): ?>
                        <div class="w-100">
                        <!-- Camera block: the live video. Its filter and mirror are CSS written by PHP; the grain, fade and vignette are CSS layers on top. -->
                        <div style="position:relative;width:100%;line-height:0;border-radius:16px;overflow:hidden;">
                            <video id="cameraVideo" autoplay playsinline muted
                                   style="width:100%;max-height:560px;object-fit:contain;background:#000;filter:<?= e($look['css']) ?>;<?= $mirror_preview ? 'transform:scaleX(-1);' : '' ?>"></video>
                            <?php if ($look['fade'] > 0): ?><div style="position:absolute;inset:0;pointer-events:none;background:rgba(40,36,32,<?= $look['fade'] / 100 ?>);mix-blend-mode:screen;"></div><?php endif; ?>
                            <?php if ($look['grain'] > 0): ?><div style="position:absolute;inset:0;pointer-events:none;background:<?= e($grain_svg) ?>;opacity:<?= $look['grain'] / 100 * 0.6 ?>;mix-blend-mode:overlay;"></div><?php endif; ?>
                            <?php if ($look['vignette'] > 0): ?><div style="position:absolute;inset:0;pointer-events:none;background:radial-gradient(ellipse at center,transparent 55%,rgba(0,0,0,<?= $look['vignette'] / 100 * 0.9 ?>) 100%);"></div><?php endif; ?>
                            <div id="countdown" class="countdown-big" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;"></div>
                        </div>
                        <p id="cameraMsg" class="text-center text-muted my-3 small">Allow the camera when the browser asks. The picture is saved with the same look you see here.</p>
                        </div>
                    <?php else: ?>
                        <!-- Strip screen block: the photos taken so far inside the chosen frame and layout (built by PHP) -->
                        <div class="w-100"><?= strip_html(array_column($photo_rows, 'photo_path'), strip_cfg($session, $strip_caption)) ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($show_camera): ?>
                <!-- Capture block: a normal form. booth_camera.js fills in image_data and submits it to save_photo.php (PHP applies the filter and saves). -->
                <form id="captureForm" method="POST" action="<?= e(site_url('booth/save_photo.php')) ?>" data-countdown="<?= (int)$countdown_seconds ?>" class="text-center no-print mb-4">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="image_data" value="">
                    <button type="button" id="captureBtn" class="btn btn-snapit btn-lg px-5 py-4 fw-bold shadow-lg" style="font-size:1.25rem;min-width:260px;border-radius:18px;" disabled>
                        <i class="fa-solid fa-camera me-2 fa-xl"></i><?= $photo_count === 0 ? 'Start Capturing' : 'Next Photo' ?>
                    </button>
                </form>
            <?php endif; ?>

            <?php if ($is_review): ?>
                <!-- Review block: keep the photo (just continue, or finish if it was the last one) or retake it (delete it and take another) -->
                <div class="card p-3 mb-4 no-print">
                    <div class="text-center mb-2 fw-semibold"><i class="fa-regular fa-circle-question me-1"></i>Keep this photo or retake?</div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <!-- Form block: posts the entered data to booth/delete_last_photo.php -->
                            <form method="POST" action="<?= e(site_url('booth/delete_last_photo.php')) ?>">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="retake">
                                <button type="submit" class="btn btn-outline-warning w-100 py-3 fw-semibold"><i class="fa-solid fa-rotate me-1"></i>Retake Photo</button>
                            </form>
                        </div>
                        <div class="col-md-6">
                            <a href="<?= e(site_url('booth/session.php')) ?>" class="btn btn-outline-success w-100 py-3 fw-semibold"><i class="fa-solid fa-check me-1"></i>Keep Photo</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!$is_review): ?>
            <!-- Navigation block: Back (removes the last photo) or back to selections, plus the Done button shown only when all photos are kept -->
            <div class="row g-3 no-print">
                <div class="col-md-6">
                    <?php if ($photo_count > 0): ?>
                        <!-- Form block: posts the entered data to booth/delete_last_photo.php -->
                        <form method="POST" action="<?= e(site_url('booth/delete_last_photo.php')) ?>">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="back">
                            <button type="submit" class="btn btn-outline-secondary w-100 py-2 fw-semibold"><i class="fa-solid fa-arrow-rotate-left me-1"></i>Back (remove last photo)</button>
                        </form>
                    <?php else: ?>
                        <a href="<?= e(site_url('booth/capture.php')) ?>" class="btn btn-outline-secondary w-100 py-2 fw-semibold"><i class="fa-solid fa-arrow-left me-1"></i>Back to selections</a>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <?php if ($is_complete): ?>
                        <!-- Form block: posts the entered data to booth/end_session.php -->
                        <form method="POST" action="<?= e(site_url('booth/end_session.php')) ?>">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <button type="submit" class="btn btn-success w-100 py-2 fw-semibold"><i class="fa-solid fa-check me-1"></i>Done / New Guest</button>
                            <div class="small text-success fw-semibold text-center mt-2"><i class="fa-solid fa-circle-check me-1"></i>All <?= (int)$target_n ?> photo<?= $target_n !== 1 ? 's' : '' ?> captured &mdash; ready to finish.</div>
                        </form>
                    <?php else: ?>
                        <div class="small text-muted text-center pt-2"><i class="fa-solid fa-circle-info me-1"></i>Capture all <?= (int)$target_n ?> photo<?= $target_n !== 1 ? 's' : '' ?> first (<?= (int)$photo_count ?>/<?= (int)$target_n ?> done).</div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php if ($show_camera): ?>
    <!-- Script block: the one small script of the booth (camera + countdown + snapshot) -->
    <script src="<?= e(site_url('includes/booth_camera.js')) ?>"></script>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
