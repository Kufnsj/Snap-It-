<?php
// Booth handler: saves the guest's countdown length (3 / 5 / 10 seconds) and mirror on/off choice. Replaces the old JavaScript + localStorage settings.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';

// Guard block: login required.
require_login();

// Request + security block: POST with a valid CSRF token only.
require_post_csrf(site_url('booth/session.php'));

// Session block: finds the guest's active booth session.
$session_id = current_booth_session_id($conn);
if (!$session_id) {
    redirect(site_url('booth/index.php'));
}

// Countdown block: only 3, 5 or 10 seconds are accepted.
if (isset($_POST['countdown']) && in_array((int)$_POST['countdown'], [3, 5, 10], true)) {
    $cd = (int)$_POST['countdown'];
    // Update block: changes rows in guest_sessions.
    $stmt = mysqli_prepare($conn, "UPDATE guest_sessions SET countdown_seconds = ? WHERE session_id = ?");
    mysqli_stmt_bind_param($stmt, 'ii', $cd, $session_id);
    mysqli_stmt_execute($stmt);
}

// Mirror block: 1 = mirrored preview (like a selfie), 0 = normal view.
if (isset($_POST['mirror'])) {
    $mi = ((int)$_POST['mirror'] === 1) ? 1 : 0;
    // Update block: changes rows in guest_sessions.
    $stmt = mysqli_prepare($conn, "UPDATE guest_sessions SET mirror_preview = ? WHERE session_id = ?");
    mysqli_stmt_bind_param($stmt, 'ii', $mi, $session_id);
    mysqli_stmt_execute($stmt);
}

// Finish block: renews the idle timer and returns to the camera page.
booth_touch_session($conn, $session_id);
redirect(site_url('booth/session.php'));
