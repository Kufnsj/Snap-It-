<?php
// Admin: form to add or edit a package, including its cover and gallery photos.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
// Guard block: only admins can use this page.
require_admin();

$id = (int)($_GET['id'] ?? 0);
$package = null;
$gallery = [];

if ($id > 0) {
    // Query block: reads from packages.
    $stmt = mysqli_prepare($conn, "SELECT * FROM packages WHERE package_id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $package = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    if (!$package) {
        set_flash('Package not found.', 'danger');
        redirect(site_url('admin/packages.php'));
    }
    $gallery = package_gallery($conn, $id);
}
$is_edit = $package !== null;

// Re-fill after a validation error (set by package_store.php).
$old = $_SESSION['package_form_old'] ?? null;
unset($_SESSION['package_form_old']);
$val = function ($k, $default = '') use ($old, $package) {
    if (is_array($old) && array_key_exists($k, $old)) return $old[$k];
    return $package[$k] ?? $default;
};
$cover = $is_edit ? package_photo_url($package['image_path'] ?? null) : null;
$slots_left = max(0, PACKAGE_MAX_GALLERY - count($gallery));

// Page layout block: site header (navbar) and flash-message area.
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/alert.php';
?>

<section class="container py-4" style="max-width:860px">
    <h1 class="fw-bold mb-4">
        <i class="fa-solid <?= $is_edit ? 'fa-pen-to-square' : 'fa-plus' ?> me-2"></i><?= $is_edit ? 'Edit Package' : 'Add Package' ?>
    </h1>

    <form action="<?= e(site_url('admin/package_store.php')) ?>" method="POST" enctype="multipart/form-data" novalidate>
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="package_id" value="<?= $is_edit ? (int)$package['package_id'] : 0 ?>">

        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3">Details</h5>
                <div class="row g-3">
                    <div class="col-12">
                        <label for="name" class="form-label fw-semibold">Package Name</label>
                        <input type="text" class="form-control" id="name" name="name" maxlength="150" value="<?= e($val('name')) ?>">
                    </div>
                    <div class="col-12">
                        <label for="description" class="form-label fw-semibold">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3" maxlength="2000"><?= e($val('description')) ?></textarea>
                    </div>
                    <div class="col-md-4">
                        <label for="duration_hours" class="form-label fw-semibold">Duration (hours)</label>
                        <input type="text" inputmode="numeric" class="form-control" id="duration_hours" name="duration_hours" value="<?= e($val('duration_hours', 6)) ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="softcopy_count" class="form-label fw-semibold">Softcopies</label>
                        <input type="text" inputmode="numeric" class="form-control" id="softcopy_count" name="softcopy_count" value="<?= e($val('softcopy_count', 500)) ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="hardcopy_count" class="form-label fw-semibold">Hardcopies</label>
                        <input type="text" inputmode="numeric" class="form-control" id="hardcopy_count" name="hardcopy_count" value="<?= e($val('hardcopy_count', 200)) ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="base_price" class="form-label fw-semibold">Base Price (PHP)</label>
                        <input type="text" inputmode="decimal" class="form-control" id="base_price" name="base_price" value="<?= e($val('base_price', '0.00')) ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="softcopy_addon_price" class="form-label fw-semibold">Softcopy Add-on Price (PHP)</label>
                        <input type="text" inputmode="decimal" class="form-control" id="softcopy_addon_price" name="softcopy_addon_price" value="<?= e($val('softcopy_addon_price', '0.00')) ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="package_type" class="form-label fw-semibold">Type</label>
                        <select class="form-select" id="package_type" name="package_type">
                            <?php foreach (['event' => 'Event', 'walkin' => 'Walk-in'] as $k => $lbl): ?>
                                <option value="<?= e($k) ?>" <?= $val('package_type', 'event') === $k ? 'selected' : '' ?>><?= e($lbl) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 d-flex flex-column justify-content-end gap-2">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="has_softcopy_addon" name="has_softcopy_addon" value="1"
                                <?= $val('has_softcopy_addon', 1) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="has_softcopy_addon">Softcopy add-on available</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1"
                                <?= $val('is_active', 1) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="is_active">Active (visible to customers)</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-1">Cover Photo</h5>
                <p class="text-muted small">Shown on the homepage and package card. JPG, PNG or WEBP, up to 2 MB.</p>
                <?php if ($cover): ?>
                    <div class="d-flex align-items-center gap-3 mb-3">
                        <img src="<?= e($cover) ?>" alt="Current cover" class="rounded" style="width:160px;height:110px;object-fit:cover">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="remove_cover" name="remove_cover" value="1">
                            <label class="form-check-label" for="remove_cover">Remove this cover photo</label>
                        </div>
                    </div>
                <?php endif; ?>
                <input type="file" class="form-control" name="cover" accept="image/jpeg,image/png,image/webp">
                <?php if ($cover): ?><div class="form-text">Choosing a new file replaces the current cover.</div><?php endif; ?>
            </div>
        </div>

        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-1">Photo Gallery</h5>
                <p class="text-muted small">
                    Up to <?= (int)PACKAGE_MAX_GALLERY ?> photos, 2 MB each. Hold Ctrl/Shift to pick several at once.
                    <?php if ($is_edit): ?>You can add <?= (int)$slots_left ?> more.<?php endif; ?>
                </p>
                <?php if ($gallery): ?>
                    <div class="row g-3 mb-3">
                        <?php foreach ($gallery as $g): $gu = package_photo_url($g['file_name']); if (!$gu) continue; ?>
                            <div class="col-6 col-md-3">
                                <div class="border rounded p-2 h-100">
                                    <img src="<?= e($gu) ?>" alt="Gallery photo" class="w-100 rounded mb-2" style="height:100px;object-fit:cover">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="del<?= (int)$g['photo_id'] ?>" name="delete_photos[]" value="<?= (int)$g['photo_id'] ?>">
                                        <label class="form-check-label small" for="del<?= (int)$g['photo_id'] ?>">Remove</label>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <input type="file" class="form-control" name="photos[]" multiple accept="image/jpeg,image/png,image/webp">
            </div>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-snapit fw-semibold px-4">
                <i class="fa-solid fa-floppy-disk me-2"></i><?= $is_edit ? 'Save Changes' : 'Create Package' ?>
            </button>
            <a href="<?= e(site_url('admin/packages.php')) ?>" class="btn btn-outline-secondary">Cancel</a>
        </div>
    </form>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
