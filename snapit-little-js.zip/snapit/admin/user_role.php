<?php
// Admin changes the role of an ACTIVE user (customer / staff / admin).
// Used by both admin/customers.php and admin/staff.php.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
// Guard block: only admins can use this page.
require_admin();

$returns = ['customers' => 'admin/customers.php', 'staff' => 'admin/staff.php'];
$back = site_url($returns[$_POST['return'] ?? ''] ?? 'admin/staff.php');

// Request check block: only POST form submissions are accepted here.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect($back);
}
// Security block: rejects forms without a valid CSRF token.
if (!verify_csrf($_POST['csrf_token'] ?? '')) {
    set_flash('Your session expired. Please try again.', 'danger');
    redirect($back);
}

$user_id = (int)($_POST['user_id'] ?? 0);
$role    = (string)($_POST['role'] ?? '');

if (!in_array($role, USER_ROLES, true)) {
    set_flash('Invalid role selected.', 'danger');
    redirect($back);
}
// An admin cannot change their own role, which also guarantees at least one admin always remains.
if ($user_id === (int)($_SESSION['user_id'] ?? 0)) {
    set_flash('You cannot change your own role.', 'danger');
    redirect($back);
}

// Query block: reads from users.
$st = mysqli_prepare($conn, "SELECT name, role, status FROM users WHERE user_id = ? LIMIT 1");
mysqli_stmt_bind_param($st, 'i', $user_id);
mysqli_stmt_execute($st);
$target = mysqli_fetch_assoc(mysqli_stmt_get_result($st));
mysqli_stmt_close($st);

if (!$target) {
    set_flash('User not found.', 'danger');
    redirect($back);
}
if ($target['status'] !== 'active') {
    set_flash("{$target['name']}'s account is inactive. Activate it before changing the role.", 'warning');
    redirect($back);
}
if ($target['role'] === $role) {
    set_flash("{$target['name']} is already " . ucfirst($role) . '.', 'info');
    redirect($back);
}

try {
    // Update block: changes rows in users.
    $up = mysqli_prepare($conn, "UPDATE users SET role = ? WHERE user_id = ? AND status = 'active'");
    mysqli_stmt_bind_param($up, 'si', $role, $user_id);
    mysqli_stmt_execute($up);
    set_flash("{$target['name']} is now " . ucfirst($role) . '. It applies on their next page load.', 'success');
} catch (Throwable $ex) {
    @error_log('[admin/user_role] ' . $ex->getMessage());
    set_flash('Could not change the role. Please try again.', 'danger');
}
redirect($back);
