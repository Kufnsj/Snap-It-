<?php
// Handler: deletes a review (customers only their own).
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/reviews.php';
// Guard block: only logged-in users can use this page.
require_login();

// Request check block: only POST form submissions are accepted here.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(site_url('index.php#packages'));
}

$package_id = (int)($_POST['package_id'] ?? 0);
$back = $package_id > 0 ? site_url('package.php?id=' . $package_id) . '#reviews' : site_url('index.php#packages');

// Security block: rejects forms without a valid CSRF token.
if (!verify_csrf($_POST['csrf_token'] ?? '')) {
    set_flash('Your session expired. Please try again.', 'danger');
    redirect($back);
}

// A customer can only remove their own review (the WHERE clause enforces it).
$user_id = (int)$_SESSION['user_id'];
try {
    // Delete block: removes rows from reviews.
    $st = mysqli_prepare($conn, "DELETE FROM reviews WHERE user_id = ? AND package_id = ?");
    mysqli_stmt_bind_param($st, 'ii', $user_id, $package_id);
    mysqli_stmt_execute($st);
    if (mysqli_stmt_affected_rows($st) > 0) {
        set_flash('Your review has been removed.', 'success');
    } else {
        set_flash('You have no review of this package to remove.', 'info');
    }
} catch (Throwable $ex) {
    @error_log('[reviews/delete] ' . $ex->getMessage());
    set_flash('Could not remove your review. Please try again.', 'danger');
}
redirect($back);
