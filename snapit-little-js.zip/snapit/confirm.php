<?php
// "Are you sure?" page. It replaces the JavaScript confirm() pop-ups: a button that needs a question posts here first,
// and only when the person presses "Yes, continue" is the real action posted to its own handler.
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/config.php';

// Guard block: login required, and the page only works with a form post.
require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(site_url('index.php'));
}

// Input block: where the action goes, the question, and the page to return to if the person says no.
$to      = (string)($_POST['confirm_to'] ?? '');
$message = trim((string)($_POST['confirm_msg'] ?? 'Are you sure?'));
$back    = (string)($_POST['confirm_back'] ?? '');

// Safety block: the target must be a .php file of this project (no outside addresses, no "..").
if (!preg_match('~^[A-Za-z0-9_\-]+(/[A-Za-z0-9_\-]+)*\.php$~', $to) || !is_file(__DIR__ . '/' . $to)) {
    set_flash('That action is not available.', 'danger');
    redirect(site_url('index.php'));
}
// The "No" link must stay on this site.
if (!preg_match('~^/[^/\\\\\s][^\\\\\s]*$~', $back) && $back !== '/') {
    $back = site_url('index.php');
}

include __DIR__ . '/includes/header.php';
?>
<div class="container py-5" style="max-width:560px;">
    <div class="card p-4 text-center">
        <h4 class="mb-3"><i class="fa-regular fa-circle-question me-2"></i>Please confirm</h4>
        <p class="mb-4"><?= e($message) ?></p>
        <!-- Yes block: re-sends every field of the original form (including its security token) to the real handler -->
        <form method="POST" action="<?= e(site_url($to)) ?>" class="d-inline">
            <?php foreach ($_POST as $name => $value): ?>
                <?php if (strpos($name, 'confirm_') === 0 || !is_string($value)) continue; ?>
                <input type="hidden" name="<?= e($name) ?>" value="<?= e($value) ?>">
            <?php endforeach; ?>
            <button type="submit" class="btn btn-snapit px-4"><i class="fa-solid fa-check me-1"></i>Yes, continue</button>
        </form>
        <a href="<?= e($back) ?>" class="btn btn-outline-secondary px-4 ms-2"><i class="fa-solid fa-xmark me-1"></i>No, go back</a>
    </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
