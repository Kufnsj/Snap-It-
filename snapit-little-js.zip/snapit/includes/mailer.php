<?php
// All email sending (PHPMailer + FPDF): order status emails with PDF, booth photo emails, queued event reminders.
if (!defined('SNAPIT_ROOT')) define('SNAPIT_ROOT', dirname(__DIR__));
require_once __DIR__ . '/config.php';

if (file_exists(SNAPIT_ROOT . '/vendor/autoload.php')) {
    require_once SNAPIT_ROOT . '/vendor/autoload.php';
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

function snapit_mailer_enabled() {
    return class_exists(PHPMailer::class);
}

function snapit_current_mailer_cfg() {
    global $MAILER;
    if (!is_array($MAILER)) {
        $MAILER = [];
    }
    $service = $MAILER['service'] ?? 'mailtrap';
    if (!isset($MAILER[$service]) || !is_array($MAILER[$service])) {
        $service = 'mailtrap';
    }
    if (!isset($MAILER[$service]) || !is_array($MAILER[$service])) {
        $MAILER[$service] = [
            'host' => 'sandbox.smtp.mailtrap.io',
            'port' => 2525,
            'username' => '',
            'password' => '',
            'smtp_secure' => 'tls',
            'smtp_auth' => true,
            'timeout' => 20,
        ];
    }
    return [
        'service_key' => $service,
        'global'      => $MAILER,
        'svc'         => $MAILER[$service],
    ];
}

function snapit_build_full_url($relative = '') {
    if (strpos($relative, 'http') === 0) return $relative;
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST']   ?? 'localhost';
    $base   = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/snapit/index.php')), '/\\');
    if ($base === '.' || $base === '\\') $base = '';
    if (strpos($relative, '/') !== 0) $relative = '/' . $relative;
    return $scheme . '://' . $host . $base . $relative;
}


function snapit_configure_smtp(PHPMailer $mail, $overrideService = null) {
    $cfg = snapit_current_mailer_cfg();
    $global = $cfg['global'];
    $svc    = $cfg['svc'];
    if ($overrideService && isset($global[$overrideService])) {
        $svc = $global[$overrideService];
        $cfg['service_key'] = $overrideService;
    }
    $mail->isSMTP();
    $mail->Host       = $svc['host'];
    $mail->Port       = (int)$svc['port'];
    $mail->SMTPAuth   = (bool)($svc['smtp_auth']   ?? true);
    $mail->Username   = $svc['username'];
    $mail->Password   = $svc['password'];
    if (!empty($svc['smtp_secure']) && $svc['smtp_secure'] !== 'none') {
        if (version_compare(PHP_VERSION, '5.5', '>=') && defined('PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS')) {
            if (strcasecmp($svc['smtp_secure'], 'ssl') === 0) {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            } else {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            }
        } else {
            $mail->SMTPSecure = strcasecmp($svc['smtp_secure'], 'ssl') === 0 ? 'ssl' : 'tls';
        }
    } else {
        $mail->SMTPAutoTLS = false;
        $mail->SMTPSecure = '';
    }
    $mail->Timeout    = (int)($svc['timeout'] ?? 30);
    $mail->CharSet    = $global['charset'] ?? 'UTF-8';
    $mail->XMailer    = 'SnapIt Photobooth Mailer (PHPMailer)';
    $mail->setFrom($global['from_email'], $global['from_name']);
    if (!empty($global['reply_to'])) {
        try { $mail->addReplyTo($global['reply_to'], $global['from_name']); } catch (Throwable $t) { /* ignore */ }
    }
    return $cfg;
}

function snapit_send_email($options = []) {
    global $MAILER;
    $result = [
        'ok'            => false,
        'message_id'    => null,
        'error'         => null,
        'detail'        => null,
        'service'       => null,
        'recipients_ok' => 0,
        'recipients_total' => 0,
        'smtp_log'      => [],
        'used_phpmailer' => false,
    ];
    $to          = $options['to']          ?? [];
    $cc          = $options['cc']          ?? [];
    $bcc         = $options['bcc']         ?? [];
    $subject     = $options['subject']     ?? '(No subject)';
    $body_html   = $options['body_html']   ?? '';
    $body_text   = $options['body_text']   ?? '';
    $attachments = $options['attachments'] ?? [];
    $overrideSvc = $options['service']     ?? null;
    $debug       = array_key_exists('debug', $options) ? (bool)$options['debug'] : (((int)($MAILER['debug_level'] ?? 0)) > 0);

    if (!is_array($to)) $to  = $to  ? [$to]  : [];
    if (!is_array($cc)) $cc  = $cc  ? [$cc]  : [];
    if (!is_array($bcc))$bcc = $bcc ? [$bcc] : [];

    $valid_to = [];
    foreach ($to as $addr) {
        $norm = trim((string)$addr);
        if ($norm && filter_var($norm, FILTER_VALIDATE_EMAIL)) $valid_to[] = $norm;
    }
    $result['recipients_total'] = count($to);
    $result['recipients_ok']    = 0;
    if (empty($valid_to)) {
        $result['error']  = 'no_valid_recipients';
        $result['detail'] = 'No valid "To" addresses provided (' . count($to) . ' attempted).';
        return $result;
    }

    if (!snapit_mailer_enabled()) {
        $result['error']  = 'phpmailer_missing';
        $result['detail'] = 'PHPMailer is not installed. Run `composer install` from snapit/ OR copy '
                          . 'PHPMailer src files (Exception,SMTP,PHPMailer,OAuth) into vendor/phpmailer/src/ '
                          . '(see vendor/README.md). Falling back to PHP mail() is intentionally disabled to '
                          . 'guarantee SMTP deliverability; please install PHPMailer.';
        return $result;
    }
    $result['used_phpmailer'] = true;

    try {
        $mail = new PHPMailer(true);
        $cfg = snapit_configure_smtp($mail, $overrideSvc);
        $result['service'] = $cfg['service_key'];

        if ($debug) {
            $mail->SMTPDebug = defined('SMTP::DEBUG_SERVER') ? SMTP::DEBUG_SERVER : 3;
            $mail->Debugoutput = function ($str, $level) use (&$result) {
                $result['smtp_log'][] = '[SMTP ' . $level . '] ' . rtrim($str);
            };
        }

        foreach ($valid_to as $addr) {
            try { $mail->addAddress($addr); } catch (PHPMailerException $e) {
                $result['detail'] = ($result['detail'] ? $result['detail'] . '; ' : '') . 'Invalid TO: ' . $addr;
            }
        }
        foreach ((array)$cc as $addr) {
            $addr = trim((string)$addr);
            if ($addr && filter_var($addr, FILTER_VALIDATE_EMAIL)) {
                try { $mail->addCC($addr); } catch (Throwable $t) { /* ignore */ }
            }
        }
        foreach ((array)$bcc as $addr) {
            $addr = trim((string)$addr);
            if ($addr && filter_var($addr, FILTER_VALIDATE_EMAIL)) {
                try { $mail->addBCC($addr); } catch (Throwable $t) { /* ignore */ }
            }
        }
        if (empty($body_text) && $body_html !== '') {
            $body_text = trim(preg_replace('/\s+/', ' ', preg_replace('/<[^>]+>/', ' ', $body_html)));
        }
        if ($body_html !== '') {
            $mail->isHTML(true);
            $mail->Body    = $body_html;
            if ($body_text !== '') $mail->AltBody = $body_text;
        } else {
            $mail->isHTML(false);
            $mail->Body = $body_text !== '' ? $body_text : $subject;
        }
        $mail->Subject = $subject;

        foreach ($attachments as $att) {
            if (is_string($att) && file_exists($att)) {
                try { $mail->addAttachment($att); } catch (Throwable $t) {
                    $result['detail'] = ($result['detail'] ? $result['detail'] . '; ' : '')
                                      . 'Could not attach file: ' . basename($att);
                }
            } elseif (is_array($att) && !empty($att['path']) && file_exists($att['path'])) {
                try {
                    $mail->addAttachment(
                        $att['path'],
                        $att['name'] ?? '',
                        PHPMailer::ENCODING_BASE64,
                        $att['type'] ?? '',
                        $att['disposition'] ?? 'attachment'
                    );
                } catch (Throwable $t) {
                    $result['detail'] = ($result['detail'] ? $result['detail'] . '; ' : '')
                                      . 'Could not attach: ' . ($att['name'] ?? basename($att['path']));
                }
            }
        }

        if ($mail->send()) {
            $result['ok'] = true;
            $result['recipients_ok'] = count($valid_to);
            if (!empty($mail->getLastMessageID())) {
                $result['message_id'] = $mail->getLastMessageID();
            }
        } else {
            $result['error']  = 'send_failed';
            $result['detail'] = 'PHPMailer send() returned false but no exception: ' . $mail->ErrorInfo;
        }
    } catch (PHPMailerException $e) {
        $result['error']  = 'phpmailer_exception';
        $result['detail'] = $e->getMessage() . ' | SMTP last error: ' . ($mail->ErrorInfo ?? 'n/a');
    } catch (Throwable $t) {
        $result['error']  = 'unexpected_exception';
        $result['detail'] = get_class($t) . ': ' . $t->getMessage() . ' @ ' . $t->getFile() . ':' . $t->getLine();
    }
    return $result;
}

function snapit_email_wrap_html($title, $bodyHtml, $baseUrl = null) {
    if ($baseUrl === null) $baseUrl = snapit_build_full_url('');
    $css = 'body{font-family:Arial,Helvetica,sans-serif;background:#f3ece0;color:#2b1f15;margin:0;padding:24px}'
         . '.wrap{max-width:600px;margin:0 auto;background:#fff;border:1px solid #e4d6bd;border-radius:12px;overflow:hidden;box-shadow:0 6px 24px rgba(26,18,12,0.10)}'
         . '.hero{background:#1a120c;color:#f3ece0;padding:28px 32px}'
         . '.hero h1{margin:0;font-size:20px;letter-spacing:0.5px;color:#d8c09a}'
         . '.hero p{margin:4px 0 0;opacity:0.9;font-size:13px}'
         . '.inner{padding:28px 32px;line-height:1.6;font-size:15px;color:#2b1f15}'
         . '.inner h2{font-size:17px;color:#3a2a1c;margin:0 0 12px}'
         . '.meta{background:#fbf8f3;border-left:4px solid #8c6b45;padding:12px 16px;margin:16px 0;border-radius:0 6px 6px 0;font-size:14px}'
         . '.cta{display:inline-block;background:#1a120c;color:#d8c09a;text-decoration:none;padding:12px 22px;border-radius:8px;font-weight:600;margin:14px 0}'
         . '.foot{padding:20px 32px;background:#fbf8f3;color:#7a6a55;font-size:12px;border-top:1px solid #e4d6bd;text-align:center}'
         . '.foot a{color:#3a2a1c;text-decoration:none}';
    $title = $title ? $title : 'Snap It Photobooth';
    return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">'
         . '<title>' . htmlspecialchars($title) . '</title></head><body style="margin:0;padding:24px;background:#f3ece0">'
         . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td>'
         . '<div class="wrap" style="max-width:600px;margin:0 auto;background:#fff;border:1px solid #e4d6bd;border-radius:12px;overflow:hidden;box-shadow:0 6px 24px rgba(26,18,12,0.10)">'
         . '<div class="hero" style="background:#1a120c;color:#f3ece0;padding:28px 32px">'
         . '<h1 style="margin:0;font-size:20px;letter-spacing:0.5px;font-weight:600;color:#d8c09a">Snap It Photobooth</h1>'
         . '<p style="margin:4px 0 0;color:#c9b793;font-size:13px">' . htmlspecialchars($title) . '</p>'
         . '</div>'
         . '<div class="inner" style="padding:28px 32px;line-height:1.6;font-size:15px;color:#2b1f15">'
         . $bodyHtml
         . '</div>'
         . '<div class="foot" style="padding:20px 32px;background:#fbf8f3;color:#7a6a55;font-size:12px;border-top:1px solid #e4d6bd;text-align:center">'
         . '&copy; ' . date('Y') . ' Snap It Photobooth &middot; '
         . '<a href="' . htmlspecialchars($baseUrl) . '" style="color:#3a2a1c;text-decoration:none">'
         . preg_replace('#^https?://#', '', rtrim($baseUrl, '/')) . '</a>'
         . '</div></div></td></tr></table></body></html>';
}

function snapit_mark_notification_sent($conn, $notification_id, $success, $errorDetail = '', $messageId = '') {
    if (!$conn || !(int)$notification_id) return false;
    $status = $success ? 'sent' : 'failed';
    $sentAt = $success ? 'NOW()' : 'NULL';
    $sql = "UPDATE notifications SET status = ?, sent_at = " . $sentAt
         . ", error_detail = ?, message_id = ? WHERE notification_id = ? LIMIT 1";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return false;
    $errShort = mb_substr((string)$errorDetail, 0, 1000);
    $idShort  = mb_substr((string)$messageId, 0, 255);
    mysqli_stmt_bind_param($stmt, 'sssi', $status, $errShort, $idShort, $notification_id);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $ok;
}

function snapit_dispatch_notification_row($conn, $row, $attachments = []) {
    if (!is_array($row) || empty($row['recipient_email'])) {
        return ['ok' => false, 'error' => 'no_recipient', 'detail' => 'Notification row missing recipient_email'];
    }
    $to   = $row['recipient_email'];
    $subj = $row['subject']       ?: 'Snap It Update';
    $body = $row['message_body']  ?: '';
    $html = '<h2 style="font-size:17px;color:#3a2a1c;margin:0 0 12px">' . htmlspecialchars($subj) . '</h2>'
          . '<div style="white-space:pre-wrap">' . htmlspecialchars($body) . '</div>';
    return snapit_send_email([
        'to'          => $to,
        'subject'     => $subj,
        'body_html'   => snapit_email_wrap_html($subj, $html),
        'body_text'   => strip_tags($body),
        'attachments' => $attachments,
    ]);
}

function snapit_send_booth_softcopy_email($toAddress, $booking, $session, $photoRows, $galleryUrl) {
    $evt = htmlspecialchars($booking['event_name'] ?? 'Snap It Event');
    $bookingId = (int)($booking['booking_id'] ?? 0);
    $sessionId = (int)($session['session_id']   ?? 0);
    $customer  = htmlspecialchars($booking['customer_name'] ?? $booking['name'] ?? 'Friend');

    $photoHtml = '';
    if (!empty($photoRows) && is_array($photoRows)) {
        $photoHtml = '<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin:18px 0">';
        foreach ($photoRows as $p) {
            $url = !empty($p['photo_path']) ? snapit_build_full_url(ltrim($p['photo_path'], '/')) : '';
            if (!$url) continue;
            $photoHtml .= '<a href="' . htmlspecialchars($url) . '" target="_blank" rel="noopener" style="display:block;border:1px solid #e4d6bd;border-radius:10px;overflow:hidden;box-shadow:0 3px 10px rgba(26,18,12,0.10)">'
                        . '<img src="' . htmlspecialchars($url) . '" alt="Photo" loading="lazy" crossorigin="anonymous" '
                        . 'style="display:block;width:100%;height:auto"></a>';
        }
        $photoHtml .= '</div>';
    }

    $body = '<h2 style="font-size:17px;color:#3a2a1c;margin:0 0 12px">Your photos are ready, ' . $customer . '! 🎉</h2>'
          . '<p>Thanks for visiting the Snap It booth at <strong>' . $evt . '</strong>. Here\'s your softcopy set from Session #' . $sessionId . ' (Booking #' . $bookingId . ').</p>'
          . $photoHtml
          . '<p><a class="cta" href="' . htmlspecialchars($galleryUrl) . '" style="display:inline-block;background:#1a120c;color:#d8c09a;text-decoration:none;padding:12px 22px;border-radius:8px;font-weight:600;margin:14px 0">View Full Gallery &amp; Download as PNG</a></p>'
          . '<div class="meta" style="background:#fbf8f3;border-left:4px solid #8c6b45;padding:12px 16px;margin:16px 0;border-radius:0 6px 6px 0;font-size:14px">'
          . 'Click each photo above to open its full-resolution version. To save: right-click &rarr; Save Image As, or use the <strong>Download as PNG</strong> button on the gallery page for the full framed strip.'
          . '</div>';
    $attachments = [];
    return snapit_send_email([
        'to'          => $toAddress,
        'subject'     => 'Your Snap It Photos from ' . $evt . ' (Session #' . $sessionId . ')',
        'body_html'   => snapit_email_wrap_html('Softcopy delivery for ' . $evt, $body, $galleryUrl),
        'body_text'   => 'Your photos are ready: ' . $galleryUrl . "\n\n" . strip_tags($body),
        'attachments' => $attachments,
    ]);
}

function snapit_send_event_reminder($booking, $daysBefore) {
    $evt = htmlspecialchars($booking['event_name'] ?? 'Your Event');
    $bookingId = (int)($booking['booking_id'] ?? 0);
    $customer  = htmlspecialchars($booking['customer_name'] ?? $booking['name'] ?? '');
    $whenDate  = htmlspecialchars($booking['event_date'] ?? '');
    $whenTime  = isset($booking['start_time']) ? htmlspecialchars(date('h:i A', strtotime($booking['start_time']))) : '';
    $venue     = htmlspecialchars($booking['venue'] ?? '');
    $hours     = (int)($booking['duration_hours'] ?? 0);
    $viewUrl   = snapit_build_full_url('booking/view.php?id=' . $bookingId);

    $body = '<h2 style="font-size:17px;color:#3a2a1c;margin:0 0 12px">Friendly reminder: ' . $evt . ' is in ' . (int)$daysBefore . ' day(s)! 🗓️</h2>'
          . '<p>Hi ' . $customer . ',</p>'
          . '<p>We\'re getting ready for your event. Here are the details we have on file for Booking #' . $bookingId . ':</p>'
          . '<div class="meta" style="background:#fbf8f3;border-left:4px solid #8c6b45;padding:12px 16px;margin:16px 0;border-radius:0 6px 6px 0;font-size:14px">'
          . '<div><strong>Event:</strong> ' . $evt . '</div>'
          . '<div><strong>Date:</strong> ' . $whenDate . '</div>'
          . '<div><strong>Start time:</strong> ' . $whenTime . '</div>'
          . '<div><strong>Duration:</strong> ' . $hours . ' hours</div>'
          . '<div><strong>Venue:</strong> ' . $venue . '</div>'
          . '</div>'
          . '<p>If anything needs to be adjusted, please reply to this email or call us as soon as possible.</p>'
          . '<a class="cta" href="' . htmlspecialchars($viewUrl) . '" style="display:inline-block;background:#1a120c;color:#d8c09a;text-decoration:none;padding:12px 22px;border-radius:8px;font-weight:600;margin:14px 0">View Booking Details</a>';
    return snapit_send_email([
        'to'        => $booking['customer_email'] ?? $booking['email'] ?? null,
        'subject'   => 'Reminder: ' . $evt . ' in ' . (int)$daysBefore . ' day(s) (Booking #' . $bookingId . ')',
        'body_html' => snapit_email_wrap_html('Event reminder for ' . $evt, $body, $viewUrl),
        'body_text' => strip_tags($body),
    ]);
}

function snapit_latin($s) {
    $s = (string)$s;
    if (function_exists('iconv')) {
        $c = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT//IGNORE', $s);
        if ($c !== false) return $c;
    }
    return preg_replace('/[^\x20-\x7E]/', '?', $s);
}

function snapit_load_order($conn, $booking_id) {
    $id = (int)$booking_id;
    // Query block: reads from vw_order_details.
    $st = mysqli_prepare($conn, "SELECT * FROM vw_order_details WHERE booking_id = ? LIMIT 1");
    mysqli_stmt_bind_param($st, 'i', $id);
    mysqli_stmt_execute($st);
    $order = mysqli_fetch_assoc(mysqli_stmt_get_result($st));
    mysqli_stmt_close($st);
    if (!$order) return [null, []];
    $items = [];
    // Query block: reads from the database.
    $st = mysqli_prepare($conn, "SELECT line_no, item_type, item_name, quantity, unit_price, subtotal
        FROM vw_order_items WHERE booking_id = ? ORDER BY line_no ASC");
    mysqli_stmt_bind_param($st, 'i', $id);
    mysqli_stmt_execute($st);
    $res = mysqli_stmt_get_result($st);
    while ($row = mysqli_fetch_assoc($res)) $items[] = $row;
    mysqli_stmt_close($st);
    return [$order, $items];
}

function snapit_order_items_html($items, $grand_total) {
    $rows = '';
    foreach ($items as $it) {
        $rows .= '<tr>'
            . '<td style="padding:8px;border-bottom:1px solid #e4d6bd">' . htmlspecialchars((string)$it['item_name']) . '</td>'
            . '<td style="padding:8px;border-bottom:1px solid #e4d6bd;text-align:center">' . (int)$it['quantity'] . '</td>'
            . '<td style="padding:8px;border-bottom:1px solid #e4d6bd;text-align:right">' . htmlspecialchars(format_money($it['unit_price'])) . '</td>'
            . '<td style="padding:8px;border-bottom:1px solid #e4d6bd;text-align:right">' . htmlspecialchars(format_money($it['subtotal'])) . '</td>'
            . '</tr>';
    }
    if ($rows === '') {
        $rows = '<tr><td colspan="4" style="padding:8px">No line items</td></tr>';
    }
    return '<table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin:16px 0;font-size:14px">'
        . '<thead><tr style="background:#fbf8f3">'
        . '<th align="left" style="padding:8px">Item</th><th style="padding:8px">Qty</th>'
        . '<th align="right" style="padding:8px">Unit</th><th align="right" style="padding:8px">Subtotal</th>'
        . '</tr></thead><tbody>' . $rows . '</tbody>'
        . '<tfoot><tr><td colspan="3" style="padding:10px 8px;text-align:right;font-weight:bold">Grand total</td>'
        . '<td style="padding:10px 8px;text-align:right;font-weight:bold">' . htmlspecialchars(format_money($grand_total)) . '</td></tr></tfoot></table>';
}

function snapit_build_order_pdf($order, $items, $extra = []) {
    if (!class_exists('FPDF')) {
        return [null, 'fpdf_missing'];
    }
    $pdf = new FPDF('P', 'mm', 'A4');
    $pdf->AddPage();
    $pdf->SetTitle('Snap It Receipt #' . (int)$order['booking_id']);
    $pdf->SetFont('Helvetica', 'B', 16);
    $pdf->Cell(0, 10, 'Snap It Photobooth', 0, 1, 'C');
    $pdf->SetFont('Helvetica', '', 10);
    $pdf->Cell(0, 6, 'Official Receipt / Order Summary', 0, 1, 'C');
    $pdf->Ln(4);
    $pdf->SetFont('Helvetica', '', 11);
    $lines = [
        'Booking #' . (int)$order['booking_id'],
        'Status: ' . ucfirst((string)($order['status'] ?? '')),
        'Customer: ' . ($order['customer_name'] ?? ''),
        'Email: ' . ($order['customer_email'] ?? ''),
        'Event: ' . ($order['event_name'] ?? ''),
        'Date: ' . format_date($order['event_date'] ?? ''),
        'Time: ' . (!empty($order['start_time']) ? date('h:i A', strtotime($order['start_time'])) : ''),
        'Duration: ' . (int)($order['duration_hours'] ?? 0) . ' hours',
        'Venue: ' . ($order['venue'] ?? ''),
    ];
    if (!empty($extra['or_number'])) $lines[] = 'OR Number: ' . $extra['or_number'];
    if (isset($extra['amount_paid'])) $lines[] = 'Amount paid now: ' . format_money($extra['amount_paid']);
    foreach ($lines as $line) {
        $pdf->Cell(0, 6, snapit_latin($line), 0, 1);
    }
    $pdf->Ln(4);
    $pdf->SetFont('Helvetica', 'B', 11);
    $pdf->Cell(80, 8, 'Item', 1);
    $pdf->Cell(20, 8, 'Qty', 1, 0, 'C');
    $pdf->Cell(45, 8, 'Unit', 1, 0, 'R');
    $pdf->Cell(45, 8, 'Subtotal', 1, 1, 'R');
    $pdf->SetFont('Helvetica', '', 10);
    foreach ($items as $it) {
        $pdf->Cell(80, 8, snapit_latin(mb_substr((string)$it['item_name'], 0, 40)), 1);
        $pdf->Cell(20, 8, (string)(int)$it['quantity'], 1, 0, 'C');
        $pdf->Cell(45, 8, snapit_latin(format_money($it['unit_price'])), 1, 0, 'R');
        $pdf->Cell(45, 8, snapit_latin(format_money($it['subtotal'])), 1, 1, 'R');
    }
    $pdf->SetFont('Helvetica', 'B', 11);
    $pdf->Cell(145, 8, 'Grand total', 1, 0, 'R');
    $pdf->Cell(45, 8, snapit_latin(format_money($order['total_amount'] ?? 0)), 1, 1, 'R');
    $pdf->SetFont('Helvetica', '', 10);
    $pdf->Cell(145, 8, 'Amount paid to date', 1, 0, 'R');
    $pdf->Cell(45, 8, snapit_latin(format_money($order['amount_paid'] ?? 0)), 1, 1, 'R');
    $pdf->Cell(145, 8, 'Balance due', 1, 0, 'R');
    $pdf->Cell(45, 8, snapit_latin(format_money($order['balance_due'] ?? 0)), 1, 1, 'R');
    $pdf->Ln(8);
    $pdf->SetFont('Helvetica', 'I', 9);
    $pdf->Cell(0, 5, 'Thank you for choosing Snap It.', 0, 1, 'C');

    $dir = SNAPIT_ROOT . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'receipts';
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
        return [null, 'receipt_dir_unwritable'];
    }
    $path = $dir . DIRECTORY_SEPARATOR . 'booking-' . (int)$order['booking_id'] . '-' . bin2hex(random_bytes(4)) . '.pdf';
    $pdf->Output('F', $path);
    if (!is_file($path)) return [null, 'pdf_write_failed'];
    return [$path, null];
}

function snapit_send_order_status_email($conn, $booking_id, $type, $extra = []) {
    [$order, $items] = snapit_load_order($conn, $booking_id);
    if (!$order) {
        return ['ok' => false, 'error' => 'not_found', 'detail' => 'Booking not found'];
    }
    $type = (string)$type;
    $allowed = ['booking_created', 'booking_confirmed', 'booking_cancelled', 'payment_received', 'booking_completed'];
    if (!in_array($type, $allowed, true)) $type = 'booking_confirmed';

    $name = $order['customer_name'] ?? '';
    $headlines = [
        'booking_created'    => 'We received your booking',
        'booking_confirmed'  => 'Your booking is confirmed',
        'booking_cancelled'  => 'Your booking has been cancelled',
        'payment_received'   => 'We received your payment',
        'booking_completed'  => 'Your booking is complete',
    ];
    $paras = [
        'booking_created'    => 'Your booking has been created and is awaiting confirmation.',
        'booking_confirmed'  => 'Great news — your booking has been confirmed.',
        'booking_cancelled'  => 'We regret to inform you that this booking has been cancelled.',
        'payment_received'   => 'We have recorded a payment against your booking.',
        'booking_completed'  => 'Your event booking has been marked as completed. Thank you for celebrating with Snap It.',
    ];
    $title = $headlines[$type];
    $subject = $title . ' - Booking #' . (int)$order['booking_id'] . ' - ' . ($order['event_name'] ?? 'Snap It');
    $itemTable = snapit_order_items_html($items, $order['total_amount']);
    $meta = '<div class="meta" style="background:#fbf8f3;border-left:4px solid #8c6b45;padding:12px 16px;margin:16px 0;border-radius:0 6px 6px 0;font-size:14px">'
        . '<div><strong>Booking:</strong> #' . (int)$order['booking_id'] . '</div>'
        . '<div><strong>Event:</strong> ' . htmlspecialchars((string)($order['event_name'] ?? '')) . '</div>'
        . '<div><strong>Date:</strong> ' . htmlspecialchars(format_date($order['event_date'] ?? '')) . '</div>'
        . '<div><strong>Time:</strong> ' . htmlspecialchars(!empty($order['start_time']) ? date('h:i A', strtotime($order['start_time'])) : '') . '</div>'
        . '<div><strong>Duration:</strong> ' . (int)$order['duration_hours'] . ' hours</div>'
        . '<div><strong>Status:</strong> ' . htmlspecialchars(ucfirst((string)$order['status'])) . '</div>'
        . '</div>';
    if (!empty($extra['or_number'])) {
        $meta .= '<p><strong>OR number:</strong> ' . htmlspecialchars((string)$extra['or_number'])
            . ' &nbsp; <strong>Paid now:</strong> ' . htmlspecialchars(format_money($extra['amount_paid'] ?? 0)) . '</p>';
    }
    $htmlInner = '<h2 style="font-size:17px;color:#3a2a1c;margin:0 0 12px">' . htmlspecialchars($title) . '</h2>'
        . '<p>Hi ' . htmlspecialchars($name) . ',</p><p>' . htmlspecialchars($paras[$type]) . '</p>'
        . $meta . $itemTable
        . '<p><strong>Grand total: ' . htmlspecialchars(format_money($order['total_amount'])) . '</strong></p>'
        . '<p>A PDF receipt is attached to this email.</p>';
    $body_html = snapit_email_wrap_html($title, $htmlInner);
    $body_text = "Hi {$name},\n\n{$paras[$type]}\n\nGrand total: " . format_money($order['total_amount']) . "\n";
    foreach ($items as $it) {
        $body_text .= '- ' . $it['item_name'] . ' x' . (int)$it['quantity'] . ' = ' . format_money($it['subtotal']) . "\n";
    }

    [$pdfPath, $pdfErr] = snapit_build_order_pdf($order, $items, $extra);
    $attachments = [];
    if ($pdfPath) {
        $attachments[] = [
            'path' => $pdfPath,
            'name' => 'SnapIt-Receipt-Booking-' . (int)$order['booking_id'] . '.pdf',
            'type' => 'application/pdf',
        ];
    }

    $to = $order['customer_email'] ?? '';
    $send = snapit_send_email([
        'to'          => $to,
        'subject'     => $subject,
        'body_html'   => $body_html,
        'body_text'   => $body_text,
        'attachments' => $attachments,
    ]);
    if ($pdfErr) {
        $send['detail'] = trim(($send['detail'] ?? '') . '; PDF: ' . $pdfErr, '; ');
        if (empty($send['error'])) $send['error'] = 'pdf_failed';
    }

    $uid = (int)$order['user_id'];
    $bid = (int)$order['booking_id'];
    $plain = $paras[$type] . "\n\nGrand total: " . format_money($order['total_amount']);
    $status = !empty($send['ok']) ? 'sent' : 'failed';
    $err = mb_substr((string)($send['detail'] ?? $send['error'] ?? ''), 0, 1000);
    $mid = mb_substr((string)($send['message_id'] ?? ''), 0, 255);
    $sentSql = !empty($send['ok']) ? 'NOW()' : 'NULL';
    try {
        $sql = "INSERT INTO notifications (booking_id, user_id, type, recipient_email, subject, message_body, status, error_detail, message_id, sent_at, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, {$sentSql}, NOW())";
        $st = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($st, 'iisssssss', $bid, $uid, $type, $to, $subject, $plain, $status, $err, $mid);
        mysqli_stmt_execute($st);
        mysqli_stmt_close($st);
    } catch (Throwable $ex) {
        @error_log('[order_email] notif insert: ' . $ex->getMessage());
    }

    if ($pdfPath && is_file($pdfPath)) @unlink($pdfPath);
    return $send;
}

function snapit_schedule_event_reminders($conn, $order) {
    $email = $order['customer_email'] ?? '';
    if (!$email || empty($order['event_date'])) return;
    $uid = (int)$order['user_id'];
    $bid = (int)$order['booking_id'];
    $today = new DateTime('today');
    foreach ([2, 1] as $days) {
        try {
            $when = new DateTime($order['event_date'] . ' 08:00:00');
            $when->modify('-' . $days . ' days');
            if ($when < $today) continue;
            $scheduled = $when->format('Y-m-d H:i:s');
            $type = 'event_reminder';
            $subject = 'Reminder: ' . ($order['event_name'] ?? 'Your event') . ' in ' . $days . ' day(s)';
            $body = 'Your Snap It booking #' . $bid . ' is in ' . $days . ' day(s).';
            $status = 'pending';
            // Save block: inserts into notifications.
            $st = mysqli_prepare($conn, "INSERT INTO notifications (booking_id, user_id, type, recipient_email, subject, message_body, status, scheduled_at, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            mysqli_stmt_bind_param($st, 'iissssss', $bid, $uid, $type, $email, $subject, $body, $status, $scheduled);
            mysqli_stmt_execute($st);
            mysqli_stmt_close($st);
        } catch (Throwable $ex) {
            @error_log('[reminders] ' . $ex->getMessage());
        }
    }
}

function snapit_mail_flash($ok_message, $send) {
    if (!empty($send['ok'])) {
        set_flash($ok_message, 'success');
        return;
    }
    $detail = trim((string)($send['detail'] ?? $send['error'] ?? 'mailer error'));
    set_flash($ok_message . ' Email was not delivered (' . $detail . ').', 'warning');
}
