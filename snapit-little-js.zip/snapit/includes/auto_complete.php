<?php
// Marks paid bookings as completed once their event time has passed, and emails the customer.
/**
 * Automatically marks PAID bookings as COMPLETED once their session has ended
 * (event_date + start_time + duration_hours <= now).
 *
 * Runs whenever a booking/admin page loads (throttled to once a minute per visitor)
 * and from notifications_dispatch_pending.php (cron). The UPDATE is guarded by
 * `status = 'paid'`, so a booking is only ever completed (and emailed) once, even
 * if two requests run at the same time.
 *
 * Bookings that ended more than 24 hours ago are completed silently (no email),
 * so the first run on an existing database does not flood customers with old emails.
 *
 * @return int number of bookings completed by this call
 */
function snapit_auto_complete_bookings($conn, $force = false)
{
    if (!$conn) return 0;
    if (!$force) {
        $last = (int)($_SESSION['auto_complete_at'] ?? 0);
        if ($last && time() - $last < 60) return 0;
        $_SESSION['auto_complete_at'] = time();
    }

    $now = date('Y-m-d H:i:s');
    $st = mysqli_prepare($conn,
        "SELECT booking_id,
                (TIMESTAMP(event_date, start_time) + INTERVAL duration_hours HOUR) AS ends_at
         FROM bookings
         WHERE status = 'paid'
           AND (TIMESTAMP(event_date, start_time) + INTERVAL duration_hours HOUR) <= ?
         ORDER BY booking_id ASC
         LIMIT 200");
    if (!$st) return 0;
    mysqli_stmt_bind_param($st, 's', $now);
    mysqli_stmt_execute($st);
    $rows = mysqli_fetch_all(mysqli_stmt_get_result($st), MYSQLI_ASSOC);
    mysqli_stmt_close($st);
    if (!$rows) return 0;

    // Update block: changes rows in bookings.
    $upd = mysqli_prepare($conn, "UPDATE bookings SET status = 'completed' WHERE booking_id = ? AND status = 'paid'");
    if (!$upd) return 0;
    $done = 0;
    $cutoff = time() - 86400;
    foreach ($rows as $r) {
        $id = (int)$r['booking_id'];
        mysqli_stmt_bind_param($upd, 'i', $id);
        mysqli_stmt_execute($upd);
        if (mysqli_stmt_affected_rows($upd) !== 1) continue;   // another request got it first
        $done++;

        if (strtotime($r['ends_at']) >= $cutoff) {
            try {
                if (!function_exists('snapit_send_order_status_email')) {
                    require_once __DIR__ . '/mailer.php';
                }
                snapit_send_order_status_email($conn, $id, 'booking_completed');
            } catch (Throwable $e) {
                @error_log('[auto_complete] email for booking #' . $id . ': ' . $e->getMessage());
            }
        }
    }
    mysqli_stmt_close($upd);
    return $done;
}
