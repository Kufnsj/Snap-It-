<?php
// Bootstrap loaded by almost every page: error handling, timezone, database connection, mailer settings and the schema self-heal.

// ---- PHP runtime hardening ----
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('html_errors', '0');
ini_set('log_errors', '1');

// Same timezone and error behaviour on every machine (override with SNAPIT_TZ).
@date_default_timezone_set(getenv('SNAPIT_TZ') ?: 'Asia/Manila');
// PHP < 8.1 does not throw on mysqli errors by default; the code expects exceptions.
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$snapitRoot = dirname(__DIR__);
$logsDir = $snapitRoot . DIRECTORY_SEPARATOR . 'logs';
if (!is_dir($logsDir)) {
    @mkdir($logsDir, 0755, true);
}
$errorLog = $logsDir . DIRECTORY_SEPARATOR . 'php_errors.log';
@ini_set('error_log', $errorLog);

// Static error page: NEVER redirects, so a failure can no longer cause a redirect loop.
if (!function_exists('snapit_static_error')) {
function snapit_static_error($title, array $lines, $code = 500) {
    if (!headers_sent()) { http_response_code($code); header('Content-Type: text/html; charset=utf-8'); }
    echo '<!doctype html><html><head><meta charset="utf-8"><title>' . htmlspecialchars($title) . '</title></head>'
       . '<body style="font-family:Segoe UI,Arial,sans-serif;background:#fafafa;color:#333;padding:48px;max-width:760px;margin:auto;">'
       . '<h2>' . htmlspecialchars($title) . '</h2>';
    foreach ($lines as $l) echo '<p>' . htmlspecialchars($l) . '</p>';
    echo '<p style="color:#777;font-size:.9em">Details are in <code>logs/php_errors.log</code>. Run <code>check.php</code> for a full diagnosis.</p></body></html>';
}
}

set_exception_handler(function (Throwable $e) {
    @error_log('[uncaught] ' . get_class($e) . ': ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    // Redirect once only; if we already bounced here, show a static page instead of looping.
    if (headers_sent() || isset($_GET['_err'])) {
        snapit_static_error('Something went wrong.', ['Please try again in a few moments.']);
    } else {
        require_once __DIR__ . '/functions.php';
        set_flash('Something went wrong while loading this page. Please try again, or contact support if the problem persists.', 'danger');
        header('Location: ' . site_url('index.php') . '?_err=1');
    }
    exit(1);
});

set_error_handler(function ($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    @error_log('[php:' . $severity . '] ' . $message . ' in ' . $file . ':' . $line);
    return false;
});

// ---- Database connection ----
// Defaults -> includes/config.local.php (written by install.php, per machine) -> environment variables.
$db_host = '127.0.0.1';   // 127.0.0.1 avoids the slow IPv6 "localhost" lookup on Windows/XAMPP
$db_port = 3306;
$db_username = 'root';
$db_passwd = '';
$db_name = 'db_snapit';
if (is_file(__DIR__ . '/config.local.php')) { include __DIR__ . '/config.local.php'; }
foreach (['host' => 'db_host', 'port' => 'db_port', 'user' => 'db_username', 'pass' => 'db_passwd', 'name' => 'db_name'] as $k => $v) {
    $envv = getenv('SNAPIT_DB_' . strtoupper($k));
    if ($envv !== false && $envv !== '') $$v = $envv;
}

$__onInstaller = basename($_SERVER['SCRIPT_NAME'] ?? '') === 'install.php';
$conn = null;
try {
    $conn = mysqli_connect($db_host, $db_username, $db_passwd, $db_name, (int)$db_port);
} catch (Throwable $__ex) {
    $__no = (int)$__ex->getCode();
    @error_log('[db] connect failed (' . $__no . '): ' . $__ex->getMessage());
    require_once __DIR__ . '/functions.php';
    if ($__no === 1049 && !$__onInstaller) {            // database does not exist yet -> first run
        header('Location: ' . site_url('install.php'));
    } elseif ($__no === 1045 || $__no === 1698) {
        snapit_static_error('Database login was refused.', ["MySQL rejected the username/password. Edit includes/config.local.php (or re-run install.php after deleting includes/installed.lock)."], 503);
    } elseif ($__no === 2002 || $__no === 2006 || $__no === 2003) {
        snapit_static_error('Cannot reach the MySQL server.', ["Start MySQL/MariaDB (XAMPP Control Panel -> MySQL -> Start) and check the port. Tried {$db_host}:{$db_port}. If MySQL runs on another port (often 3307), set it in includes/config.local.php."], 503);
    } else {
        snapit_static_error('Database is temporarily unavailable.', ['MySQL error ' . $__no . '. Please check the log.'], 503);
    }
    exit(1);
}

mysqli_set_charset($conn, "utf8mb4");
try { mysqli_query($conn, "SET time_zone = '" . date('P') . "'"); } catch (Throwable $__ex) {}

// ---- Mailer (PHPMailer SMTP). Credentials: env vars, then config.local.php, then blanks. ----
$mailtrap_user = $mailtrap_user ?? '';
$mailtrap_pass = $mailtrap_pass ?? '';
$google_smtp_user = $google_smtp_user ?? '';
$google_smtp_pass = $google_smtp_pass ?? '';
$MAILER = [
    'service'     => getenv('SNAPIT_MAILER_SERVICE') ?: ($mailer_service ?? 'mailtrap'),
    'from_email'  => getenv('SNAPIT_MAIL_FROM_EMAIL') ?: getenv('SNAPIT_FROM_EMAIL') ?: ($mail_from_email ?? 'no-reply@snapit.ph'),
    'from_name'   => getenv('SNAPIT_MAIL_FROM_NAME') ?: getenv('SNAPIT_FROM_NAME') ?: ($mail_from_name ?? 'Snap It Photo Booth'),
    'reply_to'    => getenv('SNAPIT_MAIL_REPLY_TO') ?: getenv('SNAPIT_REPLY_TO') ?: ($mail_reply_to ?? 'support@snapit.ph'),
    'charset'     => 'UTF-8',
    'debug_level' => (int)(getenv('SNAPIT_MAILER_DEBUG') ?: 0),
    'mailtrap'    => [
        'host'        => getenv('SNAPIT_MAILTRAP_HOST') ?: 'sandbox.smtp.mailtrap.io',
        'port'        => (int)(getenv('SNAPIT_MAILTRAP_PORT') ?: 2525),
        'username'    => getenv('SNAPIT_MAILTRAP_USER') ?: $mailtrap_user,
        'password'    => getenv('SNAPIT_MAILTRAP_PASS') ?: $mailtrap_pass,
        'smtp_secure' => getenv('SNAPIT_MAILTRAP_SECURE') ?: 'tls',
        'smtp_auth'   => true,
        'timeout'     => 20,
    ],
    'google'      => [
        'host'        => getenv('SNAPIT_GOOGLE_HOST') ?: 'smtp.gmail.com',
        'port'        => (int)(getenv('SNAPIT_GOOGLE_PORT') ?: 587),
        'username'    => getenv('SNAPIT_GOOGLE_USER') ?: $google_smtp_user,
        'password'    => getenv('SNAPIT_GOOGLE_PASS') ?: $google_smtp_pass,
        'smtp_secure' => 'tls',
        'smtp_auth'   => true,
        'timeout'     => 20,
    ],
];
if (!isset($MAILER[$MAILER['service']])) {
    $MAILER['service'] = 'mailtrap';
}

// ---- First-run detection + self-healing schema ----
if (session_status() === PHP_SESSION_NONE) { @session_start(); }
if (empty($_SESSION['schema_ok_v9'])) {
    $__t = mysqli_query($conn, "SHOW TABLES LIKE 'users'");
    if ($__t && mysqli_num_rows($__t) === 0 && !$__onInstaller) {
        require_once __DIR__ . '/functions.php';
        header('Location: ' . site_url('install.php'));
        exit;
    }
    $__ensure = [
        ['payments', 'status', "ALTER TABLE payments ADD COLUMN status ENUM('pending','completed','captured','failed','refunded_pending') NOT NULL DEFAULT 'completed' AFTER payment_date"],
        ['payments', 'gateway_reference', "ALTER TABLE payments ADD COLUMN gateway_reference VARCHAR(255) NULL AFTER or_number"],
        ['guest_sessions', 'countdown_seconds', "ALTER TABLE guest_sessions ADD COLUMN countdown_seconds TINYINT NOT NULL DEFAULT 3"],
        ['guest_sessions', 'mirror_preview', "ALTER TABLE guest_sessions ADD COLUMN mirror_preview TINYINT(1) NOT NULL DEFAULT 1"],
        ['guest_sessions', 'session_owner_user_id', "ALTER TABLE guest_sessions ADD COLUMN session_owner_user_id INT NULL AFTER guest_name, ADD INDEX idx_gs_owner (session_owner_user_id)"],
        ['packages', 'image_path', "ALTER TABLE packages ADD COLUMN image_path VARCHAR(255) NULL AFTER package_type"],
        ['users', 'avatar', "ALTER TABLE users ADD COLUMN avatar VARCHAR(255) NULL AFTER status"],
        ['bookings', 'inventory_deducted', "ALTER TABLE bookings ADD COLUMN inventory_deducted TINYINT(1) NOT NULL DEFAULT 0"],
        ['notifications', 'status', "ALTER TABLE notifications ADD COLUMN status ENUM('pending','sent','partial','failed') NOT NULL DEFAULT 'pending' AFTER message_body"],
        ['notifications', 'error_detail', "ALTER TABLE notifications ADD COLUMN error_detail VARCHAR(1000) NULL AFTER status"],
        ['notifications', 'message_id', "ALTER TABLE notifications ADD COLUMN message_id VARCHAR(255) NULL AFTER error_detail"],
        ['notifications', 'scheduled_at', "ALTER TABLE notifications ADD COLUMN scheduled_at DATETIME NULL AFTER message_id"],
        ['delivery_recipients', 'error_detail', "ALTER TABLE delivery_recipients ADD COLUMN error_detail VARCHAR(1000) NULL AFTER sent_at"],
        ['delivery_recipients', 'message_id', "ALTER TABLE delivery_recipients ADD COLUMN message_id VARCHAR(255) NULL AFTER error_detail"],
    ];
    foreach ($__ensure as $__e) {
        try {
            $__r = mysqli_query($conn, "SHOW COLUMNS FROM `{$__e[0]}` LIKE '{$__e[1]}'");
            if ($__r && mysqli_num_rows($__r) === 0) { mysqli_query($conn, $__e[2]); }
        } catch (Throwable $__ex) { @error_log('[schema] ' . $__ex->getMessage()); }
    }
    try {
        mysqli_query($conn, "CREATE TABLE IF NOT EXISTS package_photos (
            photo_id INT PRIMARY KEY AUTO_INCREMENT,
            package_id INT NOT NULL,
            file_name VARCHAR(255) NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_pp_package (package_id),
            FOREIGN KEY (package_id) REFERENCES packages(package_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $__ex) { @error_log('[schema] ' . $__ex->getMessage()); }
    try {
        mysqli_query($conn, "CREATE TABLE IF NOT EXISTS reviews (
            review_id INT PRIMARY KEY AUTO_INCREMENT,
            package_id INT NOT NULL,
            user_id INT NOT NULL,
            rating TINYINT NOT NULL,
            comment TEXT NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_review_user_package (user_id, package_id),
            INDEX idx_review_package (package_id),
            FOREIGN KEY (package_id) REFERENCES packages(package_id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $__ex) { @error_log('[schema] ' . $__ex->getMessage()); }
    // Order line items (2NF) + backfill for bookings made before this table existed.
    try {
        mysqli_query($conn, "CREATE TABLE IF NOT EXISTS booking_items (
            item_id INT PRIMARY KEY AUTO_INCREMENT,
            booking_id INT NOT NULL,
            package_id INT NOT NULL,
            item_type ENUM('package','addon') NOT NULL DEFAULT 'package',
            quantity INT NOT NULL DEFAULT 1,
            unit_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            UNIQUE KEY uq_booking_item (booking_id, item_type),
            FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
            FOREIGN KEY (package_id) REFERENCES packages(package_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        mysqli_query($conn, "INSERT IGNORE INTO booking_items (booking_id, package_id, item_type, quantity, unit_price)
            SELECT booking_id, package_id, 'package', 1, package_price FROM bookings");
        mysqli_query($conn, "INSERT IGNORE INTO booking_items (booking_id, package_id, item_type, quantity, unit_price)
            SELECT booking_id, package_id, 'addon', 1, addon_price FROM bookings WHERE softcopy_addon = 1");
    } catch (Throwable $__ex) { @error_log('[schema] booking_items: ' . $__ex->getMessage()); }
    // Order transaction views (commented originals live in includes/schema.sql).
    foreach ([
        "CREATE OR REPLACE VIEW vw_order_details AS SELECT b.booking_id, b.user_id, b.package_id, b.booking_type, b.event_name, b.event_date, b.start_time, b.duration_hours, b.venue, b.estimated_softcopies, b.estimated_hardcopies, b.softcopy_addon, b.hardcopy_delivery_name, b.hardcopy_delivery_address, b.hardcopy_delivery_contact, b.package_price, b.addon_price, b.total_amount, b.status, b.notes, b.created_at, u.name AS customer_name, u.email AS customer_email, p.name AS package_name, COALESCE(pay.amount_paid, 0) AS amount_paid, GREATEST(b.total_amount - COALESCE(pay.amount_paid, 0), 0) AS balance_due, COALESCE(pay.payment_count, 0) AS payment_count, pay.last_payment_date FROM bookings b INNER JOIN users u ON u.user_id = b.user_id INNER JOIN packages p ON p.package_id = b.package_id LEFT JOIN ( SELECT booking_id, SUM(amount_paid) AS amount_paid, COUNT(*) AS payment_count, MAX(payment_date) AS last_payment_date FROM payments WHERE status IN ('completed', 'captured') GROUP BY booking_id ) pay ON pay.booking_id = b.booking_id",
        "CREATE OR REPLACE VIEW vw_order_items AS SELECT i.booking_id, ROW_NUMBER() OVER (PARTITION BY i.booking_id ORDER BY i.item_id) AS line_no, CASE i.item_type WHEN 'package' THEN 'Package' ELSE 'Add-on' END AS item_type, CASE i.item_type WHEN 'package' THEN CONCAT(p.name, ' (', b.duration_hours, ' hrs)') ELSE 'Softcopy add-on' END AS item_name, i.quantity, i.unit_price, (i.quantity * i.unit_price) AS subtotal FROM booking_items i INNER JOIN bookings b ON b.booking_id = i.booking_id INNER JOIN packages p ON p.package_id = i.package_id",
    ] as $__view) {
        try { mysqli_query($conn, $__view); } catch (Throwable $__ex) { @error_log('[schema] view: ' . $__ex->getMessage()); }
    }
    try {
        $__nt = mysqli_query($conn, "SHOW COLUMNS FROM notifications LIKE 'type'");
        $__nrow = $__nt ? mysqli_fetch_assoc($__nt) : null;
        if ($__nrow && stripos($__nrow['Type'], 'booking_completed') === false) {
            mysqli_query($conn, "ALTER TABLE notifications MODIFY COLUMN type ENUM('booking_created','booking_confirmed','softcopy_sent','event_reminder','payment_received','booking_cancelled','booking_completed') NOT NULL");
        }
    } catch (Throwable $__ex) { @error_log('[schema] notifications.type: ' . $__ex->getMessage()); }
    try {
        $__idx = mysqli_query($conn, "SHOW INDEX FROM notifications WHERE Key_name = 'idx_notif_scheduled_type_status'");
        if (!$__idx || mysqli_num_rows($__idx) === 0) {
            mysqli_query($conn, "ALTER TABLE notifications ADD INDEX idx_notif_scheduled_type_status (scheduled_at, type, status)");
        }
    } catch (Throwable $__ex) { @error_log('[schema] notif index: ' . $__ex->getMessage()); }
    try {
        mysqli_query($conn, "CREATE TABLE IF NOT EXISTS password_resets (
            reset_id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            token_hash CHAR(64) NOT NULL,
            expires_at DATETIME NOT NULL,
            used_at DATETIME NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_pr_hash (token_hash),
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $__ex) { @error_log('[schema] password_resets: ' . $__ex->getMessage()); }
    $_SESSION['schema_ok_v9'] = 1;
}

// A deactivated user is logged out right away; a changed role applies on the next request.
if (!$__onInstaller) {
    require_once __DIR__ . '/functions.php';
    snapit_sync_session_user($conn);
}
