<?php
// Server-side photo-strip image builder (PHP GD). Replaces the old browser-side html2canvas PNG download.
// It reproduces the strip the CSS draws on screen: outer border, background, photo grid with gaps and rounded corners, and a caption line.

// Helper block: converts "#rrggbb" / "#rgb" text into a GD colour (falls back to the given default when the text is not a valid hex colour).
function strip_img_color($img, $hex, $default = '#ffffff', $alpha = 0) {
    $hex = ltrim(trim((string)$hex), '#');
    if (!preg_match('/^([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $hex)) $hex = ltrim($default, '#');
    if (strlen($hex) === 3) $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    return imagecolorallocatealpha($img, hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2)), $alpha);
}

// Helper block: loads an image file of any supported type; returns null when the file is missing or unreadable.
function strip_img_load($file) {
    if (!$file || !is_file($file)) return null;
    $im = @imagecreatefromstring((string)file_get_contents($file));
    return $im ?: null;
}

// Helper block: crops the photo to fill a w x h box (like CSS object-fit: cover) and rounds its corners; returns a transparent-cornered tile.
function strip_img_tile($src, $w, $h, $radius) {
    $w = max(1, (int)$w); $h = max(1, (int)$h);
    $tile = imagecreatetruecolor($w, $h);
    imagealphablending($tile, false);
    imagesavealpha($tile, true);
    imagefill($tile, 0, 0, imagecolorallocatealpha($tile, 0, 0, 0, 127));
    $sw = imagesx($src); $sh = imagesy($src);
    $scale = max($w / $sw, $h / $sh);
    $cw = (int)round($w / $scale); $ch = (int)round($h / $scale);
    imagecopyresampled($tile, $src, 0, 0, (int)(($sw - $cw) / 2), (int)(($sh - $ch) / 2), $w, $h, $cw, $ch);
    $r = min((int)$radius, (int)($w / 2), (int)($h / 2));
    if ($r > 0) {
        $clear = imagecolorallocatealpha($tile, 0, 0, 0, 127);
        for ($x = 0; $x < $r; $x++) {
            for ($y = 0; $y < $r; $y++) {
                if (($r - $x - 0.5) ** 2 + ($r - $y - 0.5) ** 2 > $r * $r) {
                    imagesetpixel($tile, $x, $y, $clear);
                    imagesetpixel($tile, $w - 1 - $x, $y, $clear);
                    imagesetpixel($tile, $x, $h - 1 - $y, $clear);
                    imagesetpixel($tile, $w - 1 - $x, $h - 1 - $y, $clear);
                }
            }
        }
    }
    return $tile;
}

// Helper block: finds a TrueType font on the server for the caption (Windows, Linux or macOS); null means "use the built-in GD font".
function strip_img_font() {
    foreach (['C:/Windows/Fonts/arial.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/dejavu/DejaVuSans.ttf', '/Library/Fonts/Arial.ttf', '/System/Library/Fonts/Supplemental/Arial.ttf'] as $f) {
        if (is_file($f)) return $f;
    }
    return null;
}

// Main block: builds the finished strip. $files = absolute paths of the kept photos (in order); $c = the config from strip_cfg().
// Returns a GD image (the caller outputs it as PNG), drawn at $scale x the on-screen size so the download is sharp.
function snapit_strip_image(array $files, array $c, $scale = 3) {
    // Size block: same width rules as strip_html() (2-inch strips are narrower) and the same aspect ratio from the layout's print size.
    $w = 520; $h = null;
    if (preg_match('/^(\d+)x(\d+)$/', $c['print'] ?? '', $m) && (int)$m[2] > 0) {
        $w = ((int)$m[1] <= 2) ? 270 : 400;
        $h = $w * (int)$m[2] / (int)$m[1];
    }
    $cols = max(1, (int)$c['cols']); $rows = max(1, (int)$c['rows']);
    $bw = max(0, (int)$c['bw']); $gap = max(0, (int)$c['gap']); $rad = max(0, (int)$c['rad']);
    $pad = $gap * 1.4;
    $foot = $gap * 1.2 + 16;                                  // caption line height + the space above it
    $gridW = $w - 2 * ($bw + $pad);
    $cellW = ($gridW - ($cols - 1) * $gap) / $cols;
    if ($h === null) {                                        // no print size: photos are 4:3 and the strip grows to fit
        $cellH = $cellW * 3 / 4;
        $h = 2 * ($bw + $pad) + $rows * $cellH + ($rows - 1) * $gap + $foot;
    } else {
        $cellH = (($h - 2 * ($bw + $pad) - $foot) - ($rows - 1) * $gap) / $rows;
    }
    $S = (float)$scale;
    $img = imagecreatetruecolor((int)round($w * $S), (int)round($h * $S));
    imagealphablending($img, true);

    // Background + border block: fills the whole strip with the frame's border colour, then the inner area with its background colour.
    imagefilledrectangle($img, 0, 0, imagesx($img), imagesy($img), strip_img_color($img, $c['bc'] ?? '', '#6f42c1'));
    $bgc = strip_img_color($img, $c['bg'] ?? '', '#ffffff');
    imagefilledrectangle($img, (int)round($bw * $S), (int)round($bw * $S), imagesx($img) - (int)round($bw * $S) - 1, imagesy($img) - (int)round($bw * $S) - 1, $bgc);

    // Pattern block: the "dots" frame pattern is a grid of small translucent grey dots.
    if (($c['pattern'] ?? '') === 'dots') {
        $dot = imagecolorallocatealpha($img, 128, 128, 128, 96);
        for ($y = $bw + 7; $y < $h - $bw; $y += 14) {
            for ($x = $bw + 7; $x < $w - $bw; $x += 14) {
                imagefilledellipse($img, (int)round($x * $S), (int)round($y * $S), (int)round(1.6 * $S), (int)round(1.6 * $S), $dot);
            }
        }
    }

    // Photo block: places each photo (or an empty grey slot) into its grid cell, row by row.
    $count = max((int)($c['count'] ?? 1), count($files));
    $slot  = imagecolorallocatealpha($img, 128, 128, 128, 108);
    for ($i = 0; $i < $count; $i++) {
        $col = $i % $cols; $row = intdiv($i, $cols);
        if ($row >= $rows) break;
        $x = ($bw + $pad + $col * ($cellW + $gap)) * $S;
        $y = ($bw + $pad + $row * ($cellH + $gap)) * $S;
        $src = isset($files[$i]) ? strip_img_load($files[$i]) : null;
        if ($src) {
            $tile = strip_img_tile($src, $cellW * $S, $cellH * $S, $rad * $S);
            imagecopy($img, $tile, (int)round($x), (int)round($y), 0, 0, imagesx($tile), imagesy($tile));
        } else {
            imagefilledrectangle($img, (int)round($x), (int)round($y), (int)round($x + $cellW * $S) - 1, (int)round($y + $cellH * $S) - 1, $slot);
        }
    }

    // Caption block: the event name and date centred under the photos, in the frame's text colour.
    $caption = trim((string)($c['caption'] ?? ''));
    if ($caption !== '') {
        $fg   = strip_img_color($img, $c['fg'] ?? '', '#333333');
        $font = strip_img_font();
        $baseY = (int)round(($h - $bw - $pad * 0.6) * $S);
        if ($font && function_exists('imagettftext')) {
            $size = 11 * $S * 0.75;
            $box  = imagettfbbox($size, 0, $font, $caption);
            imagettftext($img, $size, 0, (int)round((imagesx($img) - ($box[2] - $box[0])) / 2), $baseY, $fg, $font, $caption);
        } else {                                              // built-in font fallback: draw small, then enlarge
            $tw = imagefontwidth(3) * strlen($caption); $th = imagefontheight(3);
            $tmp = imagecreatetruecolor($tw, $th);
            imagealphablending($tmp, false); imagesavealpha($tmp, true);
            imagefill($tmp, 0, 0, imagecolorallocatealpha($tmp, 0, 0, 0, 127));
            imagestring($tmp, 3, 0, 0, $caption, imagecolorallocate($tmp, ...sscanf(ltrim((string)($c['fg'] ?? '#333333'), '#') . '', '%2x%2x%2x') ?: [51, 51, 51]));
            $dw = (int)round($tw * $S * 0.9); $dh = (int)round($th * $S * 0.9);
            imagealphablending($img, true);
            imagecopyresampled($img, $tmp, (int)round((imagesx($img) - $dw) / 2), $baseY - $dh, 0, 0, $dw, $dh, $tw, $th);
        }
    }
    return $img;
}
