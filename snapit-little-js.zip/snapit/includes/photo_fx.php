<?php
// Photo effects in plain PHP (GD). They replace the browser canvas code and includes/camfx.js, so the booth needs no JavaScript.
// Every photo goes through ONE function, photo_fx_apply(): colour filter -> fade -> grain -> vignette, in a single pass over the pixels.

// ---------------------------------------------------------------------
// Block 1: reading the filter text ("sepia(.2) contrast(1.1)") stored in the database
// ---------------------------------------------------------------------

/** Splits a CSS-style filter text into a list like [['sepia', 0.2], ['contrast', 1.1]]. Unknown words (like blur) are ignored. */
function photo_fx_parse($css) {
    $list = [];
    if (!is_string($css) || trim($css) === '' || trim($css) === 'none') return $list;
    preg_match_all('/([a-z-]+)\(\s*(-?[0-9.]+)\s*(deg|px|%)?\s*\)/i', $css, $found, PREG_SET_ORDER);
    foreach ($found as $f) {
        $name = strtolower($f[1]);
        $value = (float)$f[2];
        if (($f[3] ?? '') === '%') $value /= 100;
        if (in_array($name, ['brightness', 'contrast', 'saturate', 'sepia', 'grayscale', 'hue-rotate', 'invert'], true)) {
            $list[] = [$name, $value];
        }
    }
    return $list;
}

// ---------------------------------------------------------------------
// Block 2: each colour filter is a small table of numbers (3 rows x 4 columns).
// Row = how much of R, G, B go into the new red / green / blue, the 4th number is a constant that is added.
// ---------------------------------------------------------------------

/** Table for ONE filter, e.g. photo_fx_table('sepia', 0.2). */
function photo_fx_table($name, $v) {
    switch ($name) {
        case 'brightness':   // multiply every colour
            return [[$v, 0, 0, 0], [0, $v, 0, 0], [0, 0, $v, 0]];
        case 'contrast':     // stretch the colours around the middle grey
            $o = 0.5 - 0.5 * $v;
            return [[$v, 0, 0, $o], [0, $v, 0, $o], [0, 0, $v, $o]];
        case 'saturate':     // 0 = grey, 1 = normal, 2 = very colourful
            return [[0.213 + 0.787 * $v, 0.715 - 0.715 * $v, 0.072 - 0.072 * $v, 0],
                    [0.213 - 0.213 * $v, 0.715 + 0.285 * $v, 0.072 - 0.072 * $v, 0],
                    [0.213 - 0.213 * $v, 0.715 - 0.715 * $v, 0.072 + 0.928 * $v, 0]];
        case 'grayscale':    // 1 = fully black and white
            $a = 1 - max(0, min(1, $v));
            return [[0.2126 + 0.7874 * $a, 0.7152 - 0.7152 * $a, 0.0722 - 0.0722 * $a, 0],
                    [0.2126 - 0.2126 * $a, 0.7152 + 0.2848 * $a, 0.0722 - 0.0722 * $a, 0],
                    [0.2126 - 0.2126 * $a, 0.7152 - 0.7152 * $a, 0.0722 + 0.9278 * $a, 0]];
        case 'sepia':        // old brown photo look
            $a = 1 - max(0, min(1, $v));
            return [[0.393 + 0.607 * $a, 0.769 - 0.769 * $a, 0.189 - 0.189 * $a, 0],
                    [0.349 - 0.349 * $a, 0.686 + 0.314 * $a, 0.168 - 0.168 * $a, 0],
                    [0.272 - 0.272 * $a, 0.534 - 0.534 * $a, 0.131 + 0.869 * $a, 0]];
        case 'hue-rotate':   // turn every colour around the colour wheel (degrees)
            $c = cos(deg2rad($v));
            $s = sin(deg2rad($v));
            return [[0.213 + $c * 0.787 - $s * 0.213, 0.715 - $c * 0.715 - $s * 0.715, 0.072 - $c * 0.072 + $s * 0.928, 0],
                    [0.213 - $c * 0.213 + $s * 0.143, 0.715 + $c * 0.285 + $s * 0.140, 0.072 - $c * 0.072 - $s * 0.283, 0],
                    [0.213 - $c * 0.213 - $s * 0.787, 0.715 - $c * 0.715 + $s * 0.715, 0.072 + $c * 0.928 + $s * 0.072, 0]];
        case 'invert':
            $a = max(0, min(1, $v));
            return [[1 - 2 * $a, 0, 0, $a], [0, 1 - 2 * $a, 0, $a], [0, 0, 1 - 2 * $a, $a]];
    }
    return [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0]];
}

/** Joins two tables into one (apply $a first, then $b), so a whole filter list becomes ONE table. */
function photo_fx_join($a, $b) {
    $out = [];
    for ($i = 0; $i < 3; $i++) {
        for ($j = 0; $j < 3; $j++) {
            $out[$i][$j] = $b[$i][0] * $a[0][$j] + $b[$i][1] * $a[1][$j] + $b[$i][2] * $a[2][$j];
        }
        $out[$i][3] = $b[$i][0] * $a[0][3] + $b[$i][1] * $a[1][3] + $b[$i][2] * $a[2][3] + $b[$i][3];
    }
    return $out;
}

/** Turns the whole filter text into one table. */
function photo_fx_combined_table($css) {
    $table = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0]];   // "do nothing" table
    foreach (photo_fx_parse($css) as [$name, $value]) {
        $table = photo_fx_join($table, photo_fx_table($name, $value));
    }
    return $table;
}

// ---------------------------------------------------------------------
// Block 3: the main function. Walks over every pixel once.
//   $fade, $grain, $vignette are 0-100 (the preset's film effects).
// ---------------------------------------------------------------------
function photo_fx_apply($img, $css_filter, $fade = 0, $grain = 0, $vignette = 0) {
    $w = imagesx($img);
    $h = imagesy($img);
    $m = photo_fx_combined_table($css_filter);

    // Film-effect numbers worked out once, not for every pixel.
    $fade_a  = max(0, min(100, (int)$fade)) / 100;
    $grain_a = max(0, min(100, (int)$grain)) / 100 * 0.6;
    $vig     = max(0, min(100, (int)$vignette)) / 100 * 0.9;
    $fade_c  = [40 / 255, 36 / 255, 32 / 255];                // the faded "milky" colour
    $cx = $w / 2;  $cy = $h / 2;
    $r0 = min($w, $h) * 0.3;                                   // vignette starts here
    $r1 = hypot($w, $h) / 2;                                   // and is darkest in the corners

    for ($y = 0; $y < $h; $y++) {
        for ($x = 0; $x < $w; $x++) {
            $rgb = imagecolorat($img, $x, $y);
            $r = (($rgb >> 16) & 255) / 255;
            $g = (($rgb >> 8) & 255) / 255;
            $b = ($rgb & 255) / 255;

            // 1. colour filter (brightness, contrast, sepia, ...)
            $nr = $m[0][0] * $r + $m[0][1] * $g + $m[0][2] * $b + $m[0][3];
            $ng = $m[1][0] * $r + $m[1][1] * $g + $m[1][2] * $b + $m[1][3];
            $nb = $m[2][0] * $r + $m[2][1] * $g + $m[2][2] * $b + $m[2][3];
            $r = $nr < 0 ? 0 : ($nr > 1 ? 1 : $nr);
            $g = $ng < 0 ? 0 : ($ng > 1 ? 1 : $ng);
            $b = $nb < 0 ? 0 : ($nb > 1 ? 1 : $nb);

            // 2. fade: lifts the dark colours towards a soft grey ("screen" blend)
            if ($fade_a > 0) {
                $r = (1 - $fade_a) * $r + $fade_a * (1 - (1 - $r) * (1 - $fade_c[0]));
                $g = (1 - $fade_a) * $g + $fade_a * (1 - (1 - $g) * (1 - $fade_c[1]));
                $b = (1 - $fade_a) * $b + $fade_a * (1 - (1 - $b) * (1 - $fade_c[2]));
            }

            // 3. grain: random speckles ("overlay" blend with a random grey)
            if ($grain_a > 0) {
                $n = mt_rand(0, 255) / 255;
                $r += $grain_a * (($r < 0.5 ? 2 * $r * $n : 1 - 2 * (1 - $r) * (1 - $n)) - $r);
                $g += $grain_a * (($g < 0.5 ? 2 * $g * $n : 1 - 2 * (1 - $g) * (1 - $n)) - $g);
                $b += $grain_a * (($b < 0.5 ? 2 * $b * $n : 1 - 2 * (1 - $b) * (1 - $n)) - $b);
            }

            // 4. vignette: the farther from the centre, the darker
            if ($vig > 0) {
                $u = (hypot($x - $cx, $y - $cy) - $r0) / ($r1 - $r0);
                $u = $u < 0 ? 0 : ($u > 1 ? 1 : $u);
                if ($u > 0.55) {
                    $k = 1 - $vig * (($u - 0.55) / 0.45);
                    $r *= $k;  $g *= $k;  $b *= $k;
                }
            }

            imagesetpixel($img, $x, $y, (((int)round($r * 255)) << 16) | (((int)round($g * 255)) << 8) | ((int)round($b * 255)));
        }
    }
    return $img;
}

// ---------------------------------------------------------------------
// Block 4: which filter text and effects does a booth session use?
// ---------------------------------------------------------------------

/** Reads the look of one booth session (preset + guest's filter + mirror). Returns null when the session does not exist. */
function booth_session_look($conn, $session_id) {
    $stmt = mysqli_prepare($conn, "SELECT gs.mirror_preview, gs.countdown_seconds,
        cp.brightness AS p_bri, cp.contrast AS p_con, cp.saturation AS p_sat, cp.warmness AS p_wrm, cp.cam_filter, cp.fx_grain, cp.fx_vignette, cp.fx_fade,
        f.css_filter
        FROM guest_sessions gs
        LEFT JOIN camera_presets cp ON gs.camera_preset_id = cp.preset_id
        LEFT JOIN filters f ON gs.filter_id = f.filter_id
        WHERE gs.session_id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $session_id);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    return $row ? photo_fx_look_from_row($row) : null;
}

/** Builds the final filter text + effect numbers from one database row (preset columns and filter column). */
function photo_fx_look_from_row($row) {
    $css = trim((string)($row['cam_filter'] ?? ''));
    if ($css === '') {
        // No ready-made text on the preset: build it from its brightness / contrast / saturation / warmth numbers.
        $bri = (int)($row['p_bri'] ?? 0);
        $con = (int)($row['p_con'] ?? 0);
        $sat = (int)($row['p_sat'] ?? 0);
        $wrm = (int)($row['p_wrm'] ?? 0);
        $parts = ['brightness(' . (1 + $bri / 100) . ')', 'contrast(' . (1 + $con / 100) . ')', 'saturate(' . max(0, 1 + $sat / 100) . ')'];
        if ($wrm > 0) $parts[] = 'sepia(' . min(0.6, $wrm / 200) . ')';
        elseif ($wrm < 0) $parts[] = 'hue-rotate(' . $wrm . 'deg)';
        $css = implode(' ', $parts);
    }
    $guest = trim((string)($row['css_filter'] ?? ''));
    if ($guest !== '' && $guest !== 'none') $css .= ' ' . $guest;
    return [
        'css'      => $css,
        'fade'     => (int)($row['fx_fade'] ?? 0),
        'grain'    => (int)($row['fx_grain'] ?? 0),
        'vignette' => (int)($row['fx_vignette'] ?? 0),
        'mirror'   => (int)($row['mirror_preview'] ?? 0) === 1,
    ];
}

// ---------------------------------------------------------------------
// Block 5: file helper. Opens a JPG, shrinks it, mirrors it, applies the look and saves it again.
// ---------------------------------------------------------------------
function photo_fx_process_file($in, $out, $look, $max_width = 1000) {
    $img = @imagecreatefromjpeg($in);
    if (!$img) {
        $img = @imagecreatefromstring((string)@file_get_contents($in));
    }
    if (!$img) return false;
    if (!imageistruecolor($img)) imagepalettetotruecolor($img);
    if (imagesx($img) > $max_width) {
        $small = imagescale($img, $max_width);
        if ($small) { imagedestroy($img); $img = $small; }
    }
    if (!empty($look['mirror'])) imageflip($img, IMG_FLIP_HORIZONTAL);
    photo_fx_apply($img, $look['css'] ?? '', $look['fade'] ?? 0, $look['grain'] ?? 0, $look['vignette'] ?? 0);
    $ok = imagejpeg($img, $out, 90);
    imagedestroy($img);
    return $ok;
}
