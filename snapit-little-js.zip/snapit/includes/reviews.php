<?php
// Package review helpers: who may review, bad-word masking, listing reviews and rating summaries.
/* ---------------------------------------------------------------------
   Package reviews: eligibility, queries, rendering and the bad-word filter
   --------------------------------------------------------------------- */

// A customer "availed" a package once a booking for it reaches one of these statuses.
const REVIEW_ELIGIBLE_STATUSES = ['completed'];
const REVIEW_MIN_LEN = 5;
const REVIEW_MAX_LEN = 1000;

/** Words to mask (lowercase). A space inside an entry matches any gap, e.g. "putang ina" / "putang-ina". */
function review_bad_words() {
    return [
        'fuck', 'fucker', 'shit', 'bullshit', 'bitch', 'asshole', 'ass', 'dick', 'bastard', 'crap', 'damn', 'piss', 'slut', 'whore',
        'putang ina', 'putangina', 'tangina', 'puta', 'gago', 'gaga', 'bobo', 'tanga', 'ulol', 'tarantado', 'pakyu', 'leche', 'inutil', 'hayop',
    ];
}

/** Letters that people swap for look-alike characters (f*ck, sh1t, a$$ ...). */
function review_char_class($ch) {
    static $map = [
        'a' => '[a@4]', 'e' => '[e3]', 'i' => '[i1!]', 'o' => '[o0]', 's' => '[s$5]', 't' => '[t7]', 'u' => '[uv]',
    ];
    return $map[$ch] ?? '[' . preg_quote($ch, '/') . ']';
}

/** One regex covering every bad word: repeated letters, look-alikes and separators allowed, whole words only. */
function review_bad_word_regex() {
    static $re = null;
    if ($re !== null) return $re;
    $alts = [];
    foreach (review_bad_words() as $word) {
        $parts = [];
        foreach (preg_split('/\s+/', $word) as $piece) {
            $letters = [];
            foreach (str_split($piece) as $ch) $letters[] = review_char_class($ch) . '+';
            $parts[] = implode('[.\-_*]*', $letters);          // f.u.c.k / f-u-c-k
        }
        $alts[] = implode('[\s.\-_*]*', $parts);               // gap between words
    }
    // Optional ending so "damned", "shitty", "fucking", "f.u.c.k.i.n.g" are caught too.
    $endings = [];
    foreach (['s', 'es', 'ed', 'ing', 'y'] as $suffix) {
        $endings[] = implode('[.\-_*]*', array_map('review_char_class', str_split($suffix)));
    }
    // Unicode-aware word edges so "class" / "assessment" are never touched.
    $re = '/(?<![\p{L}\p{N}])(?:' . implode('|', $alts) . ')(?:[.\-_*]*(?:' . implode('|', $endings) . '))?(?![\p{L}\p{N}])/iu';
    return $re;
}

/** Replace every bad word with asterisks of the same length. Safe to run more than once. */
function mask_bad_words($text) {
    $out = preg_replace_callback(review_bad_word_regex(), function ($m) {
        return str_repeat('*', mb_strlen($m[0]));
    }, (string)$text);
    return $out === null ? (string)$text : $out;   // null only on a regex error: never lose the review
}

/** True when this user has a booking for the package in an eligible status. */
function review_user_eligible($conn, $user_id, $package_id) {
    $in = implode(',', array_fill(0, count(REVIEW_ELIGIBLE_STATUSES), '?'));
    // Query block: reads from bookings.
    $st = mysqli_prepare($conn, "SELECT COUNT(*) FROM bookings WHERE user_id = ? AND package_id = ? AND status IN ($in)");
    $uid = (int)$user_id; $pid = (int)$package_id;
    $types = 'ii' . str_repeat('s', count(REVIEW_ELIGIBLE_STATUSES));
    $params = array_merge([$uid, $pid], REVIEW_ELIGIBLE_STATUSES);
    mysqli_stmt_bind_param($st, $types, ...$params);
    mysqli_stmt_execute($st);
    return (int)(mysqli_fetch_row(mysqli_stmt_get_result($st))[0] ?? 0) > 0;
}

/** The user's own review of a package, or null. */
function review_for_user($conn, $user_id, $package_id) {
    // Query block: reads from reviews.
    $st = mysqli_prepare($conn, "SELECT * FROM reviews WHERE user_id = ? AND package_id = ? LIMIT 1");
    $uid = (int)$user_id; $pid = (int)$package_id;
    mysqli_stmt_bind_param($st, 'ii', $uid, $pid);
    mysqli_stmt_execute($st);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($st)) ?: null;
}

/** All reviews of a package, newest first, with the reviewer's name. */
function package_reviews($conn, $package_id) {
    // Query block: reads from the database.
    $st = mysqli_prepare($conn, "SELECT r.review_id, r.user_id, r.rating, r.comment, r.created_at, r.updated_at, u.name
        FROM reviews r INNER JOIN users u ON u.user_id = r.user_id
        WHERE r.package_id = ? ORDER BY r.updated_at DESC, r.review_id DESC");
    $pid = (int)$package_id;
    mysqli_stmt_bind_param($st, 'i', $pid);
    mysqli_stmt_execute($st);
    $res = mysqli_stmt_get_result($st);
    $rows = [];
    while ($r = mysqli_fetch_assoc($res)) $rows[] = $r;
    return $rows;
}

/** [average rating (float), number of reviews (int)] */
function package_rating_summary($conn, $package_id) {
    // Query block: reads from reviews.
    $st = mysqli_prepare($conn, "SELECT AVG(rating), COUNT(*) FROM reviews WHERE package_id = ?");
    $pid = (int)$package_id;
    mysqli_stmt_bind_param($st, 'i', $pid);
    mysqli_stmt_execute($st);
    $row = mysqli_fetch_row(mysqli_stmt_get_result($st));
    return [(float)($row[0] ?? 0), (int)($row[1] ?? 0)];
}

/** Five Font Awesome stars, filled up to $rating. */
function render_stars($rating) {
    $rating = max(0, min(5, (int)round($rating)));
    $html = '<span class="text-warning" aria-label="' . $rating . ' out of 5 stars">';
    for ($i = 1; $i <= 5; $i++) {
        $html .= '<i class="' . ($i <= $rating ? 'fa-solid' : 'fa-regular') . ' fa-star"></i>';
    }
    return $html . '</span>';
}
