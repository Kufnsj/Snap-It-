// The only JavaScript of the booth: open the webcam, show it live, count down, take the picture.
var video  = document.getElementById('cameraVideo');
var button = document.getElementById('captureBtn');
var shout  = document.getElementById('countdown');
var form   = document.getElementById('captureForm');

// 1. Ask the browser for the camera and show it live in the <video> tag.
navigator.mediaDevices.getUserMedia({ video: true }).then(function (stream) {
  video.srcObject = stream;
  video.onloadedmetadata = function () { button.disabled = false; };   // the picture is ready
}).catch(function () {
  document.getElementById('cameraMsg').textContent = 'The camera is blocked or not found. Allow it in the address bar and refresh.';
});

// 2. When the button is pressed: count down 3-2-1, then take the picture.
button.onclick = function () {
  var left = parseInt(form.getAttribute('data-countdown'), 10);
  button.disabled = true;
  shout.textContent = left;
  var timer = setInterval(function () {
    left = left - 1;
    shout.textContent = left > 0 ? left : '';
    if (left <= 0) { clearInterval(timer); takePhoto(); }
  }, 1000);
};

// 3. Copy the current video frame onto a canvas, put it in the hidden field and send the form to PHP.
function takePhoto() {
  var canvas = document.createElement('canvas');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext('2d').drawImage(video, 0, 0);
  form.image_data.value = canvas.toDataURL('image/jpeg', 0.92);
  form.submit();
}
