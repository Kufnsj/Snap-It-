<?php
// Staff handler: marks a paid booking as completed and emails the customer.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/mailer.php';
// Guard block: only staff and admins can use this page.
require_staff();
// Request + security block: POST with a valid CSRF token only.
require_post_csrf(site_url('booking/index.php'));

$booking_id = (int)($_POST['id'] ?? 0);

if ($booking_id <= 0) {
    set_flash('Invalid booking reference.', 'danger');
    redirect(site_url('booking/index.php'));
}

// Query block: reads from the database.
$stmt = mysqli_prepare($conn, "SELECT b.*, u.email AS customer_email, u.name AS customer_name
    FROM bookings b INNER JOIN users u ON b.user_id = u.user_id
    WHERE b.booking_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $booking_id);
mysqli_stmt_execute($stmt);
$booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$booking) {
    set_flash('Booking not found.', 'danger');
    redirect(site_url('booking/index.php'));
}

if ($booking['status'] !== 'paid') {
    set_flash('Only fully paid bookings can be marked as completed.', 'warning');
    redirect(site_url('booking/view.php?id=' . $booking_id));
}

$new_status = 'completed';
// Update block: changes rows in bookings.
$upd = mysqli_prepare($conn, "UPDATE bookings SET status = ? WHERE booking_id = ?");
mysqli_stmt_bind_param($upd, 'si', $new_status, $booking_id);
mysqli_stmt_execute($upd);

$send = snapit_send_order_status_email($conn, $booking_id, 'booking_completed');
snapit_mail_flash('Booking #' . $booking_id . ' has been marked as completed.', $send);
redirect(site_url('booking/view.php?id=' . $booking_id));
