<?php
// Customer handler: receives the booking form from create.php, validates it, recalculates the price on the server and saves the booking.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
// Guard block: only logged-in users can book.
require_login();

// Request check block: only POST submissions are accepted.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(site_url('booking/create.php'));
}

// Security block: rejects forms without a valid CSRF token.
if (!verify_csrf($_POST['csrf_token'] ?? '')) {
    set_flash('Invalid form submission. Please try again.', 'danger');
    redirect(site_url('booking/create.php'));
}

// Input block: reads and trims the submitted form fields.
$package_id = (int)($_POST['package_id'] ?? 0);
$back_url = site_url('booking/create.php' . ($package_id > 0 ? '?package=' . $package_id : ''));
$event_name = trim($_POST['event_name'] ?? '');
$event_date = trim($_POST['event_date'] ?? '');
$start_time = trim($_POST['start_time'] ?? '');

$venue = trim($_POST['venue'] ?? '');
$softcopy_addon = isset($_POST['softcopy_addon']) && (int)$_POST['softcopy_addon'] === 1 ? 1 : 0;
$hardcopy_delivery_name = trim($_POST['hardcopy_delivery_name'] ?? '') ?: null;
$hardcopy_delivery_address = trim($_POST['hardcopy_delivery_address'] ?? '') ?: null;
$hardcopy_delivery_contact = trim($_POST['hardcopy_delivery_contact'] ?? '') ?: null;
$notes = trim($_POST['notes'] ?? '') ?: null;

// Validation block: checks the name, date (at least 1 day ahead), time format and venue.
$errors = [];

if ($package_id <= 0) {
    $errors[] = 'Please select a valid package.';
}
if (strlen($event_name) < 2 || strlen($event_name) > 200) {
    $errors[] = 'Event name must be between 2 and 200 characters.';
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $event_date)) {
    $errors[] = 'Invalid event date format.';
}
if (is_date_past($event_date)) {
    $errors[] = 'Event date cannot be in the past.';
}
$tomorrow = date('Y-m-d', strtotime('+1 day'));
if ($event_date < $tomorrow) {
    $errors[] = 'Bookings must be made at least 1 day in advance.';
}
if (!preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $start_time)) {
    $errors[] = 'Invalid start time format.';
}
if (strlen($venue) < 5) {
    $errors[] = 'Please provide a valid venue/address (at least 5 characters).';
}

if (!empty($errors)) {
    set_flash(implode(' ', $errors), 'danger');
    redirect($back_url);
}

// Package block: reloads the chosen package from the database (never trusts the price or duration sent by the browser).
$pkg_stmt = mysqli_prepare($conn, "SELECT * FROM packages WHERE package_id = ? AND is_active = 1 AND package_type = 'event' LIMIT 1");
mysqli_stmt_bind_param($pkg_stmt, 'i', $package_id);
mysqli_stmt_execute($pkg_stmt);
$pkg_result = mysqli_stmt_get_result($pkg_stmt);
$pkg = mysqli_fetch_assoc($pkg_result);

if (!$pkg) {
    set_flash('The selected package is no longer available.', 'danger');
    redirect($back_url);
}

// Rules block: duration and copy counts come from the package; the add-on is only allowed when the package offers it.
// Duration and copy counts are fixed by the package (no free choice).
$estimated_softcopies = (int)$pkg['softcopy_count'];
$estimated_hardcopies = (int)$pkg['hardcopy_count'];
$duration_hours = (int)$pkg['duration_hours'];
if ($softcopy_addon && (!(int)$pkg['has_softcopy_addon'] || (int)$pkg['softcopy_count'] > 0)) {
    $softcopy_addon = 0;
}
if (!in_business_hours($start_time, $duration_hours)) {
    $errors[] = 'Booking is outside business hours (8:00 AM to 10:00 PM). Please adjust the time or duration.';
}
if (booking_has_conflict($conn, $event_date, $start_time, $duration_hours)) {
    $errors[] = 'This time slot is not available. Events need a 1-hour gap between bookings, so please choose a different date or time.';
}

if (!empty($errors)) {
    set_flash(implode(' ', $errors), 'danger');
    redirect($back_url);
}

// Price block: total = package price + optional soft-copy add-on, calculated here on the server.
$package_price = (float)$pkg['base_price'];
$addon_price = $softcopy_addon ? (float)$pkg['softcopy_addon_price'] : 0.00;
$total_amount = $package_price + $addon_price;
$status = 'pending';
$user_id = $_SESSION['user_id'];

// Save block: inserts the booking as 'pending'.
$ins_stmt = mysqli_prepare($conn, "INSERT INTO bookings
    (user_id, package_id, event_name, event_date, start_time, duration_hours, venue,
     estimated_softcopies, estimated_hardcopies, softcopy_addon,
     hardcopy_delivery_name, hardcopy_delivery_address, hardcopy_delivery_contact,
     package_price, addon_price, total_amount, status, notes)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
mysqli_stmt_bind_param($ins_stmt, 'iisssisssisssddsss',
    $user_id, $package_id, $event_name, $event_date, $start_time, $duration_hours, $venue,
    $estimated_softcopies, $estimated_hardcopies, $softcopy_addon,
    $hardcopy_delivery_name, $hardcopy_delivery_address, $hardcopy_delivery_contact,
    $package_price, $addon_price, $total_amount, $status, $notes);

if (!mysqli_stmt_execute($ins_stmt)) {
    set_flash('Failed to create booking. Please try again.', 'danger');
    redirect($back_url);
}

$new_booking_id = mysqli_insert_id($conn);

// Line-items block (see below).
// Line items: the package, plus the softcopy add-on when chosen.
$it = mysqli_prepare($conn, "INSERT INTO booking_items (booking_id, package_id, item_type, quantity, unit_price) VALUES (?, ?, ?, 1, ?)");
$t = 'package'; mysqli_stmt_bind_param($it, 'iisd', $new_booking_id, $package_id, $t, $package_price); mysqli_stmt_execute($it);
if ($softcopy_addon) { $t = 'addon'; mysqli_stmt_bind_param($it, 'iisd', $new_booking_id, $package_id, $t, $addon_price); mysqli_stmt_execute($it); }

// Email block: sends the "booking created" email and opens the new booking page.
require_once __DIR__ . '/../includes/mailer.php';
$send = snapit_send_order_status_email($conn, $new_booking_id, 'booking_created');
snapit_mail_flash('Booking #' . $new_booking_id . ' created successfully. Awaiting confirmation.', $send);
redirect(site_url('booking/view.php?id=' . $new_booking_id));
