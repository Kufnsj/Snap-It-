<?php
// Customer page: the event booking form. Step 1 picks a package (page reloads with its details); step 2 fills in the event and posts to store.php.
// All prices and allowed start hours are calculated by PHP here, so no JavaScript is needed.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
// Guard block: only logged-in users can book.
require_login();

// Package-choice block: reads the package picked in step 1 (?package=ID).
$preselected_package = isset($_GET['package']) ? (int)$_GET['package'] : 0;

// Package-list block: loads the active event packages for the drop-down.
$pkg_stmt = mysqli_prepare($conn, "SELECT * FROM packages WHERE is_active = 1 AND package_type = 'event' ORDER BY base_price ASC");
mysqli_stmt_execute($pkg_stmt);
$pkg_result = mysqli_stmt_get_result($pkg_stmt);

$packages = [];
while ($p = mysqli_fetch_assoc($pkg_result)) {
    $packages[] = $p;
}

// Date block: earliest bookable date (bookings need at least 1 day notice).
$tomorrow = date('Y-m-d', strtotime('+1 day'));

// Selected-package block: finds the chosen package in the list.
$selected_pkg = null;
if ($preselected_package > 0) {
    foreach ($packages as $p) {
        if ($p['package_id'] == $preselected_package) {
            $selected_pkg = $p;
            break;
        }
    }
}

// Price block: the package price, add-on price and totals are calculated here in PHP (this replaces the old JavaScript live calculator).
$addon_available = $selected_pkg && (int)$selected_pkg['has_softcopy_addon'] === 1 && (int)$selected_pkg['softcopy_count'] === 0;
$base_price      = $selected_pkg ? (float)$selected_pkg['base_price'] : 0.0;
$addon_price     = $addon_available ? (float)$selected_pkg['softcopy_addon_price'] : 0.0;

// Start-time block: only hours that still end by 10 PM for the chosen package's fixed duration are offered (replaces the JavaScript that disabled late hours).
$pkg_hours = $selected_pkg ? (int)$selected_pkg['duration_hours'] : 0;
$start_hours = [];
for ($h = 8; $h <= 21; $h++) {
    if ($h + $pkg_hours <= 22) {
        $start_hours[sprintf('%02d:00', $h)] = date('g:i A', strtotime(sprintf('%02d:00', $h)));
    }
}

// Page layout block: site header (navbar) and flash-message area.
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/alert.php';
?>

<!-- Page title block: heading and back button -->
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold mb-0">
                    Reserve Your Event
                </h2>
                <a href="<?= e(site_url('booking/index.php')) ?>" class="btn btn-outline-secondary">
                    <i class="fa-solid fa-arrow-left me-1"></i> Back
                </a>
            </div>

            <!-- Step 1 block: choose a package. This is a plain GET form: pressing the button reloads the page with the package's details (no JavaScript). -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-light py-3">
                    <h5 class="fw-bold mb-0"><i class="fa-solid fa-box me-2"></i>Step 1 &mdash; Package Details</h5>
                </div>
                <div class="card-body p-4">
                    <form method="GET" action="<?= e(site_url('booking/create.php')) ?>" class="row g-3 align-items-end">
                        <div class="col-md-9">
                            <label class="form-label fw-semibold">Select Package <span class="text-danger">*</span></label>
                            <select name="package" class="form-select form-select-lg" required>
                                <option value="">-- Choose a package --</option>
                                <?php foreach ($packages as $p): ?>
                                    <option value="<?= (int)$p['package_id'] ?>" <?= ($selected_pkg && $selected_pkg['package_id'] == $p['package_id']) ? 'selected' : '' ?>>
                                        <?= e($p['name']) ?> &mdash; <?= (int)$p['duration_hours'] ?>h &bull;
                                        <?= (int)$p['softcopy_count'] ?> soft / <?= (int)$p['hardcopy_count'] ?> hard &bull;
                                        <?= e(format_money($p['base_price'])) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-outline-secondary btn-lg w-100">Show details</button>
                        </div>
                    </form>
                    <?php if ($selected_pkg): ?>
                        <div class="form-text mt-2">
                            Package includes <?= (int)$selected_pkg['softcopy_count'] ?> soft copies and <?= (int)$selected_pkg['hardcopy_count'] ?> hard copies.
                            Duration is fixed at <?= (int)$selected_pkg['duration_hours'] ?> hours.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (!$selected_pkg): ?>
                <div class="alert alert-info">Choose a package above and press <strong>Show details</strong> to continue with your booking.</div>
            <?php else: ?>
            <!-- Step 2 block: the booking form (event details, copies, delivery, notes, price) posts to store.php, which re-checks everything on the server -->
            <form method="POST" action="<?= e(site_url('booking/store.php')) ?>">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="package_id" value="<?= (int)$selected_pkg['package_id'] ?>">
                <input type="hidden" name="duration_hours" value="<?= (int)$selected_pkg['duration_hours'] ?>">

                <!-- Event block: event name, date, start hour, fixed duration and venue -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-light py-3">
                        <h5 class="fw-bold mb-0"><i class="fa-regular fa-calendar me-2"></i>Event Information</h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label fw-semibold">Event Name <span class="text-danger">*</span></label>
                                <input type="text" name="event_name" class="form-control" required
                                       maxlength="200" placeholder="e.g. Juan &amp; Maria's Wedding">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Event Date <span class="text-danger">*</span></label>
                                <input type="date" name="event_date" id="event_date" class="form-control"
                                       min="<?= e($tomorrow) ?>" required>
                                <div class="form-text">Bookings must be made at least 1 day in advance.</div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Start Time <span class="text-danger">*</span></label>
                                <select name="start_time" id="start_time" class="form-select" required>
                                    <option value="">Select hour</option>
                                    <?php foreach ($start_hours as $val => $label): ?>
                                        <option value="<?= e($val) ?>"><?= e($label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="form-text">Pick the starting hour. Business hours: 8:00 AM - 10:00 PM. A 1-hour gap is kept between events on the same day.</div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Duration (set by package)</label>
                                <input type="hidden" name="duration_hours" id="duration_hours" value="<?= $selected_pkg ? (int)$selected_pkg['duration_hours'] : 0 ?>">
                                <input type="text" id="duration_display" class="form-control" readonly
                                       value="<?= $selected_pkg ? (int)$selected_pkg['duration_hours'] . ' hours' : 'Select a package first' ?>">
                                <div class="form-text" id="duration_hint"></div>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Venue / Address <span class="text-danger">*</span></label>
                                <textarea name="venue" class="form-control" rows="3" required
                                          placeholder="Full venue address, including landmark if any..."></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Copies & add-on block: soft/hard copy counts from the package and the optional unlimited-softcopy switch -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-light py-3">
                        <h5 class="fw-bold mb-0"><i class="fa-solid fa-copy me-2"></i>Copies &amp; Add-ons</h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Soft Copies <span class="text-muted">(per package)</span></label>
                                <input type="number" name="estimated_softcopies" id="estimated_softcopies"
                                       class="form-control" readonly tabindex="-1" style="-moz-appearance:textfield" 
                                       value="<?= (int)$selected_pkg['softcopy_count'] ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Hard Copies <span class="text-muted">(per package)</span></label>
                                <input type="number" name="estimated_hardcopies" id="estimated_hardcopies"
                                       class="form-control" readonly tabindex="-1" style="-moz-appearance:textfield" 
                                       value="<?= (int)$selected_pkg['hardcopy_count'] ?>">
                            </div>
                            <?php if ($addon_available): ?>
                            <div class="col-md-4 d-flex align-items-end">
                                <div class="form-check form-switch fs-6">
                                    <input class="form-check-input" type="checkbox" role="switch"
                                           id="softcopy_addon" name="softcopy_addon" value="1">
                                    <label class="form-check-label fw-semibold" for="softcopy_addon">
                                        Unlimited Softcopy Add-on
                                    </label>
                                    <div class="form-text">+ <?= e(format_money($addon_price)) ?> for unlimited soft copies</div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Hardcopy delivery block (optional): who receives the printed copies and where -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-light py-3 d-flex justify-content-between align-items-center">
                        <h5 class="fw-bold mb-0"><i class="fa-solid fa-truck me-2"></i>Hardcopy Delivery</h5>
                        <span class="badge bg-light text-secondary small">Optional</span>
                    </div>
                    <div class="card-body p-4">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Recipient Name</label>
                                <input type="text" name="hardcopy_delivery_name" class="form-control" maxlength="150"
                                       placeholder="Name of person who will receive hard copies">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Contact Number</label>
                                <input type="text" name="hardcopy_delivery_contact" class="form-control" maxlength="30"
                                       placeholder="Mobile or landline">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Delivery Address</label>
                                <textarea name="hardcopy_delivery_address" class="form-control" rows="2"
                                          placeholder="Full delivery address for hard copies"></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Notes block: special requests -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-light py-3">
                        <h5 class="fw-bold mb-0"><i class="fa-solid fa-note-sticky me-2"></i>Notes</h5>
                    </div>
                    <div class="card-body p-4">
                        <textarea name="notes" class="form-control" rows="3"
                                  placeholder="Special requests, preferred themes, additional instructions..."></textarea>
                    </div>
                </div>

                <!-- Price summary block: base price, add-on price and totals calculated by PHP -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-light py-3">
                        <h5 class="fw-bold mb-0"><i class="fa-solid fa-receipt me-2"></i>Price Summary</h5>
                    </div>
                    <div class="card-body p-4">
                        <!-- Table block: the list of records, one row each -->
                        <table class="table table-borderless mb-0">
                            <tbody>
                                <tr>
                                    <td>Package Base Price</td>
                                    <td class="text-end fw-semibold"><?= e(format_money($base_price)) ?></td>
                                </tr>
                                <tr>
                                    <td>Softcopy Add-on <?= $addon_available ? '(only if the switch above is on)' : '(not offered for this package)' ?></td>
                                    <td class="text-end fw-semibold"><?= e(format_money($addon_price)) ?></td>
                                </tr>
                                <tr class="border-top">
                                    <td class="fw-bold fs-5">Total Amount</td>
                                    <td class="text-end fw-bold fs-5" style="color:var(--snapit-gold)"><?= e(format_money($base_price)) ?><?= $addon_available ? ' <span class="small text-muted">(' . e(format_money($base_price + $addon_price)) . ' with add-on)</span>' : '' ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Submit block: cancel or submit the booking -->
                <div class="d-flex gap-3 justify-content-end">
                    <a href="<?= e(site_url('booking/index.php')) ?>" class="btn btn-outline-secondary px-4">Cancel</a>
                    <button type="submit" class="btn btn-snapit px-5 fw-semibold">
                        <i class="fa-regular fa-calendar-check me-2"></i>Submit Booking
                    </button>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>


<?php include __DIR__ . '/../includes/footer.php'; ?>
