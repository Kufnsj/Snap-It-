# The only JavaScript in Snap It (little-JS version)

**File:** `includes/booth_camera.js` - 28 lines of code, loaded only on the booth camera screen (`booth/session.php`).
Everything else is PHP, HTML and CSS. The one other script on the site is Bootstrap's own library (a CDN `<script src>` in `includes/header.php`).

## Why JavaScript is needed at all

A web page can only reach the webcam through the browser's camera feature, and the browser lets only JavaScript use it
(`navigator.mediaDevices.getUserMedia`). PHP runs on the server, so it cannot see the camera. Nothing else in the system needs JavaScript.

## The script in three steps

```js
var video  = document.getElementById('cameraVideo');   // the <video> tag on the page
var button = document.getElementById('captureBtn');    // the Capture button
var shout  = document.getElementById('countdown');     // the big number shown over the video
var form   = document.getElementById('captureForm');   // the form that goes to PHP
```
Four variables: they just point to four things on the page by their id.

**Step 1 - open the camera and show it live**
```js
navigator.mediaDevices.getUserMedia({ video: true }).then(function (stream) {
  video.srcObject = stream;                                            // put the live camera picture in the <video> tag
  video.onloadedmetadata = function () { button.disabled = false; };   // when the picture is ready, enable the button
}).catch(function () { ... });                                         // if the camera is blocked or missing, show a message
```
The browser shows a permission pop-up. If the guest allows it, we get a `stream` (the live picture) and give it to the `<video>` tag.

**Step 2 - countdown when the button is pressed**
```js
button.onclick = function () {
  var left = parseInt(form.getAttribute('data-countdown'), 10);  // 3, 5 or 10 seconds, written by PHP in the form
  button.disabled = true;
  shout.textContent = left;                                      // show the first number
  var timer = setInterval(function () {                          // run this every 1000 ms (1 second)
    left = left - 1;
    shout.textContent = left > 0 ? left : '';
    if (left <= 0) { clearInterval(timer); takePhoto(); }        // time is up: stop the timer and take the photo
  }, 1000);
};
```

**Step 3 - take the picture and send it to PHP**
```js
function takePhoto() {
  var canvas = document.createElement('canvas');                 // an invisible drawing board
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext('2d').drawImage(video, 0, 0);                // copy the current video frame onto it
  form.image_data.value = canvas.toDataURL('image/jpeg', 0.92);  // turn the picture into text and put it in the hidden field
  form.submit();                                                 // send the form to booth/save_photo.php
}
```

## What PHP does (no JavaScript)

| Job | Where |
|---|---|
| Writes the live-preview filter as CSS: `<video style="filter: ...">` | `booth/session.php` (text from `includes/photo_fx.php`) |
| Mirror button: CSS `transform: scaleX(-1)` | `booth/session.php`, saved by `booth/booth_settings.php` |
| Grain, fade and vignette layers over the preview: plain CSS | `booth/session.php` |
| Countdown length 3 / 5 / 10 s: a normal form | `booth/booth_settings.php` |
| Receives the picture, applies the filter, mirror and film effects with GD, saves the JPG, records it in the database | `booth/save_photo.php` + `includes/photo_fx.php` |
| Keep / Retake, progress bar, Done button, idle timeout, strip, print queue, email | PHP |
| "Are you sure?" questions | `confirm.php` (a plain page, no `confirm()` pop-up) |

The preview is the browser's CSS filter; the saved photo gets the same look from PHP. They are very close but not pixel-identical.

## Likely questions

- **How does the camera open?** The page asks the browser for the camera with `getUserMedia` (JavaScript). The browser shows a permission pop-up; if allowed, the live picture goes into the `<video>` tag.
- **How is the photo taken?** After the countdown, JavaScript copies the current video frame onto a `<canvas>`, turns it into text (base64 JPEG), puts it in a hidden form field and submits the form. PHP decodes it and saves the file.
- **Where is the filter applied?** The live preview uses a CSS filter that PHP writes into the page. The saved photo is filtered by PHP using the GD library, once, on the server.
- **Why not do it all in PHP?** PHP runs on the server and cannot reach the webcam in the guest's browser. That is the only reason this script exists.
- **Does it work on any computer?** Browsers allow the camera only on `localhost` or HTTPS. For the demo the site runs on localhost.
