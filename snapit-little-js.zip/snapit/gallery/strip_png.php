<?php
// Customer download: builds the finished photo strip as a PNG on the server (PHP GD) and sends it as a file download.
// Replaces the old browser-side html2canvas download, so no JavaScript library is needed.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/strip_image.php';

// Guard block: login required.
require_login();

// Input block: the session id of the photo set to download.
$sid = isset($_GET['sid']) ? (int)$_GET['sid'] : 0;
$current_user_id = (int)($_SESSION['user_id'] ?? 0);
if ($sid <= 0) {
    set_flash('Invalid session reference.', 'danger');
    redirect(site_url('gallery/index.php'));
}

// Session-data block: loads the session with its layout, frame and booking (same data the download page uses).
$stmt = mysqli_prepare($conn, "SELECT gs.*, b.booking_id, b.user_id AS booking_user_id,
    l.photo_count, l.grid_cols, l.grid_rows, l.print_size,
    f.css_filter,
    fd.border_color, fd.border_width, fd.bg_color, fd.text_color, fd.photo_gap, fd.photo_radius, fd.pattern,
    b.event_name
    FROM guest_sessions gs
    INNER JOIN bookings b ON gs.booking_id = b.booking_id
    LEFT JOIN layouts l ON gs.layout_id = l.layout_id
    LEFT JOIN filters f ON gs.filter_id = f.filter_id
    LEFT JOIN frame_designs fd ON gs.frame_design_id = fd.design_id
    WHERE gs.session_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $sid);
mysqli_stmt_execute($stmt);
$session = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
if (!$session) {
    set_flash('Photo session not found.', 'danger');
    redirect(site_url('gallery/index.php'));
}

// Permission block: only the booking's owner may download, and only when the booking includes soft copies.
$booking_id = (int)$session['booking_id'];
if ((int)$session['booking_user_id'] !== $current_user_id) {
    set_flash('You are not authorized to access this session.', 'danger');
    redirect(site_url('gallery/index.php'));
}
if (!booking_has_softcopy_access($conn, $booking_id)) {
    set_flash('Softcopy download is not available for this booking.', 'danger');
    redirect(site_url('gallery/view_booking.php?id=' . $booking_id));
}

// Photos block: finds each kept photo's file on disk, in order (paths are checked to stay inside the uploads folder).
$pstmt = mysqli_prepare($conn, "SELECT photo_path FROM session_photos WHERE session_id = ? AND is_kept = 1 ORDER BY order_index ASC, photo_id ASC");
mysqli_stmt_bind_param($pstmt, 'i', $sid);
mysqli_stmt_execute($pstmt);
$pres = mysqli_stmt_get_result($pstmt);
$files = [];
while ($row = mysqli_fetch_assoc($pres)) {
    $rel = photo_rel_path($row['photo_path']);
    $files[] = ($rel && strpos($rel, '..') === false) ? dirname(__DIR__) . '/' . $rel : null;
}
if (!function_exists('imagecreatetruecolor')) {
    set_flash('The PHP GD extension is not enabled on this server, so the PNG cannot be created.', 'danger');
    redirect(site_url('gallery/download.php?sid=' . $sid));
}

// Build block: draws the strip and sends it to the browser as an attachment.
$caption = ($session['event_name'] ?? 'Snap It') . (!empty($session['guest_name']) ? ' · ' . $session['guest_name'] : '');
$img = snapit_strip_image($files, strip_cfg($session, $caption));
header('Content-Type: image/png');
header('Content-Disposition: attachment; filename="snapit-session-' . $sid . '.png"');
imagepng($img);
imagedestroy($img);
exit;
