<?php
// Handler: emails the photo set to up to 10 recipients and records each delivery.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
// Guard block: only logged-in users can use this page.
require_login();

$redirect_url = site_url('gallery/index.php');

// Request check block: only POST form submissions are accepted here.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    set_flash('Invalid request method.', 'danger');
    redirect($redirect_url);
}

// Security block: rejects forms without a valid CSRF token.
if (!isset($_POST['csrf_token']) || !verify_csrf($_POST['csrf_token'])) {
    set_flash('Invalid security token. Please refresh and try again.', 'danger');
    $sid_post = isset($_POST['session_id']) ? (int)$_POST['session_id'] : 0;
    if ($sid_post > 0) {
        // Query block: reads from guest_sessions.
        $bstmt = mysqli_prepare($conn, "SELECT booking_id FROM guest_sessions WHERE session_id = ? LIMIT 1");
        mysqli_stmt_bind_param($bstmt, 'i', $sid_post);
        mysqli_stmt_execute($bstmt);
        $bres = mysqli_stmt_get_result($bstmt);
        $brow = mysqli_fetch_assoc($bres);
        if ($brow) {
            redirect(site_url('gallery/view_booking.php?id=' . (int)$brow['booking_id']));
        }
    }
    redirect($redirect_url);
}

$session_id = isset($_POST['session_id']) ? (int)$_POST['session_id'] : 0;
$current_user_id = (int)($_SESSION['user_id'] ?? 0);

if ($session_id <= 0) {
    set_flash('Invalid session reference.', 'danger');
    redirect($redirect_url);
}

// Query block: reads from the database.
$sstmt = mysqli_prepare($conn, "SELECT gs.session_id, gs.booking_id, gs.guest_name, b.user_id AS booking_user_id, b.event_name, b.softcopy_addon, u.name AS customer_name, u.email AS customer_email
    FROM guest_sessions gs
    INNER JOIN bookings b ON gs.booking_id = b.booking_id
    LEFT JOIN users u ON b.user_id = u.user_id
    WHERE gs.session_id = ? LIMIT 1");
mysqli_stmt_bind_param($sstmt, 'i', $session_id);
mysqli_stmt_execute($sstmt);
$sres = mysqli_stmt_get_result($sstmt);
$session = mysqli_fetch_assoc($sres);

if (!$session) {
    set_flash('Photo session not found.', 'danger');
    redirect($redirect_url);
}

$booking_id = (int)$session['booking_id'];
$redirect_url = site_url('gallery/view_booking.php?id=' . $booking_id);

if ((int)$session['booking_user_id'] !== $current_user_id) {
    set_flash('You are not authorized to send emails for this session.', 'danger');
    redirect($redirect_url);
}

if (!booking_has_softcopy_access($conn, $booking_id)) {
    set_flash('Softcopy email delivery is not available for this booking. It is included with Solo, Classic, Premium, and Grand Wedding packages, or may be purchased separately as a softcopy add-on.', 'danger');
    redirect($redirect_url);
}

$raw_emails = $_POST['emails'] ?? [];
if (!is_array($raw_emails)) {
    $raw_emails = [];
}

$valid_emails = [];
$seen = [];
$invalid_count = 0;
$total_submitted = 0;

foreach ($raw_emails as $raw) {
    $raw = trim((string)$raw);
    if ($raw === '') continue;
    $total_submitted++;
    $norm = strtolower($raw);
    if (isset($seen[$norm])) continue;
    if (valid_email($raw)) {
        $seen[$norm] = true;
        $valid_emails[] = $raw;
    } else {
        $invalid_count++;
    }
}

if (count($valid_emails) > 10) {
    $valid_emails = array_slice($valid_emails, 0, 10);
}

require_once __DIR__ . '/../includes/mailer.php';

// Query block: reads from session_photos.
$pStmt = mysqli_prepare($conn, "SELECT photo_path FROM session_photos WHERE session_id = ? AND is_kept = 1 ORDER BY order_index ASC");
mysqli_stmt_bind_param($pStmt, 'i', $session_id);
mysqli_stmt_execute($pStmt);
$pRes = mysqli_stmt_get_result($pStmt);
$photos = [];
while ($pr = mysqli_fetch_assoc($pRes)) $photos[] = $pr;
mysqli_stmt_close($pStmt);

$galleryUrl = snapit_build_full_url('gallery/view_booking.php?id=' . $booking_id);

$inserted = 0;
$sentCount = 0;
$failedCount = 0;

if (!empty($valid_emails)) {
    // Save block: inserts into delivery_recipients.
    $istmt = mysqli_prepare($conn, "INSERT INTO delivery_recipients
        (booking_id, session_id, email, sent_at, error_detail, message_id, created_at)
        VALUES (?, ?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
            sent_at = VALUES(sent_at),
            error_detail = VALUES(error_detail),
            message_id = VALUES(message_id)");

    foreach ($valid_emails as $email) {
        $send = snapit_send_booth_softcopy_email($email, $session, $session, $photos, $galleryUrl);
        $sentAt = !empty($send['ok']) ? date('Y-m-d H:i:s') : null;
        $err = mb_substr((string)($send['detail'] ?? $send['error'] ?? ''), 0, 1000);
        $mid = mb_substr((string)($send['message_id'] ?? ''), 0, 255);

        if (!empty($send['ok'])) {
            $sentCount++;
        } else {
            $failedCount++;
        }

        mysqli_stmt_bind_param($istmt, 'iissss', $booking_id, $session_id, $email, $sentAt, $err, $mid);
        if (mysqli_stmt_execute($istmt)) {
            $inserted++;
        }
    }
    mysqli_stmt_close($istmt);
}

if ($inserted > 0) {
    $status = ($failedCount === 0) ? 'sent' : (($sentCount > 0) ? 'partial' : 'failed');
    // Save block: inserts into notifications.
    $nstmt = mysqli_prepare($conn, "INSERT INTO notifications
        (booking_id, user_id, type, subject, message_body, status, sent_at, created_at)
        VALUES (?, ?, 'softcopy_sent', ?, ?, ?, NOW(), NOW())");
    $subject = 'Softcopy delivery for session #' . $session_id;
    $body = $sentCount . ' of ' . $inserted . ' recipient(s) sent successfully for Session #' . $session_id . ' (Booking #' . $booking_id . ').';
    $nUid = (int)$session['booking_user_id'];
    mysqli_stmt_bind_param($nstmt, 'iisss', $booking_id, $nUid, $subject, $body, $status);
    mysqli_stmt_execute($nstmt);
    mysqli_stmt_close($nstmt);
}

if ($total_submitted === 0) {
    set_flash('No email addresses were provided.', 'warning');
} else {
    if ($sentCount > 0) {
        $msg = 'Softcopy photos emailed successfully to ' . $sentCount . ' recipient(s).';
        if ($failedCount > 0) {
            $msg .= ' (' . $failedCount . ' recipient(s) failed delivery).';
        }
        if ($invalid_count > 0) {
            $msg .= ' (Skipped ' . $invalid_count . ' invalid address' . ($invalid_count !== 1 ? 'es' : '') . '.)';
        }
        set_flash($msg, 'success');
    } else {
        if ($failedCount > 0) {
            set_flash('Delivery failed for ' . $failedCount . ' recipient(s). Please check SMTP logs.', 'danger');
        } elseif ($invalid_count > 0) {
            set_flash('No recipients added. ' . $invalid_count . ' invalid email address(es) were skipped.', 'warning');
        } else {
            set_flash('No new recipients processed.', 'info');
        }
    }
}

redirect($redirect_url);
