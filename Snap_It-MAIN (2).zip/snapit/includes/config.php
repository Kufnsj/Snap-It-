<?php

// ---- PHP runtime hardening (T2) ----
// Never leak stack traces or raw DB errors to browsers.
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('html_errors', '0');
ini_set('log_errors', '1');

$snapitRoot = dirname(__DIR__);
$logsDir = $snapitRoot . DIRECTORY_SEPARATOR . 'logs';
if (!is_dir($logsDir)) {
    @mkdir($logsDir, 0755, true);
}
$errorLog = $logsDir . DIRECTORY_SEPARATOR . 'php_errors.log';
@ini_set('error_log', $errorLog);

// Catch-all exception handler: never let an uncaught Throwable produce
// a blank fatal page or (worse) a stack trace. Flash & redirect to the
// homepage / login screen with a generic friendly message.
set_exception_handler(function (Throwable $e) use ($errorLog) {
    @error_log('[uncaught] ' . get_class($e) . ': ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (headers_sent()) {
        echo '<!doctype html><html><head><meta charset="utf-8"><title>Temporarily unavailable</title></head><body style="font-family:Segoe UI,Arial,sans-serif;background:#fafafa;color:#333;padding:48px;text-align:center;"><h2>Something went wrong.</h2><p>Please try again in a few moments, or return to the <a href="./">home page</a>.</p></body></html>';
    } else {
        header('HTTP/1.1 500 Internal Server Error');
        require_once __DIR__ . '/functions.php';
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.use_strict_mode', '1');
            ini_set('session.use_only_cookies', '1');
            session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
            session_start();
        }
        set_flash('Something went wrong while loading this page. Please try again, or contact support if the problem persists.', 'danger');
        $url = function_exists('site_url') ? site_url('index.php') : './index.php';
        header('Location: ' . $url);
    }
    exit(1);
});

set_error_handler(function ($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    @error_log('[php:' . $severity . '] ' . $message . ' in ' . $file . ':' . $line);
    return false;
});

// ---- Database connection ----
$db_host = 'localhost';
$db_username = 'root';
$db_passwd = '';
$db_name = 'db_snapit';

$conn = @mysqli_connect($db_host, $db_username, $db_passwd, $db_name);

if (!$conn) {
    @error_log('[db] connect failed: ' . mysqli_connect_error());
    if (headers_sent()) {
        echo '<!doctype html><html><head><meta charset="utf-8"><title>Temporarily unavailable</title></head><body style="font-family:Segoe UI,Arial,sans-serif;background:#fafafa;color:#333;padding:48px;text-align:center;"><h2>Database is temporarily unavailable.</h2><p>Please try again in a few moments.</p></body></html>';
    } else {
        header('HTTP/1.1 503 Service Unavailable');
        require_once __DIR__ . '/functions.php';
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.use_strict_mode', '1');
            ini_set('session.use_only_cookies', '1');
            session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
            session_start();
        }
        set_flash('Database connection failed. Please try again in a few moments.', 'danger');
        $url = function_exists('site_url') ? site_url('users/login.php') : './users/login.php';
        header('Location: ' . $url);
    }
    exit(1);
}

mysqli_set_charset($conn, "utf8mb4");

// ---- SMTP / Mailer configuration (T10) ----
// Mailtrap defaults for dev; override via environment for production.
// Dual-service toggle: set $smtp_service to 'google' to use Gmail SMTP
// (requires App Password when 2FA is enabled).
$smtp_service    = getenv('SNAPIT_SMTP_SERVICE')   ?: 'mailtrap';
$smtp_host       = getenv('SNAPIT_SMTP_HOST')      ?: 'sandbox.smtp.mailtrap.io';
$smtp_port       = (int)(getenv('SNAPIT_SMTP_PORT') ?: 2525);
$smtp_user       = getenv('SNAPIT_SMTP_USER')      ?: '';
$smtp_pass       = getenv('SNAPIT_SMTP_PASS')      ?: '';
$smtp_secure     = getenv('SNAPIT_SMTP_SECURE')    ?: 'tls'; // 'tls' | 'ssl' | ''
$smtp_auth       = getenv('SNAPIT_SMTP_AUTH') === '' ? true : (bool)getenv('SNAPIT_SMTP_AUTH');

if ($smtp_service === 'google') {
    if (!getenv('SNAPIT_SMTP_HOST'))   $smtp_host = 'smtp.gmail.com';
    if (!getenv('SNAPIT_SMTP_PORT'))   $smtp_port = 587;
    if (!getenv('SNAPIT_SMTP_SECURE')) $smtp_secure = 'tls';
}

$mail_from_email = getenv('SNAPIT_MAIL_FROM_EMAIL') ?: 'no-reply@snapit.ph';
$mail_from_name  = getenv('SNAPIT_MAIL_FROM_NAME')  ?: 'Snap It Photo Booth';
$mail_reply_to   = getenv('SNAPIT_MAIL_REPLY_TO')   ?: 'support@snapit.ph';

// ---- Self-healing schema: add columns that older databases may lack ----
if (isset($conn) && $conn) {
    if (session_status() === PHP_SESSION_NONE) { @session_start(); }
    if (empty($_SESSION['schema_ok_v2'])) {
        $__ensure = [
            ['payments', 'status', "ALTER TABLE payments ADD COLUMN status ENUM('pending','completed','captured','failed','refunded_pending') NOT NULL DEFAULT 'completed' AFTER payment_date"],
            ['guest_sessions', 'countdown_seconds', "ALTER TABLE guest_sessions ADD COLUMN countdown_seconds TINYINT NOT NULL DEFAULT 3"],
            ['guest_sessions', 'mirror_preview', "ALTER TABLE guest_sessions ADD COLUMN mirror_preview TINYINT(1) NOT NULL DEFAULT 1"],
            ['bookings', 'inventory_deducted', "ALTER TABLE bookings ADD COLUMN inventory_deducted TINYINT(1) NOT NULL DEFAULT 0"],
        ];
        foreach ($__ensure as $__e) {
            try {
                $__r = mysqli_query($conn, "SHOW COLUMNS FROM `{$__e[0]}` LIKE '{$__e[1]}'");
                if ($__r && mysqli_num_rows($__r) === 0) { mysqli_query($conn, $__e[2]); }
            } catch (Throwable $__ex) { @error_log('[schema] ' . $__ex->getMessage()); }
        }
        $_SESSION['schema_ok_v2'] = 1;
    }
}
