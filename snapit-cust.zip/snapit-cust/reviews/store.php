<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/reviews.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(site_url('index.php#packages'));
}

$package_id = (int)($_POST['package_id'] ?? 0);
$back = site_url('package.php?id=' . $package_id) . '#reviews';

if (!verify_csrf($_POST['csrf_token'] ?? '')) {
    set_flash('Your session expired. Please try again.', 'danger');
    redirect($package_id > 0 ? $back : site_url('index.php#packages'));
}

// The package must exist and be active.
$pk = mysqli_prepare($conn, "SELECT package_id FROM packages WHERE package_id = ? AND is_active = 1 LIMIT 1");
mysqli_stmt_bind_param($pk, 'i', $package_id);
mysqli_stmt_execute($pk);
if (!mysqli_fetch_assoc(mysqli_stmt_get_result($pk))) {
    set_flash('That package could not be found.', 'warning');
    redirect(site_url('index.php#packages'));
}

// Only customers who actually availed this package may review it.
$user_id = (int)$_SESSION['user_id'];
if (!review_user_eligible($conn, $user_id, $package_id)) {
    set_flash('Only customers with a completed booking of this package can review it.', 'warning');
    redirect($back);
}

$rating  = filter_var($_POST['rating'] ?? '', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 5]]);
$comment = trim((string)($_POST['comment'] ?? ''));
$comment = preg_replace('/\R{3,}/u', "\n\n", $comment);          // squash runs of blank lines

$errors = [];
if ($rating === false) $errors[] = 'Please choose a rating from 1 to 5.';
if ($comment === '') $errors[] = 'Please write a short review.';
elseif (mb_strlen($comment) < REVIEW_MIN_LEN) $errors[] = 'Your review is too short (at least ' . REVIEW_MIN_LEN . ' characters).';
elseif (mb_strlen($comment) > REVIEW_MAX_LEN) $errors[] = 'Your review is too long (' . REVIEW_MAX_LEN . ' characters maximum).';

if ($errors) {
    $_SESSION['review_form_old'] = ['package_id' => $package_id, 'rating' => (string)($_POST['rating'] ?? ''), 'comment' => $comment];
    set_flash(implode(' ', $errors), 'danger');
    redirect($back);
}

$comment = mask_bad_words($comment);   // regex mask of foul words before anything is stored

try {
    $existing = review_for_user($conn, $user_id, $package_id);
    if ($existing) {
        $st = mysqli_prepare($conn, "UPDATE reviews SET rating = ?, comment = ? WHERE review_id = ? AND user_id = ?");
        $rid = (int)$existing['review_id'];
        mysqli_stmt_bind_param($st, 'isii', $rating, $comment, $rid, $user_id);
        mysqli_stmt_execute($st);
        set_flash('Your review has been updated.', 'success');
    } else {
        $st = mysqli_prepare($conn, "INSERT INTO reviews (package_id, user_id, rating, comment) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($st, 'iiis', $package_id, $user_id, $rating, $comment);
        mysqli_stmt_execute($st);
        set_flash('Thanks! Your review has been posted.', 'success');
    }
} catch (Throwable $ex) {
    @error_log('[reviews/store] ' . $ex->getMessage());
    set_flash('Could not save your review. Please try again.', 'danger');
}
redirect($back);
