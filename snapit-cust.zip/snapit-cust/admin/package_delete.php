<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf($_POST['csrf_token'] ?? '')) {
    set_flash('Your session expired. Please try again.', 'danger');
    redirect(site_url('admin/packages.php'));
}

$id = (int)($_POST['package_id'] ?? 0);

$stmt = mysqli_prepare($conn, "SELECT package_id, name, image_path FROM packages WHERE package_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$pkg = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
if (!$pkg) {
    set_flash('Package not found.', 'danger');
    redirect(site_url('admin/packages.php'));
}

// Bookings reference packages, so a booked package must be deactivated instead of deleted.
$bk = mysqli_prepare($conn, "SELECT COUNT(*) FROM bookings WHERE package_id = ?");
mysqli_stmt_bind_param($bk, 'i', $id);
mysqli_stmt_execute($bk);
$n = (int)(mysqli_fetch_row(mysqli_stmt_get_result($bk))[0] ?? 0);
if ($n > 0) {
    set_flash("\"{$pkg['name']}\" has {$n} booking(s) on record, so it can't be deleted. Deactivate it instead.", 'warning');
    redirect(site_url('admin/packages.php'));
}

try {
    $gallery = package_gallery($conn, $id);          // read file names before the rows cascade away
    $del = mysqli_prepare($conn, "DELETE FROM packages WHERE package_id = ?");
    mysqli_stmt_bind_param($del, 'i', $id);
    mysqli_stmt_execute($del);
    if (!empty($pkg['image_path'])) package_photo_delete_file($pkg['image_path']);
    foreach ($gallery as $g) package_photo_delete_file($g['file_name']);
    set_flash('Package deleted.', 'success');
} catch (Throwable $ex) {
    @error_log('[admin/package_delete] ' . $ex->getMessage());
    set_flash('Could not delete the package. Please try again.', 'danger');
}
redirect(site_url('admin/packages.php'));
