<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(site_url('admin/packages.php'));
}

$id      = (int)($_POST['package_id'] ?? 0);
$is_edit = $id > 0;
$back    = site_url('admin/package_form.php') . ($is_edit ? '?id=' . $id : '');

// When the whole upload is bigger than post_max_size, PHP drops $_POST and $_FILES entirely.
if (empty($_POST) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    set_flash('The upload was too large. Keep each photo under 2 MB and choose fewer photos at once.', 'danger');
    redirect(site_url('admin/packages.php'));
}
if (!verify_csrf($_POST['csrf_token'] ?? '')) {
    set_flash('Your session expired. Please try again.', 'danger');
    redirect(site_url('admin/packages.php'));
}

$name        = trim((string)($_POST['name'] ?? ''));
$description = trim((string)($_POST['description'] ?? ''));
$duration    = trim((string)($_POST['duration_hours'] ?? ''));
$soft        = trim((string)($_POST['softcopy_count'] ?? ''));
$hard        = trim((string)($_POST['hardcopy_count'] ?? ''));
$base_price  = trim((string)($_POST['base_price'] ?? ''));
$addon_price = trim((string)($_POST['softcopy_addon_price'] ?? ''));
$type        = (string)($_POST['package_type'] ?? 'event');
$has_addon   = isset($_POST['has_softcopy_addon']) ? 1 : 0;
$is_active   = isset($_POST['is_active']) ? 1 : 0;

$errors = [];
if ($name === '') $errors[] = 'Package name is required.';
elseif (mb_strlen($name) > 150) $errors[] = 'Package name is too long (150 characters maximum).';
if (mb_strlen($description) > 2000) $errors[] = 'Description is too long (2000 characters maximum).';

$int = function ($v, $min, $max) {
    return filter_var($v, FILTER_VALIDATE_INT, ['options' => ['min_range' => $min, 'max_range' => $max]]);
};
$duration_i = $int($duration, 1, 24);
if ($duration_i === false) $errors[] = 'Duration must be a whole number of hours between 1 and 24.';
$soft_i = $int($soft, 0, 100000);
if ($soft_i === false) $errors[] = 'Softcopies must be a whole number between 0 and 100,000.';
$hard_i = $int($hard, 0, 100000);
if ($hard_i === false) $errors[] = 'Hardcopies must be a whole number between 0 and 100,000.';

$money = function ($v) {
    $v = str_replace(',', '', $v);
    return (preg_match('/^\d{1,7}(\.\d{1,2})?$/', $v) === 1) ? (float)$v : false;
};
$base_f = $money($base_price);
if ($base_f === false) $errors[] = 'Base price must be a number such as 8000 or 8000.50 (max 9,999,999.99).';
$addon_f = $money($addon_price === '' ? '0' : $addon_price);
if ($addon_f === false) $errors[] = 'Add-on price must be a number such as 1500 or 1500.50.';
if (!in_array($type, ['event', 'walkin'], true)) $errors[] = 'Invalid package type.';

// Load the existing package (edit mode).
$existing = null;
if ($is_edit) {
    $chk = mysqli_prepare($conn, "SELECT package_id, image_path FROM packages WHERE package_id = ? LIMIT 1");
    mysqli_stmt_bind_param($chk, 'i', $id);
    mysqli_stmt_execute($chk);
    $existing = mysqli_fetch_assoc(mysqli_stmt_get_result($chk));
    if (!$existing) {
        set_flash('Package not found.', 'danger');
        redirect(site_url('admin/packages.php'));
    }
}

// Gallery limit: existing photos - removals + new uploads.
$cover_upload = files_normalize($_FILES['cover'] ?? null);
$new_photos   = files_normalize($_FILES['photos'] ?? null);
$to_delete    = array_values(array_unique(array_map('intval', (array)($_POST['delete_photos'] ?? []))));
if ($is_edit) {
    $existing_gallery = package_gallery($conn, $id);
    $existing_ids = array_map(function ($g) { return (int)$g['photo_id']; }, $existing_gallery);
    $to_delete = array_values(array_intersect($to_delete, $existing_ids));
    $remaining = count($existing_gallery) - count($to_delete);
} else {
    $existing_gallery = [];
    $to_delete = [];
    $remaining = 0;
}
if ($remaining + count($new_photos) > PACKAGE_MAX_GALLERY) {
    $errors[] = 'A package can have at most ' . PACKAGE_MAX_GALLERY . ' gallery photos.';
}

if ($errors) {
    $_SESSION['package_form_old'] = [
        'name' => $name, 'description' => $description, 'duration_hours' => $duration,
        'softcopy_count' => $soft, 'hardcopy_count' => $hard, 'base_price' => $base_price,
        'softcopy_addon_price' => $addon_price, 'package_type' => $type,
        'has_softcopy_addon' => $has_addon, 'is_active' => $is_active,
    ];
    set_flash(implode(' ', $errors), 'danger');
    redirect($back);
}

$photo_errors = [];
try {
    if ($is_edit) {
        $st = mysqli_prepare($conn, "UPDATE packages SET name = ?, description = ?, duration_hours = ?, softcopy_count = ?, hardcopy_count = ?,
            base_price = ?, has_softcopy_addon = ?, softcopy_addon_price = ?, package_type = ?, is_active = ? WHERE package_id = ?");
        mysqli_stmt_bind_param($st, 'ssiiididsii', $name, $description, $duration_i, $soft_i, $hard_i,
            $base_f, $has_addon, $addon_f, $type, $is_active, $id);
        mysqli_stmt_execute($st);
    } else {
        $st = mysqli_prepare($conn, "INSERT INTO packages (name, description, duration_hours, softcopy_count, hardcopy_count,
            base_price, has_softcopy_addon, softcopy_addon_price, package_type, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($st, 'ssiiididsi', $name, $description, $duration_i, $soft_i, $hard_i,
            $base_f, $has_addon, $addon_f, $type, $is_active);
        mysqli_stmt_execute($st);
        $id = (int)mysqli_insert_id($conn);
    }

    // ---- Cover photo (single upload) ----
    $old_cover = $existing['image_path'] ?? null;
    $new_cover = null;
    if ($cover_upload) {
        [$fn, $err] = package_photo_save_upload($cover_upload[0]);
        if ($err) $photo_errors[] = $err; else $new_cover = $fn;
    }
    if ($new_cover !== null || ($is_edit && isset($_POST['remove_cover']) && $old_cover)) {
        $set = $new_cover; // null clears the cover when only "remove" was ticked
        $u = mysqli_prepare($conn, "UPDATE packages SET image_path = ? WHERE package_id = ?");
        mysqli_stmt_bind_param($u, 'si', $set, $id);
        mysqli_stmt_execute($u);
        if ($old_cover) package_photo_delete_file($old_cover);
    }

    // ---- Gallery: remove ticked photos ----
    if ($to_delete) {
        foreach ($existing_gallery as $g) {
            if (!in_array((int)$g['photo_id'], $to_delete, true)) continue;
            $d = mysqli_prepare($conn, "DELETE FROM package_photos WHERE photo_id = ? AND package_id = ?");
            $gid = (int)$g['photo_id'];
            mysqli_stmt_bind_param($d, 'ii', $gid, $id);
            mysqli_stmt_execute($d);
            package_photo_delete_file($g['file_name']);
        }
    }

    // ---- Gallery: add new photos (multiple upload) ----
    if ($new_photos) {
        $so = mysqli_prepare($conn, "SELECT COALESCE(MAX(sort_order), 0) FROM package_photos WHERE package_id = ?");
        mysqli_stmt_bind_param($so, 'i', $id);
        mysqli_stmt_execute($so);
        $order = (int)(mysqli_fetch_row(mysqli_stmt_get_result($so))[0] ?? 0);
        foreach ($new_photos as $f) {
            [$fn, $err] = package_photo_save_upload($f);
            if ($err) { $photo_errors[] = $err; continue; }
            $order++;
            $ins = mysqli_prepare($conn, "INSERT INTO package_photos (package_id, file_name, sort_order) VALUES (?, ?, ?)");
            mysqli_stmt_bind_param($ins, 'isi', $id, $fn, $order);
            mysqli_stmt_execute($ins);
        }
    }
} catch (Throwable $ex) {
    @error_log('[admin/package_store] ' . $ex->getMessage());
    set_flash('Could not save the package. Please try again.', 'danger');
    redirect($is_edit ? $back : site_url('admin/package_form.php'));
}

if ($photo_errors) {
    set_flash('Package saved, but some photos were not uploaded: ' . implode(' ', $photo_errors), 'warning');
    redirect(site_url('admin/package_form.php?id=' . $id));
}
set_flash($is_edit ? 'Package updated.' : 'Package created.', 'success');
redirect(site_url('admin/packages.php'));
