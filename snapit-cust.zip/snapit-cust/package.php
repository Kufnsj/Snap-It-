<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/reviews.php';

$id = (int)($_GET['id'] ?? 0);
$pkg = null;
if ($id > 0) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM packages WHERE package_id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $pkg = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}
// Customers only see active packages; admins can preview inactive ones.
if (!$pkg || (!$pkg['is_active'] && !is_admin())) {
    set_flash('That package could not be found.', 'warning');
    redirect(site_url('index.php#packages'));
}

// Cover first, then the gallery, as one list of image URLs.
$images = [];
if ($u = package_photo_url($pkg['image_path'] ?? null)) $images[] = $u;
foreach (package_gallery($conn, $id) as $g) {
    if ($u = package_photo_url($g['file_name'])) $images[] = $u;
}

// ---- Reviews ----
$reviews = package_reviews($conn, $id);
[$avg_rating, $review_count] = package_rating_summary($conn, $id);
$my_id = is_loggedin() ? (int)$_SESSION['user_id'] : 0;
$can_review = $my_id > 0 && $pkg['is_active'] && review_user_eligible($conn, $my_id, $id);
$my_review = $can_review ? review_for_user($conn, $my_id, $id) : null;
$old = $_SESSION['review_form_old'] ?? null;
unset($_SESSION['review_form_old']);
if (is_array($old) && (int)($old['package_id'] ?? 0) !== $id) $old = null;
$form_rating  = $old['rating']  ?? ($my_review['rating']  ?? '');
$form_comment = $old['comment'] ?? ($my_review['comment'] ?? '');

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/alert.php';
?>

<section class="container py-5">
    <a href="<?= e(site_url('index.php#packages')) ?>" class="text-decoration-none small"><i class="fa-solid fa-arrow-left me-1"></i>All packages</a>

    <div class="row g-5 mt-1">
        <div class="col-lg-7">
            <?php if ($images): ?>
                <img id="mainPhoto" src="<?= e($images[0]) ?>" alt="<?= e($pkg['name']) ?>" class="w-100 rounded shadow-sm" style="max-height:440px;object-fit:cover">
                <?php if (count($images) > 1): ?>
                    <div class="d-flex flex-wrap gap-2 mt-3">
                        <?php foreach ($images as $i => $src): ?>
                            <img src="<?= e($src) ?>" alt="Photo <?= $i + 1 ?> of <?= e($pkg['name']) ?>" class="rounded thumb-pick"
                                 style="width:90px;height:68px;object-fit:cover;cursor:pointer;border:2px solid <?= $i === 0 ? 'var(--snapit-gold, #c9a46b)' : 'transparent' ?>"
                                 data-full="<?= e($src) ?>">
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="rounded bg-light d-flex align-items-center justify-content-center text-muted" style="height:320px">
                    <div class="text-center"><i class="fa-regular fa-image fa-3x mb-2"></i><div>No photos yet</div></div>
                </div>
            <?php endif; ?>
        </div>

        <div class="col-lg-5">
            <?php if (!$pkg['is_active']): ?><span class="badge bg-secondary mb-2">Inactive (admin preview)</span><?php endif; ?>
            <h1 class="fw-bold"><?= e($pkg['name']) ?></h1>
            <p class="text-muted"><?= nl2br(e($pkg['description'] ?? '')) ?></p>

            <ul class="list-unstyled my-4">
                <li class="mb-2"><i class="fa-regular fa-clock me-2 text-primary"></i><?= (int)$pkg['duration_hours'] ?> hours of coverage</li>
                <li class="mb-2"><i class="fa-regular fa-file-image me-2 text-primary"></i><?= (int)$pkg['softcopy_count'] ?> soft copies</li>
                <li class="mb-2"><i class="fa-solid fa-print me-2 text-primary"></i><?= (int)$pkg['hardcopy_count'] ?> hard copies</li>
                <?php if ($pkg['has_softcopy_addon']): ?>
                    <li class="mb-2"><i class="fa-solid fa-plus me-2 text-primary"></i>Softcopy add-on available
                        <?php if ((float)$pkg['softcopy_addon_price'] > 0): ?>(+ <?= e(format_money($pkg['softcopy_addon_price'])) ?>)<?php endif; ?></li>
                <?php endif; ?>
            </ul>

            <div class="small text-muted">Starting at</div>
            <div class="price-tag mb-4"><?= e(format_money($pkg['base_price'])) ?></div>

            <?php if ($pkg['is_active'] && $pkg['package_type'] === 'event'): ?>
                <a href="<?= e(site_url('booking/create.php?package=' . (int)$pkg['package_id'])) ?>" class="btn btn-snapit btn-lg px-5">Book Now</a>
            <?php endif; ?>
        </div>
    </div>

    <hr class="my-5">

    <div id="reviews">
        <div class="d-flex align-items-center flex-wrap gap-3 mb-4">
            <h2 class="fw-bold mb-0">Customer Reviews</h2>
            <?php if ($review_count > 0): ?>
                <div class="fs-5"><?= render_stars($avg_rating) ?>
                    <span class="ms-1 fw-semibold"><?= e(number_format($avg_rating, 1)) ?></span>
                    <span class="text-muted small">(<?= (int)$review_count ?> review<?= $review_count === 1 ? '' : 's' ?>)</span>
                </div>
            <?php endif; ?>
        </div>

        <div class="row g-4">
            <div class="col-lg-7">
                <?php if (!$reviews): ?>
                    <div class="text-muted py-4">No reviews yet. Be the first to share your experience.</div>
                <?php endif; ?>
                <?php foreach ($reviews as $r): ?>
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between flex-wrap gap-1">
                                <div>
                                    <span class="fw-semibold"><?= e($r['name']) ?></span>
                                    <?php if ((int)$r['user_id'] === $my_id): ?><span class="badge bg-secondary ms-1">You</span><?php endif; ?>
                                </div>
                                <div class="small text-muted">
                                    <?= e(format_date($r['created_at'])) ?>
                                    <?php if ($r['updated_at'] !== $r['created_at']): ?>&middot; edited<?php endif; ?>
                                </div>
                            </div>
                            <div class="my-1"><?= render_stars($r['rating']) ?></div>
                            <p class="mb-0"><?= nl2br(e(mask_bad_words($r['comment']))) ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="col-lg-5">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <?php if ($can_review): ?>
                            <h5 class="fw-bold mb-3"><?= $my_review ? 'Edit your review' : 'Write a review' ?></h5>
                            <form method="POST" action="<?= e(site_url('reviews/store.php')) ?>" novalidate>
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="package_id" value="<?= (int)$id ?>">
                                <div class="mb-3">
                                    <label for="rating" class="form-label fw-semibold">Rating</label>
                                    <select class="form-select" id="rating" name="rating">
                                        <option value="">Choose...</option>
                                        <?php foreach ([5 => 'Excellent', 4 => 'Very good', 3 => 'Good', 2 => 'Fair', 1 => 'Poor'] as $n => $lbl): ?>
                                            <option value="<?= $n ?>" <?= (string)$form_rating === (string)$n ? 'selected' : '' ?>><?= $n ?> &ndash; <?= e($lbl) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="comment" class="form-label fw-semibold">Your review</label>
                                    <textarea class="form-control" id="comment" name="comment" rows="5"><?= e($form_comment) ?></textarea>
                                    <div class="form-text"><?= (int)REVIEW_MIN_LEN ?>&ndash;<?= (int)REVIEW_MAX_LEN ?> characters. Offensive words are automatically masked.</div>
                                </div>
                                <button type="submit" class="btn btn-snapit fw-semibold px-4"><?= $my_review ? 'Update Review' : 'Post Review' ?></button>
                            </form>
                        <?php elseif (!is_loggedin()): ?>
                            <h5 class="fw-bold mb-2">Share your experience</h5>
                            <p class="text-muted mb-3">Log in to review this package. Only customers who have completed a booking of it can leave a review.</p>
                            <a href="<?= e(site_url('users/login.php')) ?>" class="btn btn-snapit">Log in</a>
                        <?php else: ?>
                            <h5 class="fw-bold mb-2">Share your experience</h5>
                            <p class="text-muted mb-0">Only customers with a completed booking of this package can leave a review.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
(function () {
    var main = document.getElementById('mainPhoto');
    var thumbs = document.querySelectorAll('.thumb-pick');
    if (!main) return;
    thumbs.forEach(function (t) {
        t.addEventListener('click', function () {
            main.src = t.getAttribute('data-full');
            thumbs.forEach(function (o) { o.style.borderColor = 'transparent'; });
            t.style.borderColor = 'var(--snapit-gold, #c9a46b)';
        });
    });
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
