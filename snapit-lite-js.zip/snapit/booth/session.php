<?php
// Booth step 2: the photo-taking page. PHP decides which of three screens to show:
//   camera screen  (more photos still needed)  ->  review screen (just captured, keep or retake)  ->  complete screen (all photos kept).
// The only JavaScript is includes/booth_camera.js, which opens the webcam, counts down and posts the snapshot to save_photo.php.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';

// Guard block: login required.
require_login();

// Session block: finds the guest's active booth session, or sends them back to the booking list.
$session_id = current_booth_session_id($conn);
if (!$session_id) {
    set_flash('No active session found. Start a new session.', 'warning');
    redirect(site_url('booth/index.php'));
}

// Session-data block: loads the session with the chosen preset, filter, layout, frame and event name.
$stmt = mysqli_prepare($conn, "SELECT gs.*, 
    (gs.idle_timeout_at IS NOT NULL AND gs.idle_timeout_at < NOW()) AS idle_expired,
    cp.name AS preset_name, cp.brightness AS p_bri, cp.contrast AS p_con, cp.saturation AS p_sat, cp.warmness AS p_wrm, cp.cam_filter, cp.fx_grain, cp.fx_vignette, cp.fx_fade,
    f.name AS filter_name, f.css_filter,
    l.name AS layout_name, l.photo_count, l.grid_cols, l.grid_rows,
    fd.name AS frame_name, fd.border_color, fd.border_width, fd.bg_color, fd.text_color, fd.photo_gap, fd.photo_radius, fd.pattern, l.print_size,
    b.event_name
    FROM guest_sessions gs
    LEFT JOIN camera_presets cp ON gs.camera_preset_id = cp.preset_id
    LEFT JOIN filters f ON gs.filter_id = f.filter_id
    LEFT JOIN layouts l ON gs.layout_id = l.layout_id
    LEFT JOIN frame_designs fd ON gs.frame_design_id = fd.design_id
    LEFT JOIN bookings b ON gs.booking_id = b.booking_id
    WHERE gs.session_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $session_id);
mysqli_stmt_execute($stmt);
$session = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Selections check block: the guest must finish the customization page first.
if (!$session || !$session['photo_count']) {
    set_flash('Please configure your booth selections first.', 'warning');
    redirect(site_url('booth/capture.php'));
}

// Idle-timeout block: a session left untouched too long is closed by end_session.php (this replaces the old JavaScript idle countdown).
if (!empty($session['idle_expired'])) {
    redirect(site_url('booth/end_session.php?auto=1'));
}
booth_touch_session($conn, $session_id);

// Photos block: loads the photos already kept for this session.
$target_n = (int)$session['photo_count'];
// Query block: reads from session_photos.
$photos_stmt = mysqli_prepare($conn, "SELECT * FROM session_photos WHERE session_id = ? AND is_kept = 1 ORDER BY order_index ASC");
mysqli_stmt_bind_param($photos_stmt, 'i', $session_id);
mysqli_stmt_execute($photos_stmt);
$photo_rows = [];
$photos = mysqli_stmt_get_result($photos_stmt);
while ($ph = mysqli_fetch_assoc($photos)) {
    $photo_rows[] = $ph;
}
$photo_count = count($photo_rows);

// Screen-choice block: decides which screen to show from the photo count and the ?review=1 flag set by save_photo.php.
$is_complete = $photo_count >= $target_n;
$is_review   = isset($_GET['review']) && $photo_count > 0;
$show_camera = !$is_complete && !$is_review;

// Settings block: countdown seconds and mirror choice saved by booth_settings.php.
$countdown_seconds = (int)($session['countdown_seconds'] ?? 3);
if (!in_array($countdown_seconds, [3, 5, 10], true)) $countdown_seconds = 3;
$mirror_preview = (int)($session['mirror_preview'] ?? 1) === 1 ? 1 : 0;

// Filter block: builds the CSS filter text from the preset's brightness/contrast/saturation/warmth plus the guest's chosen filter.
$p_bri = (int)($session['p_bri'] ?? 0);
$p_con = (int)($session['p_con'] ?? 0);
$p_sat = (int)($session['p_sat'] ?? 0);
$p_wrm = (int)($session['p_wrm'] ?? 0);
$preset_filter_parts = [];
$preset_filter_parts[] = 'brightness(' . (1 + $p_bri / 100) . ')';
$preset_filter_parts[] = 'contrast(' . (1 + $p_con / 100) . ')';
$preset_filter_parts[] = 'saturate(' . max(0, 1 + $p_sat / 100) . ')';
if ($p_wrm > 0) {
    $preset_filter_parts[] = 'sepia(' . min(0.6, $p_wrm / 200) . ')';
} elseif ($p_wrm < 0) {
    $preset_filter_parts[] = 'hue-rotate(' . $p_wrm . 'deg)';
}
$preset_css_filter = implode(' ', $preset_filter_parts);
if (!empty($session['cam_filter'])) $preset_css_filter = $session['cam_filter'];
$filter_css = trim($session['css_filter'] ?? 'none');
$combined_css_filter = ($filter_css === '' || $filter_css === 'none') ? $preset_css_filter : $preset_css_filter . ' ' . $filter_css;

// Strip block: the finished photo-strip HTML (frame, layout and filter applied) drawn by PHP for the review and complete screens.
$strip_caption = $session['event_name'] . ' · ' . date('M j, Y');

// Page layout block: site header (navbar) and flash-message area.
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/alert.php';
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-10">

            <!-- Info bar block: shows the guest, preset, filter, layout and frame of this session -->
            <div class="card shadow-sm border-0 p-3 mb-3 no-print">
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <span class="badge bg-primary"><i class="fa-solid fa-user me-1"></i><?= e($session['guest_name'] ?: 'Guest #' . $session_id) ?></span>
                    <span class="badge badge-snapit"><i class="fa-solid fa-sliders me-1"></i><?= e($session['preset_name'] ?? 'Default') ?></span>
                    <span class="badge" style="background:var(--snapit-secondary);color:#fff;"><i class="fa-solid fa-palette me-1"></i><?= e($session['filter_name'] ?? 'None') ?></span>
                    <span class="badge bg-info text-dark"><i class="fa-solid fa-table-cells me-1"></i><?= e($session['layout_name'] ?? 'Solo') ?></span>
                    <span class="badge bg-secondary"><i class="fa-regular fa-image me-1"></i><?= e($session['frame_name'] ?? 'Plain') ?></span>
                </div>
                <div class="small text-muted mt-1">
                    <i class="fa-regular fa-calendar-check me-1"></i><?= e($session['event_name']) ?> &bull; Session #<?= (int)$session_id ?>
                    &bull; <i class="fa-regular fa-clock me-1"></i>Closes after <?= (int)BOOTH_IDLE_MINUTES ?> minutes of inactivity
                </div>
            </div>

            <!-- Progress block: "Photo X of N" bar calculated by PHP -->
            <div class="progress mb-3 no-print" style="height:28px;border-radius:14px;">
                <?php $pct = min(100, ($photo_count / max(1, $target_n)) * 100); ?>
                <div class="progress-bar progress-bar-striped" role="progressbar"
                     style="width: <?= $pct ?>%;background:linear-gradient(90deg,var(--snapit-primary),var(--snapit-secondary));">
                    <span class="fw-bold px-2">Photo <?= (int)min($photo_count + 1, $target_n) ?> of <?= (int)$target_n ?></span>
                </div>
            </div>

            <?php if ($show_camera): ?>
                <!-- Settings block: countdown length and mirror toggle; each button is a plain form submit handled by booth_settings.php -->
                <form method="POST" action="<?= e(site_url('booth/booth_settings.php')) ?>" class="booth-controls no-print">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <div class="d-flex align-items-center gap-2">
                        <span class="booth-ctl-label"><i class="fa-regular fa-clock me-1"></i>Timer</span>
                        <div class="cd-group" role="group" aria-label="Countdown timer">
                            <?php foreach ([3, 5, 10] as $cdOpt): ?>
                                <button type="submit" name="countdown" value="<?= $cdOpt ?>" class="cd-pill<?= $cdOpt === $countdown_seconds ? ' active' : '' ?>"><?= $cdOpt ?>s</button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <button type="submit" name="mirror" value="<?= $mirror_preview ? 0 : 1 ?>" class="mirror-toggle<?= $mirror_preview ? ' active' : '' ?>" title="Flip camera view">
                        <i class="fa-solid fa-camera-rotate me-1"></i>Mirror: <?= $mirror_preview ? 'On' : 'Off' ?>
                    </button>
                </form>
            <?php endif; ?>

            <div class="position-relative mb-4">
                <div class="booth-frame" style="border-color:<?= e($session['border_color']) ?>;border-width:<?= (int)$session['border_width'] ?>px;">

                    <?php if ($show_camera): ?>
                        <!-- Camera screen block: live video + film effects + countdown overlay. booth_camera.js reads the data-* settings below. -->
                        <div id="boothCamera" style="position:relative;width:100%;line-height:0;border-radius:16px;"
                             data-filter="<?= e($combined_css_filter) ?>" data-mirror="<?= $mirror_preview ?>" data-countdown="<?= $countdown_seconds ?>"
                             data-grain="<?= (int)($session['fx_grain'] ?? 0) ?>" data-vignette="<?= (int)($session['fx_vignette'] ?? 0) ?>" data-fade="<?= (int)($session['fx_fade'] ?? 0) ?>">
                            <video id="cameraVideo" autoplay playsinline muted
                                   style="width:100%;max-height:560px;object-fit:contain;border-radius:16px;background:#000;display:none;"></video>
                            <div id="camFx" style="position:absolute;inset:0;border-radius:16px;pointer-events:none;"></div>
                            <div id="countdownOverlay" class="countdown-big" style="display:none;position:absolute;inset:0;align-items:center;justify-content:center;background:rgba(18,13,9,0.88);border-radius:16px;z-index:20;"></div>
                            <canvas id="captureCanvas" style="display:none;"></canvas>
                        </div>
                        <p id="cameraMsg" class="text-center text-muted my-4">
                            <i class="fa-solid fa-spinner fa-spin me-1"></i>Starting camera... please allow camera access when your browser asks.
                        </p>
                        <noscript><p class="text-center text-danger my-4">The live camera needs JavaScript. Please enable it in your browser.</p></noscript>
                    <?php else: ?>
                        <!-- Strip screen block: the photos taken so far inside the chosen frame and layout (built by PHP) -->
                        <div class="w-100"><?= strip_html(array_column($photo_rows, 'photo_path'), strip_cfg($session, $strip_caption)) ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($show_camera): ?>
                <!-- Capture button block: stays disabled until the camera is ready; the script then runs the countdown and submits captureForm -->
                <div class="text-center no-print mb-4">
                    <button type="button" id="captureBtn" class="btn btn-snapit btn-lg px-5 py-4 fw-bold shadow-lg" style="font-size:1.25rem;min-width:260px;border-radius:18px;" disabled>
                        <i class="fa-solid fa-camera me-2 fa-xl"></i><?= $photo_count === 0 ? 'Start Capturing' : 'Next Photo' ?>
                    </button>
                </div>
                <!-- Snapshot form block: the script puts the photo here, then it is posted to save_photo.php -->
                <form id="captureForm" method="POST" action="<?= e(site_url('booth/save_photo.php')) ?>">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="image_data" value="">
                </form>
            <?php endif; ?>

            <?php if ($is_review): ?>
                <!-- Review block: keep the photo (just continue, or finish if it was the last one) or retake it (delete it and reopen the camera) -->
                <div class="card p-3 mb-4 no-print">
                    <div class="text-center mb-2 fw-semibold"><i class="fa-regular fa-circle-question me-1"></i>Keep this photo or retake?</div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <!-- Form block: posts the entered data to booth/delete_last_photo.php -->
                            <form method="POST" action="<?= e(site_url('booth/delete_last_photo.php')) ?>">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="retake">
                                <button type="submit" class="btn btn-outline-warning w-100 py-3 fw-semibold"><i class="fa-solid fa-rotate me-1"></i>Retake Photo</button>
                            </form>
                        </div>
                        <div class="col-md-6">
                            <a href="<?= e(site_url('booth/session.php')) ?>" class="btn btn-outline-success w-100 py-3 fw-semibold"><i class="fa-solid fa-check me-1"></i>Keep Photo</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!$is_review): ?>
            <!-- Navigation block: Back (removes the last photo) or back to selections, plus the Done button shown only when all photos are kept -->
            <div class="row g-3 no-print">
                <div class="col-md-6">
                    <?php if ($photo_count > 0): ?>
                        <!-- Form block: posts the entered data to booth/delete_last_photo.php -->
                        <form method="POST" action="<?= e(site_url('booth/delete_last_photo.php')) ?>">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="back">
                            <button type="submit" class="btn btn-outline-secondary w-100 py-2 fw-semibold"><i class="fa-solid fa-arrow-rotate-left me-1"></i>Back (remove last photo)</button>
                        </form>
                    <?php else: ?>
                        <a href="<?= e(site_url('booth/capture.php')) ?>" class="btn btn-outline-secondary w-100 py-2 fw-semibold"><i class="fa-solid fa-arrow-left me-1"></i>Back to selections</a>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <?php if ($is_complete): ?>
                        <!-- Form block: posts the entered data to booth/end_session.php -->
                        <form method="POST" action="<?= e(site_url('booth/end_session.php')) ?>">
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                            <button type="submit" class="btn btn-success w-100 py-2 fw-semibold"><i class="fa-solid fa-check me-1"></i>Done / New Guest</button>
                            <div class="small text-success fw-semibold text-center mt-2"><i class="fa-solid fa-circle-check me-1"></i>All <?= (int)$target_n ?> photo<?= $target_n !== 1 ? 's' : '' ?> captured &mdash; ready to finish.</div>
                        </form>
                    <?php else: ?>
                        <div class="small text-muted text-center pt-2"><i class="fa-solid fa-circle-info me-1"></i>Capture all <?= (int)$target_n ?> photo<?= $target_n !== 1 ? 's' : '' ?> first (<?= (int)$photo_count ?>/<?= (int)$target_n ?> done).</div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php if ($show_camera): ?>
    <!-- Script block: the two small browser scripts used by the booth camera (film effects + webcam capture) -->
    <script src="<?= e(site_url('includes/camfx.js')) ?>"></script>
    <script src="<?= e(site_url('includes/booth_camera.js')) ?>"></script>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
