// Booth camera script: the ONLY JavaScript the photo booth needs (browsers can open a webcam only through JavaScript).
// Everything else (photo list, progress, keep/retake, settings, idle timer) is done by PHP.
(function () {
  var box = document.getElementById('boothCamera');
  if (!box) return; // not in camera mode (review or complete screen)
  var video = document.getElementById('cameraVideo'), canvas = document.getElementById('captureCanvas');
  var btn = document.getElementById('captureBtn'), msg = document.getElementById('cameraMsg');
  var overlay = document.getElementById('countdownOverlay'), form = document.getElementById('captureForm');
  var filter = box.dataset.filter || 'none', mirror = box.dataset.mirror === '1', seconds = parseInt(box.dataset.countdown, 10) || 3;
  var fx = { grain: +box.dataset.grain || 0, vignette: +box.dataset.vignette || 0, fade: +box.dataset.fade || 0 };
  var stream = null;

  // Preview block: applies the guest's preset/filter, mirror and film effects to the live video using CSS only.
  video.style.filter = filter;
  if (mirror) video.style.transform = 'scaleX(-1)';
  var fxEl = document.getElementById('camFx');
  if (fxEl && window.CamFX) fxEl.innerHTML = CamFX.overlay(fx);

  // Camera block: asks the browser for the webcam and enables the capture button when it is ready.
  function startCamera() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      msg.textContent = 'This browser cannot open the camera. Use a recent Chrome, Edge or Firefox on localhost or HTTPS.';
      return;
    }
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 800 } }, audio: false })
      .then(function (s) {
        stream = s; video.srcObject = s; video.play();
        video.style.display = ''; msg.style.display = 'none'; btn.disabled = false;
      })
      .catch(function (err) {
        msg.textContent = (err && err.name === 'NotAllowedError') ? 'Camera permission was denied. Allow it in the address bar, then refresh.'
          : (err && err.name === 'NotFoundError') ? 'No camera was found on this device.'
          : 'The camera could not start. Close other apps that use it, then refresh.';
      });
  }

  // Countdown block: shows 3-2-1 over the preview, then takes the photo.
  btn.addEventListener('click', function () {
    btn.disabled = true;
    var n = seconds;
    overlay.style.display = 'flex'; overlay.textContent = n;
    var timer = setInterval(function () {
      n--;
      if (n > 0) { overlay.textContent = n; return; }
      clearInterval(timer); overlay.style.display = 'none'; snap();
    }, 1000);
  });

  // Snapshot block: draws the current frame (with filter, mirror and effects) to a canvas, puts it in the hidden form field and submits to PHP.
  function snap() {
    var w = video.videoWidth || 1280, h = video.videoHeight || 800, ctx = canvas.getContext('2d');
    canvas.width = w; canvas.height = h;
    ctx.save(); ctx.filter = filter;
    if (mirror) { ctx.translate(w, 0); ctx.scale(-1, 1); }
    ctx.drawImage(video, 0, 0, w, h); ctx.restore();
    if (window.CamFX) CamFX.apply(ctx, w, h, fx);
    form.elements.image_data.value = canvas.toDataURL('image/jpeg', 0.92);
    stopCamera();
    form.submit();
  }

  // Cleanup block: turns the webcam light off when leaving the page.
  function stopCamera() { if (stream) stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; }
  window.addEventListener('pagehide', stopCamera);

  startCamera();
})();
