<?php
// Admin: list of packages with photo counts, activate/deactivate and delete.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
// Guard block: only admins can use this page.
require_admin();

// Activate / deactivate (soft delete) a package.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Security block: rejects forms without a valid CSRF token.
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('Your session expired. Please try again.', 'danger');
        redirect(site_url('admin/packages.php'));
    }
    if (($_POST['action'] ?? '') === 'toggle_status' && isset($_POST['package_id'])) {
        $pid = (int)$_POST['package_id'];
        // Update block: changes rows in packages.
        $st = mysqli_prepare($conn, "UPDATE packages SET is_active = 1 - is_active WHERE package_id = ?");
        mysqli_stmt_bind_param($st, 'i', $pid);
        mysqli_stmt_execute($st);
        set_flash(mysqli_stmt_affected_rows($st) > 0 ? 'Package status updated.' : 'Package not found.',
                  mysqli_stmt_affected_rows($st) > 0 ? 'success' : 'danger');
    }
    redirect(site_url('admin/packages.php'));
}

$search = trim((string)($_GET['search'] ?? ''));
$sql = "SELECT p.*, (SELECT COUNT(*) FROM package_photos ph WHERE ph.package_id = p.package_id) AS gallery_count
        FROM packages p";
if ($search !== '') {
    $like = '%' . addcslashes($search, '%_\\') . '%';
    $stmt = mysqli_prepare($conn, $sql . " WHERE p.name LIKE ? OR p.description LIKE ? ORDER BY p.package_id DESC");
    mysqli_stmt_bind_param($stmt, 'ss', $like, $like);
} else {
    $stmt = mysqli_prepare($conn, $sql . " ORDER BY p.package_id DESC");
}
mysqli_stmt_execute($stmt);
$packages = mysqli_stmt_get_result($stmt);
$total = mysqli_num_rows($packages);

// Page layout block: site header (navbar) and flash-message area.
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/alert.php';
?>

<section class="container py-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <h1 class="fw-bold mb-0"><i class="fa-solid fa-camera-retro me-2"></i>Package Management</h1>
        <a href="<?= e(site_url('admin/package_form.php')) ?>" class="btn btn-snapit fw-semibold">
            <i class="fa-solid fa-plus me-2"></i>Add Package
        </a>
    </div>

    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body p-4">
            <form method="GET" class="row g-3 align-items-end" novalidate>
                <div class="col-md-8">
                    <label class="form-label fw-semibold">Search Packages</label>
                    <input type="text" name="search" class="form-control" placeholder="Search by name or description..." value="<?= e($search) ?>">
                </div>
                <div class="col-md-4 d-flex gap-2">
                    <button type="submit" class="btn btn-snapit flex-grow-1"><i class="fa-solid fa-search me-1"></i>Search</button>
                    <?php if ($search !== ''): ?>
                        <a href="<?= e(site_url('admin/packages.php')) ?>" class="btn btn-outline-secondary"><i class="fa-solid fa-xmark"></i></a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold mb-0">Packages</h5>
            <span class="badge badge-snapit px-3 py-2"><?= (int)$total ?> record(s)</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <!-- Table block: the list of records, one row each -->
                <table class="table table-hover mb-0 align-middle">
                    <thead>
                        <tr>
                            <th>Package</th><th>Type</th><th>Duration</th><th>Price</th><th>Photos</th><th>Status</th>
                            <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($total > 0): ?>
                        <?php while ($p = mysqli_fetch_assoc($packages)): ?>
                            <?php $img = package_photo_url($p['image_path'] ?? null); ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <?php if ($img): ?>
                                            <img src="<?= e($img) ?>" alt="" class="me-3 rounded" style="width:56px;height:42px;object-fit:cover">
                                        <?php else: ?>
                                            <div class="me-3 rounded bg-light d-flex align-items-center justify-content-center text-muted" style="width:56px;height:42px"><i class="fa-regular fa-image"></i></div>
                                        <?php endif; ?>
                                        <div>
                                            <div class="fw-bold"><?= e($p['name']) ?></div>
                                            <div class="small text-muted">ID: #<?= (int)$p['package_id'] ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?= e(ucfirst($p['package_type'])) ?></td>
                                <td><?= (int)$p['duration_hours'] ?> hrs</td>
                                <td><?= e(format_money($p['base_price'])) ?></td>
                                <td><?= $img ? 'Cover + ' : 'No cover, ' ?><?= (int)$p['gallery_count'] ?> gallery</td>
                                <td>
                                    <span class="badge rounded-pill px-3 py-2 <?= $p['is_active'] ? 'bg-success' : 'bg-secondary' ?>">
                                        <?= $p['is_active'] ? 'Active' : 'Inactive' ?>
                                    </span>
                                </td>
                                <td class="text-end text-nowrap">
                                    <a href="<?= e(site_url('package.php?id=' . (int)$p['package_id'])) ?>" class="btn btn-sm btn-outline-secondary"><i class="fa-regular fa-eye me-1"></i>View</a>
                                    <a href="<?= e(site_url('admin/package_form.php?id=' . (int)$p['package_id'])) ?>" class="btn btn-sm btn-outline-light"><i class="fa-solid fa-pen me-1"></i>Edit</a>
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Change this package\'s status?');">
                                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                        <input type="hidden" name="action" value="toggle_status">
                                        <input type="hidden" name="package_id" value="<?= (int)$p['package_id'] ?>">
                                        <button type="submit" class="btn btn-sm <?= $p['is_active'] ? 'btn-outline-warning' : 'btn-outline-success' ?>">
                                            <?= $p['is_active'] ? 'Deactivate' : 'Activate' ?>
                                        </button>
                                    </form>
                                    <!-- Form block: posts the entered data to admin/package_delete.php -->
                                    <form method="POST" action="<?= e(site_url('admin/package_delete.php')) ?>" class="d-inline"
                                          onsubmit="return confirm('Permanently delete this package and its photos? This cannot be undone.');">
                                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                        <input type="hidden" name="package_id" value="<?= (int)$p['package_id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fa-regular fa-trash-can me-1"></i>Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center text-muted py-5">
                            <?= $search !== '' ? 'No packages match your search.' : 'No packages yet. Click "Add Package" to create one.' ?>
                        </td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
